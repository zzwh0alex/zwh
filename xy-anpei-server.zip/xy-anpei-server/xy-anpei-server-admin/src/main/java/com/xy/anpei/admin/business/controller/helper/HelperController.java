package com.xy.anpei.admin.business.controller.helper;

import com.xy.anpei.admin.business.dto.helper.HelperGenPwdDto;
import com.xy.anpei.admin.business.dto.helper.HelperParsePwdDto;
import com.xy.anpei.admin.business.service.HelperService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-06-28 10:11
 */
@RestController
@RequestMapping("/helper")
public class HelperController {

    private final HelperService helperService;

    public HelperController(HelperService helperService) {
        this.helperService = helperService;
    }

    @PostMapping(value = "/generatePassword", name = "生成密码")
    public Object generatePassword(@RequestBody @Valid HelperGenPwdDto dto) {
        return helperService.generatePassword(dto);
    }

    @PostMapping(value = "/parsePassword", name = "解析密码")
    public Object parsePassword(@RequestBody @Valid HelperParsePwdDto dto) {
        return helperService.parsePassword(dto);
    }
}
