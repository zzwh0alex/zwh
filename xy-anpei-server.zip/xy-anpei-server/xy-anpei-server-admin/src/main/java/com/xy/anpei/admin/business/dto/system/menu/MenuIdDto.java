package com.xy.anpei.admin.business.dto.system.menu;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 09:04
 */
@Data
public class MenuIdDto {

    /**
     * 菜单 ID
     */
    @NotBlank(message = "菜单ID不能为空")
    private String menuId;
}
