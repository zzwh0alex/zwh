package com.xy.anpei.admin.security.config.jwt;

import com.auth0.jwt.exceptions.AlgorithmMismatchException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.xy.anpei.admin.util.JwtUtil;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * JWT 认证类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:31
 */
@Slf4j
public class JwtAuthenticationProvider implements AuthenticationProvider {

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String token = ((JwtAuthenticationToken) authentication).getToken();
        try {
            JwtUtil.verify(token);
        } catch (TokenExpiredException tee) {
            log.info("令牌已过期！token={}", token);
            throw new BusinessException(Response.TOKEN_ERROR);
        } catch (SignatureVerificationException sve) {
            log.info("令牌签名错误！token={}", token);
            throw new BusinessException(Response.TOKEN_ERROR);
        } catch (AlgorithmMismatchException ame) {
            log.info("令牌加密算法不匹配！token={}", token);
            throw new BusinessException(Response.TOKEN_ERROR);
        } catch (Exception e) {
            log.info("令牌错误！token={}", token);
            throw new BusinessException(Response.TOKEN_ERROR);
        }
        return authentication;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return JwtAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
