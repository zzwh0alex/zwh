package com.xy.anpei.admin.security.config.jwt;

import com.xy.anpei.admin.security.filter.JwtAuthenticationFilter;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutFilter;

/**
 * JWT 配置类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:34
 */
public class JwtConfig<T extends JwtConfig<T, B>, B extends HttpSecurityBuilder<B>> extends AbstractHttpConfigurer<T, B> {

    private final JwtAuthenticationFilter authFilter;

    public JwtConfig() {
        this.authFilter = new JwtAuthenticationFilter();
    }

    @Override
    public void configure(B builder) {
        authFilter.setAuthenticationManager(builder.getSharedObject(AuthenticationManager.class));

        JwtAuthenticationFilter filter = postProcess(authFilter);
        builder.addFilterBefore(filter, LogoutFilter.class);
    }

    public JwtConfig<T, B> authenticationSuccessHandler(AuthenticationSuccessHandler authSuccessHandler) {
        authFilter.setAuthenticationSuccessHandler(authSuccessHandler);
        return this;
    }
}
