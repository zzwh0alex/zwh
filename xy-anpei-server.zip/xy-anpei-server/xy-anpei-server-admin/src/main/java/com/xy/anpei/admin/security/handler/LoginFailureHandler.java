package com.xy.anpei.admin.security.handler;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 登录失败处理器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:50
 */
public class LoginFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) {
        throw new BusinessException(Response.NO_AUTH, exception.getMessage());
    }
}
