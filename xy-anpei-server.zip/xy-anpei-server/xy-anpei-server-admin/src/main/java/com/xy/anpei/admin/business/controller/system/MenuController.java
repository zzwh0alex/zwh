package com.xy.anpei.admin.business.controller.system;

import com.xy.anpei.admin.business.dto.system.menu.MenuIdDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuQueryDto;
import com.xy.anpei.admin.business.service.MenuService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 11:29
 */
@RestController
@RequestMapping("/menu")
public class MenuController {

    private final MenuService menuService;

    public MenuController(MenuService menuService) {
        this.menuService = menuService;
    }

    @GetMapping(value = "/getUserMenus", name = "获取当前用户菜单")
    public Object getUserMenus() {
        return menuService.getUserMenus();
    }

    @PreAuthorize("hasAuthority('system.menu.query')")
    @PostMapping(value = "/getSysMenus", name = "分页获取系统菜单信息")
    public Object getSysMenus(@RequestBody @Valid MenuQueryDto dto) {
        return menuService.getSysMenus(dto);
    }

    @PreAuthorize("hasAuthority('system.menu.add')")
    @PostMapping(value = "/add", name = "添加系统菜单")
    public void add(@RequestBody @Valid MenuDto dto) {
        menuService.add(dto);
    }

    @PreAuthorize("hasAuthority('system.menu.update')")
    @PostMapping(value = "/update", name = "更新系统菜单")
    public void update(@RequestBody @Valid MenuDto dto) {
        menuService.update(dto);
    }

    @PreAuthorize("hasAuthority('system.menu.delete')")
    @PostMapping(value = "/delete", name = "删除系统菜单")
    public void delete(@RequestBody @Valid MenuIdDto dto) {
        menuService.delete(dto);
    }
}
