package com.xy.anpei.admin.security.handler;

import cn.hutool.extra.spring.SpringUtil;
import com.xy.anpei.admin.business.domain.entity.User;
import com.xy.anpei.admin.business.service.UserService;
import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.security.config.jwt.JwtAuthenticationToken;
import com.xy.anpei.admin.util.JwtUtil;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * JWT 验证成功处理器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:29
 */
public class JwtSuccessHandler extends CommonSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        String token = ((JwtAuthenticationToken) authentication).getToken();
        String userId = JwtUtil.getClaim(token, AdminConst.FIELD_USER_ID);

        // 查询用户信息
        User user = SpringUtil.getBean(UserService.class).getByUserId(userId);
        // 将用户信息存入 Authentication 供后续使用
        SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(user.getAuthorities(), user));

        // 判断 token 是否需要刷新
        if (JwtUtil.needToRefresh(token)) {
            addTokenToHeader(response);
        }
    }
}
