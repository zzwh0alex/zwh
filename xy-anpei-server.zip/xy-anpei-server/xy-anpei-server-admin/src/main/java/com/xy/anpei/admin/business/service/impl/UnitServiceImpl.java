package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.domain.model.ViewUnit;
import com.xy.anpei.admin.business.dto.unit.unit.UnitDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitNoDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitQueryDto;
import com.xy.anpei.admin.business.repository.ViewUnitRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.UnitService;
import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.business.repository.UnitRepository;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.JpaUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 09:49
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UnitServiceImpl extends AbstractService implements UnitService {

    private final UnitRepository unitRepository;

    private final ViewUnitRepository viewUnitRepository;

    public UnitServiceImpl(UnitRepository unitRepository,
                           ViewUnitRepository viewUnitRepository) {
        this.unitRepository = unitRepository;
        this.viewUnitRepository = viewUnitRepository;
    }

    @Override
    public Object getAvailableUnits() {
        List<Unit> units = unitRepository.findAll(JpaUtil.getDefaultExample(Unit.class), Sort.by("displayOrder"));
        return units.stream().map(unit -> {
            Map<String, Object> map = new LinkedHashMap<>(3);
            map.put("unitNo", unit.getUnitNo());
            map.put("unitName", unit.getUnitName());
            map.put("fullName", unit.getFullName());
            return map;
        }).collect(Collectors.toList());
    }

    @Override
    public Object getUnits(UnitQueryDto dto) {
        return getPage(viewUnitRepository, dto, this.getReturnFields());
    }

    @Override
    public Object getUnitDetail(UnitNoDto dto) {
        ViewUnit unit = viewUnitRepository.findByUnitNo(dto.getUnitNo())
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在机构[%s]", dto.getUnitNo())));
        return beanToMap(unit, this.getReturnFields());
    }

    @Override
    public void add(UnitDto dto) {
        unitRepository.findByUnitNo(dto.getUnitNo()).ifPresent(u -> {
            throw new BusinessException(Response.DATA_ALREADY_EXISTS, String.format("已存在机构[%s]", u.getUnitNo()));
        });
        Unit unit = this.fillUnit(new Unit(), dto);
        doCreate(unit);
        unitRepository.save(unit);
    }

    @Override
    public void update(UnitDto dto) {
        Unit unit = this.fillUnit(this.getByUnitNo(dto.getUnitNo()), dto);
        doUpdate(unit);
        unitRepository.save(unit);
    }

    @Override
    public void delete(UnitNoDto dto) {
        Unit unit = this.getByUnitNo(dto.getUnitNo());
        doDelete(unit);
        unitRepository.save(unit);
    }

    @Override
    public Unit getByUnitNo(String unitNo) {
        return unitRepository.findByUnitNo(unitNo)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在机构[%s]", unitNo)));
    }

    /**
     * 获取返回字段
     *
     * @return 返回字段
     */
    private String[] getReturnFields() {
        return new String[]{"unitNo", "unitName", "fullName", "address", "postalCode", "provinceId", "provinceFullName",
                "cityId", "cityFullName", "districtId", "districtFullName", "businessLicenseNo", "businessLicenseDate",
                "businessLicenseRegNo", "businessScope", "unifiedSocialCreditCode", "legalPerson", "contactNumber", "displayOrder",
                "deleteFlag", "deleteDesc", "createUser", "createTime", "updateUser", "updateTime", "deleteUser", "deleteTime"};
    }

    /**
     * 填充机构信息
     *
     * @param unit Unit
     * @param dto  UnitDto
     * @return Unit
     */
    private Unit fillUnit(Unit unit, UnitDto dto) {
        unit.setUnitNo(StringUtils.deleteWhitespace(dto.getUnitNo()));
        unit.setUnitName(StringUtils.deleteWhitespace(dto.getUnitName()));
        unit.setFullName(StringUtils.deleteWhitespace(dto.getUnitName()));
        unit.setAddress(StringUtils.deleteWhitespace(dto.getAddress()));
        unit.setPostalCode(StringUtils.deleteWhitespace(dto.getPostalCode()));
        unit.setProvinceId(dto.getProvinceId());
        unit.setCityId(dto.getCityId());
        unit.setDistrictId(dto.getDistrictId());
        unit.setBusinessLicenseNo(StringUtils.deleteWhitespace(dto.getBusinessLicenseNo()));
        unit.setBusinessLicenseDate(StringUtils.deleteWhitespace(dto.getBusinessLicenseDate()));
        unit.setBusinessLicenseRegNo(StringUtils.deleteWhitespace(dto.getBusinessLicenseRegNo()));
        unit.setBusinessScope(StringUtils.deleteWhitespace(dto.getBusinessScope()));
        unit.setUnifiedSocialCreditCode(StringUtils.deleteWhitespace(dto.getUnifiedSocialCreditCode()));
        unit.setLegalPerson(StringUtils.deleteWhitespace(dto.getLegalPerson()));
        unit.setContactNumber(StringUtils.deleteWhitespace(dto.getContactNumber()));
        unit.setDisplayOrder(dto.getDisplayOrder());
        return unit;
    }
}
