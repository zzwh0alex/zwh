package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.region.CityDto;
import com.xy.anpei.admin.business.dto.region.ProvinceDto;
import com.xy.anpei.base.business.domain.entity.City;
import com.xy.anpei.base.business.domain.entity.District;
import com.xy.anpei.base.business.domain.entity.Province;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:47
 */
public interface RegionService {

    /**
     * 获取省列表
     *
     * @return a list of Province
     */
    List<Province> getProvinces();

    /**
     * 获取市列表
     *
     * @param dto ProvinceDto
     * @return a list of City
     */
    List<City> getCities(ProvinceDto dto);

    /**
     * 获取区/县列表
     *
     * @param dto CityDto
     * @return a list of District
     */
    List<District> getDistricts(CityDto dto);
}
