package com.xy.anpei.admin.business.dto.unit.coach;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 16:02
 */
@Data
public class CoachDto {

    /**
     * 教练员姓名
     */
    @NotBlank(message = "教练员姓名不能为空")
    private String coachName;

    /**
     * 机构编号
     */
    @NotBlank(message = "机构编号不能为空")
    private String unitNo;

    /**
     * 身份证号
     */
    @NotBlank(message = "身份证号不能为空")
    private String idNo;

    /**
     * 手机号码
     */
    @NotBlank(message = "手机号码不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号码格式不正确")
    private String phone;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 个人照片
     */
    private MultipartFile file;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @Min(value = 0, message = "账号状态不正确")
    @Max(value = 1, message = "账号状态不正确")
    @NotNull(message = "账号状态不能为空")
    private Integer status;
}
