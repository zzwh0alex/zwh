package com.xy.anpei.admin.business.dto.system.role;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 16:56
 */
@Data
public class RoleDto {

    /**
     * 角色 ID
     */
    @NotBlank(message = "角色ID不能为空")
    private String roleId;

    /**
     * 角色名称
     */
    @NotBlank(message = "角色名称不能为空")
    private String roleName;

    /**
     * 角色描述
     */
    private String roleDesc;

    /**
     * 权限 ID 列表
     */
    @NotNull(message = "角色权限不能为空")
    @Size(min = 1, message = "请至少选择一个权限")
    private Set<String> authIds;
}
