package com.xy.anpei.admin.business.dto.common;

import com.xy.anpei.base.page.PageInterface;
import lombok.Data;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 09:48
 */
@Data
public class MyPage implements PageInterface {

    /**
     * 当前页数
     */
    @Min(value = 1, message = "当前页数不能小于1")
    private Integer pageNum;

    /**
     * 分页大小
     */
    @Min(value = 1, message = "分页大小不能小于1")
    @Max(value = 100, message = "分页大小不能大于100")
    private Integer pageSize;

    @Override
    public Pageable getPageable() {
        if (null == this.pageNum) {
            this.pageNum = 1;
        }
        if (null == this.pageSize) {
            this.pageSize = 10;
        }
        return PageRequest.of(this.pageNum - 1, this.pageSize);
    }
}
