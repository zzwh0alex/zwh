package com.xy.anpei.admin.util;

import com.xy.anpei.admin.constant.AdminConst;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

/**
 * 验证码工具类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 16:34
 */
public class CaptchaUtil {

    /**
     * 字体
     */
    private static final String[] FONT_NAMES = {"宋体", "楷体", "隶书", "微软雅黑"};

    /**
     * 字符集（不含数字 0 和 1、小写字母 l 和 o、大写字母 I 和 O）
     */
    private static final String CODES = "23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";

    /**
     * Random 对象
     */
    private static final Random RANDOM = new Random();

    /**
     * 随机获取一个字符串
     *
     * @return String
     */
    private static String randomChar() {
        return CODES.charAt(RANDOM.nextInt(CODES.length())) + "";
    }

    /**
     * 随机获取一个颜色
     *
     * @return Color
     */
    private static Color randomColor() {
        int bound = 200;
        int red = RANDOM.nextInt(bound);
        int green = RANDOM.nextInt(bound);
        int blue = RANDOM.nextInt(bound);
        return new Color(red, green, blue);
    }

    /**
     * 随机获取一种字体
     *
     * @return Font
     */
    private static Font randomFont() {
        String name = FONT_NAMES[RANDOM.nextInt(FONT_NAMES.length)];
        int style = RANDOM.nextInt(3);
        int size = RANDOM.nextInt(5) + 24;
        return new Font(name, style, size);
    }

    /**
     * 绘制干扰线
     *
     * @param graphics Graphics2D
     * @param width    验证码宽度
     * @param height   验证码高度
     */
    private static void drawLine(Graphics2D graphics, int width, int height) {
        int num = 5;
        for (int i = 0; i < num; i++) {
            int x1 = RANDOM.nextInt(width);
            int y1 = RANDOM.nextInt(height);
            int x2 = RANDOM.nextInt(width);
            int y2 = RANDOM.nextInt(height);
            graphics.setColor(randomColor());
            graphics.setStroke(new BasicStroke(1.5f));
            graphics.drawLine(x1, y1, x2, y2);
        }
    }

    /**
     * 创建验证码
     *
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @param length   验证码长度
     * @param width    验证码图片宽度
     * @param height   验证码图片高度
     * @throws IOException IOException
     */
    public static void generateCaptcha(HttpServletRequest request, HttpServletResponse response, Integer length, Integer width, Integer height) throws IOException {
        if (null == length) {
            length = 4;
        }
        if (null == width) {
            width = 100;
        }
        if (null == height) {
            height = 40;
        }

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        g2.fillRect(0, 0, width, height);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            String str = randomChar();
            sb.append(str);
            g2.setColor(randomColor());
            g2.setFont(randomFont());
            g2.drawString(str, width * (i * 1.0f / length + 0.05f), height * 0.625f);
        }
        drawLine(g2, width, height);

        request.getSession().setAttribute(AdminConst.SESSION_CAPTCHA, sb.toString());
        ImageIO.write(image, "JPG", response.getOutputStream());
    }
}
