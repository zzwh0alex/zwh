package com.xy.anpei.admin.business.domain.model;

import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 17:51
 */
@Getter
@Setter
@Entity
@Table(name = "view_study_time")
public class ViewStudyTime implements Serializable {

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Id
    @Column(name = "train_id")
    private String trainId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "unit_full_name")
    private String unitFullName;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 课程名称
     */
    @Column(name = "subject_name")
    private String subjectName;

    /**
     * 课件名称
     */
    @Column(name = "course_name")
    private String courseName;

    /**
     * 学时类型
     * 1-视频（video）；2-练习（practice）
     */
    @Column(name = "time_type")
    private Integer timeType;

    /**
     * 开始时间
     */
    @Column(name = "start_time")
    private Date startTime;

    /**
     * 结束时间
     */
    @Column(name = "end_time")
    private Date endTime;

    /**
     * 有效时长（单位：分钟）
     */
    @Column(name = "duration")
    private Integer duration;

    /**
     * 学时状态
     * 0-无效；1-有效
     */
    @Column(name = "status")
    private Integer status;

    /**
     * 访问客户端
     */
    @Column(name = "client")
    private String client;

    /**
     * 访问 IP
     */
    @Column(name = "request_ip")
    private String requestIp;

    /**
     * 备注
     */
    @Column(name = "remark")
    private String remark;

    /**
     * 照片集合
     */
    @Column(name = "photo_list")
    private String photoList;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 获取学时类型的中文描述
     *
     * @return 学时类型的中文描述
     */
    public String getTimeTypeDesc() {
        String timeTypeDesc = "";
        if (MyConst.TIME_TYPE_VIDEO_INT == this.timeType) {
            timeTypeDesc = "视频";
        } else if (MyConst.TIME_TYPE_PRACTICE_INT == this.timeType) {
            timeTypeDesc = "练习";
        }
        return timeTypeDesc;
    }

    /**
     * 获取学时状态的中文描述
     *
     * @return 学时状态的中文描述
     */
    public String getStatusDesc() {
        String statusDesc = "";
        if (0 == this.status) {
            statusDesc = "无效";
        } else if (1 == this.status) {
            statusDesc = "有效";
        }
        return statusDesc;
    }
}
