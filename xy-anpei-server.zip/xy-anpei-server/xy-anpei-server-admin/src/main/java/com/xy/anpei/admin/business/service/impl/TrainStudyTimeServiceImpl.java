package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.dto.train.TimeQueryDto;
import com.xy.anpei.admin.business.repository.ViewStudyTimeRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.TrainStudyTimeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 14:50
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class TrainStudyTimeServiceImpl extends AbstractService implements TrainStudyTimeService {

    private final ViewStudyTimeRepository viewStudyTimeRepository;

    public TrainStudyTimeServiceImpl(ViewStudyTimeRepository viewStudyTimeRepository) {
        this.viewStudyTimeRepository = viewStudyTimeRepository;
    }

    @Override
    public Object getStudyTimes(TimeQueryDto dto) {
        String[] fileds = {"trainId", "unitNo", "unitName", "unitFullName", "coachName", "idNo", "subjectName",
                "courseName", "timeType", "timeTypeDesc", "startTime", "endTime", "duration", "status", "statusDesc",
                "client", "requestIp", "remark", "createTime"};
        return getPage(viewStudyTimeRepository, dto, fileds);
    }
}
