package com.xy.anpei.admin.business.controller.system;

import com.xy.anpei.admin.business.dto.system.user.*;
import com.xy.anpei.admin.business.service.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 16:32
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PreAuthorize("hasAuthority('system.user.query')")
    @PostMapping(value = "/getUsers", name = "分页获取系统用户信息")
    public Object getUsers(@RequestBody @Valid UserQueryDto dto) {
        return userService.getPageUsers(dto);
    }

    @PreAuthorize("hasAuthority('system.user.query')")
    @PostMapping(value = "/getUserRoles", name = "获取用户角色信息")
    public Object getUserRoles(@RequestBody @Valid UserIdDto dto) {
        return userService.getUserRoles(dto);
    }

    @PreAuthorize("hasAuthority('system.user.add')")
    @PostMapping(value = "/add", name = "添加系统用户")
    public void add(@RequestBody @Valid UserAddDto dto) {
        userService.add(dto);
    }

    @PreAuthorize("hasAuthority('system.user.update')")
    @PostMapping(value = "/update", name = "更新系统用户")
    public void update(@RequestBody @Valid UserUpdDto dto) {
        userService.update(dto);
    }

    @PreAuthorize("hasAuthority('system.user.delete')")
    @PostMapping(value = "/delete", name = "删除系统用户")
    public void delete(@RequestBody @Valid UserIdDto dto) {
        userService.delete(dto);
    }

    @PostMapping(value = "/changePassword", name = "修改账号密码")
    public void changePassword(@RequestBody @Valid UserPwdChgDto dto) {
        userService.changePassword(dto);
    }

    @PreAuthorize("hasAuthority('system.user.update')")
    @PostMapping(value = "/resetPassword", name = "重置账号密码")
    public void resetPassword(@RequestBody @Valid UserPwdResDto dto) {
        userService.resetPassword(dto);
    }
}
