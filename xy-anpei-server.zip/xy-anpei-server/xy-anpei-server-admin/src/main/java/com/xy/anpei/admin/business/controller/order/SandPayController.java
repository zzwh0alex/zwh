package com.xy.anpei.admin.business.controller.order;

import com.xy.anpei.admin.business.dto.order.ClearDateDto;
import com.xy.anpei.admin.business.dto.order.OrderCodeDto;
import com.xy.anpei.admin.business.dto.order.RefundDto;
import com.xy.anpei.admin.business.service.SandPayService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-13 14:41
 */
@RestController
@RequestMapping("/sp")
public class SandPayController {

    private final SandPayService sandPayService;

    public SandPayController(SandPayService sandPayService) {
        this.sandPayService = sandPayService;
    }

    @PreAuthorize("hasAuthority('order.query.query')")
    @PostMapping(value = "/orderQuery", name = "订单查询")
    public Object getStudyTimes(@RequestBody @Valid OrderCodeDto dto) {
        return sandPayService.orderQuery(dto);
    }

    @PreAuthorize("hasAuthority('order.refund.refund')")
    @PostMapping(value = "/orderRefund", name = "申请退款")
    public Object orderRefund(@RequestBody @Valid RefundDto dto) {
        return sandPayService.orderRefund(dto);
    }

    @PreAuthorize("hasAuthority('bill.download.download')")
    @PostMapping(value = "/billDownload", name = "对账单下载")
    public Object billDownload(@RequestBody @Valid ClearDateDto dto) {
        return sandPayService.clearFileDownload(dto);
    }
}
