package com.xy.anpei.admin.business.dto.unit.coach;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 16:09
 */
@Data
public class CoachIdNoDto {

    /**
     * 身份证号
     */
    @NotBlank(message = "身份证号不能为空")
    private String idNo;
}
