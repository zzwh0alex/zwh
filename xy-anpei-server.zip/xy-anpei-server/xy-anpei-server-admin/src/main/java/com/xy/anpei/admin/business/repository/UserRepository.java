package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.entity.User;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 15:59
 */
@Repository
public interface UserRepository extends MyRepository<User, String> {
}
