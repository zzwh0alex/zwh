package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.unit.unit.UnitDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitNoDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitQueryDto;
import com.xy.anpei.base.business.domain.entity.Unit;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 09:49
 */
public interface UnitService {

    /**
     * 获取可用的机构列表
     *
     * @return 可用的机构列表
     */
    Object getAvailableUnits();

    /**
     * 分页获取机构信息
     *
     * @param dto UnitQueryDto
     * @return 机构信息
     */
    Object getUnits(UnitQueryDto dto);

    /**
     * 根据机构编号获取机构详细信息
     *
     * @param dto UnitNoDto
     * @return 机构详细信息
     */
    Object getUnitDetail(UnitNoDto dto);

    /**
     * 添加机构
     *
     * @param dto UnitDto
     */
    void add(UnitDto dto);

    /**
     * 更新机构
     *
     * @param dto UnitDto
     */
    void update(UnitDto dto);

    /**
     * （软）删除机构
     *
     * @param dto UnitNoDto
     */
    void delete(UnitNoDto dto);

    /**
     * 根据机构编号获取机构信息
     *
     * @param unitNo 机构编号
     * @return Unit
     */
    Unit getByUnitNo(String unitNo);
}
