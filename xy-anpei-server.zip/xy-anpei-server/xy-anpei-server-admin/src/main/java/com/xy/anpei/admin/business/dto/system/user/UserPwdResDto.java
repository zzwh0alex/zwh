package com.xy.anpei.admin.business.dto.system.user;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 17:03
 */
@Data
public class UserPwdResDto {

    /**
     * 账号 ID
     */
    @NotBlank(message = "账号ID不能为空")
    private String userId;

    /**
     * 管理密码
     */
    @NotBlank(message = "管理密码不能为空")
    private String adminPwd;

    /**
     * 新密码
     */
    @NotBlank(message = "新密码不能为空")
    private String newPwd;

    /**
     * 确认密码
     */
    @NotBlank(message = "确认密码不能为空")
    private String checkPwd;
}
