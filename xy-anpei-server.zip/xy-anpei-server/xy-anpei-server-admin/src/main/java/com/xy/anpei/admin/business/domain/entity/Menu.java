package com.xy.anpei.admin.business.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.business.domain.entity.parent.BasicEntity;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 14:52
 */
@Getter
@Setter
@Entity
@Table(name = "sys_menu")
public class Menu extends BasicEntity implements Serializable {

    /**
     * 菜单 ID
     */
    @Id
    @Column(name = "menu_id")
    private String menuId;

    /**
     * 菜单名称
     */
    @Column(name = "menu_name")
    private String menuName;

    /**
     * 菜单路径
     */
    @Column(name = "menu_path")
    private String path;

    /**
     * 菜单级别
     */
    @Column(name = "menu_level")
    private Integer level;

    /**
     * 菜单状态
     * 0-停用；1-启用
     */
    @JsonIgnore
    @Column(name = "menu_status")
    private Integer status;

    /**
     * ElementUI 图标名称
     */
    @Column(name = "icon_cls")
    private String iconCls;

    /**
     * Vue 组件名称
     */
    @Column(name = "vue_component")
    private String vueComponent;

    /**
     * 父菜单 ID
     */
    @JsonIgnore
    @Column(name = "parent_id")
    private String parentId;

    /**
     * 显示顺序
     */
    @JsonIgnore
    @Column(name = "display_order")
    private Integer displayOrder;

    /**
     * 权限 ID
     */
    @JsonIgnore
    @Column(name = "auth_id")
    private String authId;

    /**
     * 子菜单
     */
    @Transient
    private List<Menu> children;

    /**
     * 获取菜单状态的中文描述
     *
     * @return 菜单状态的中文描述
     */
    @JsonIgnore
    public String getStatusDesc() {
        String statusDesc = "";
        if (MyConst.STATUS_ENABLED.equals(this.status)) {
            statusDesc = "启用";
        } else if (MyConst.STATUS_DISABLED.equals(this.status)) {
            statusDesc = "停用";
        }
        return statusDesc;
    }
}
