package com.xy.anpei.admin.business.dto.order;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-07-14 09:14
 */
@Data
public class RefundDto {

    /**
     * 商户单号
     */
    @NotBlank(message = "商户单号不能为空")
    private String orderCode;

    /**
     * 退款原因
     */
    private String refundReason;
}
