package com.xy.anpei.admin.business.service;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.admin.business.domain.entity.User;
import com.xy.anpei.admin.util.SecurityUtil;
import com.xy.anpei.base.business.domain.entity.parent.BasicEntity;
import com.xy.anpei.base.business.domain.entity.parent.DeletableEntity;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.util.JpaUtil;
import com.xy.anpei.base.util.MyUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.lang.reflect.Method;
import java.util.*;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 11:01
 */
public abstract class AbstractService {

    /**
     * 获取当前用户
     *
     * @return User
     */
    protected User getCurrUser() {
        return SecurityUtil.getCurrUser();
    }

    /**
     * 获取当前用户 ID
     *
     * @return 当前用户 ID
     */
    protected String getCurrUserId() {
        return getCurrUser().getUserId();
    }

    /**
     * 获取密码编码器
     *
     * @return PasswordEncoder
     */
    protected PasswordEncoder getPasswordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    /**
     * 填充创建信息
     *
     * @param entity BasicEntity
     */
    protected void doCreate(BasicEntity entity) {
        entity.setCreateUser(getCurrUserId());
        entity.setCreateTime(new Date());
    }

    /**
     * 填充更新信息
     *
     * @param entity BasicEntity
     */
    protected void doUpdate(BasicEntity entity) {
        entity.setUpdateUser(getCurrUserId());
        entity.setUpdateTime(new Date());
    }

    /**
     * 填充删除信息
     *
     * @param entity DeletableEntity
     */
    protected void doDelete(DeletableEntity entity) {
        entity.setDeleteFlag(MyConst.DELETED);
        entity.setDeleteUser(getCurrUserId());
        entity.setDeleteTime(new Date());
    }

    /**
     * 根据查询条件分页查询数据
     *
     * @param myRepository MyRepository
     * @param queryObj     查询过滤条件
     * @param fields       字段集
     * @param <T>          泛型
     * @return Map<String, Object>
     */
    protected <T> Map<String, Object> getPage(MyRepository<T, ?> myRepository, Object queryObj, String... fields) {
        // 获取分页数据
        Page<T> page = JpaUtil.getPage(myRepository, queryObj);

        // 封装返回参数
        Map<String, Object> retMap = new LinkedHashMap<>();
        // 当前页数
        retMap.put("pageNum", page.getNumber() + 1);
        // 分页大小
        retMap.put("pageSize", page.getSize());
        // 当前页记录数
        retMap.put("numberOfElements", page.getNumberOfElements());
        // 总页数
        retMap.put("totalPages", page.getTotalPages());
        // 总记录数
        retMap.put("totalElements", page.getTotalElements());
        // 是否第一页
        retMap.put("isFirst", page.isFirst());
        // 是否最后一页
        retMap.put("isLast", page.isLast());
        // 分页数据
        retMap.put("content", fields.length == 0 ? page.getContent() : getWarpContent(page.getContent(), fields));

        return retMap;
    }

    /**
     * 封装分页数据
     *
     * @param content 分页数据
     * @param fields  字段集
     * @param <T>     泛型
     * @return 封装后的分页数据
     */
    private <T> Object getWarpContent(List<T> content, String... fields) {
        List<Map<String, Object>> list = new ArrayList<>(content.size());

        // 参数可通过英文冒号分隔，冒号前为实例字段名，冒号后为接口字段名
        String fieldSeparator = ":";
        Map<String, String> fieldMap = new LinkedHashMap<>(fields.length);
        for (String field : fields) {
            if (StringUtils.contains(field, fieldSeparator)) {
                String[] split = field.split(fieldSeparator);
                fieldMap.put(split[1], MyUtil.getMethodName(split[0]));
            } else {
                fieldMap.put(field, MyUtil.getMethodName(field));
            }
        }
        content.forEach(t -> {
            Map<String, Object> map = new LinkedHashMap<>(fields.length);
            Class<?> clazz = t.getClass();
            fieldMap.forEach((field, methodName) -> {
                try {
                    Method method = clazz.getMethod(methodName);
                    Class<?> returnType = method.getReturnType();
                    Object value = method.invoke(t);
                    if (String.class.isAssignableFrom(returnType)) {
                        map.put(field, StringUtils.defaultIfBlank((String) value, ""));
                    } else if (Date.class.isAssignableFrom(returnType)) {
                        map.put(field, MyUtil.formatTime((Date) value));
                    } else {
                        map.put(field, value);
                    }
                } catch (Exception ignored) {
                }
            });
            list.add(map);
        });

        return JSONUtil.parseArray(MyUtil.toJsonStr(list));
    }

    /**
     * Bean 转 Map
     *
     * @param obj    Object
     * @param fields 字段集
     * @return Map<String, Object>
     */
    protected Map<String, Object> beanToMap(Object obj, String... fields) {
        Map<String, Object> map = new LinkedHashMap<>(fields.length);
        if (null == obj || fields.length == 0) {
            return map;
        }
        Class<?> clazz = obj.getClass();
        for (String field : fields) {
            try {
                Method method = clazz.getMethod(MyUtil.getMethodName(field));
                Class<?> returnType = method.getReturnType();
                Object value = method.invoke(obj);
                if (String.class.isAssignableFrom(returnType)) {
                    map.put(field, StringUtils.defaultIfBlank((String) value, ""));
                } else if (Date.class.isAssignableFrom(returnType)) {
                    map.put(field, MyUtil.formatTime((Date) value));
                } else {
                    map.put(field, value);
                }
            } catch (Exception ignored) {
            }
        }
        return map;
    }
}
