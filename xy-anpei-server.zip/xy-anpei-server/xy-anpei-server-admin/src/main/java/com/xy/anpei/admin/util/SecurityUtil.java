package com.xy.anpei.admin.util;

import com.xy.anpei.admin.business.domain.entity.User;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * Security 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-06-28 11:00
 */
public class SecurityUtil {

    /**
     * 获取当前用户
     *
     * @return User
     */
    public static User getCurrUser() {
        return (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    /**
     * 获取当前用户 ID
     *
     * @return 当前用户 ID
     */
    public static String getCurrUserId() {
        return getCurrUser().getUserId();
    }
}
