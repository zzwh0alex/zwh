package com.xy.anpei.admin.business.controller.unit;

import com.xy.anpei.admin.business.dto.unit.unit.UnitDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitNoDto;
import com.xy.anpei.admin.business.dto.unit.unit.UnitQueryDto;
import com.xy.anpei.admin.business.service.UnitService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 11:54
 */
@RestController
@RequestMapping("/unit")
public class UnitController {

    private final UnitService unitService;

    public UnitController(UnitService unitService) {
        this.unitService = unitService;
    }

    @PreAuthorize("hasAuthority('unit.manage.query')")
    @GetMapping(value = "/getAllUnits", name = "获取所有启用的机构信息")
    public Object getAllUnits() {
        return unitService.getAvailableUnits();
    }

    @PreAuthorize("hasAuthority('unit.manage.query')")
    @PostMapping(value = "/getUnits", name = "分页获取机构信息")
    public Object getUnits(@RequestBody @Valid UnitQueryDto dto) {
        return unitService.getUnits(dto);
    }

    @PreAuthorize("hasAuthority('unit.manage.query')")
    @PostMapping(value = "/getUnitDetail", name = "获取机构详细信息")
    public Object getUnitDetail(@RequestBody @Valid UnitNoDto dto) {
        return unitService.getUnitDetail(dto);
    }

    @PreAuthorize("hasAuthority('unit.manage.add')")
    @PostMapping(value = "/add", name = "添加机构信息")
    public void add(@RequestBody @Valid UnitDto dto) {
        unitService.add(dto);
    }

    @PreAuthorize("hasAuthority('unit.manage.update')")
    @PostMapping(value = "/update", name = "更新机构信息")
    public void update(@RequestBody @Valid UnitDto dto) {
        unitService.update(dto);
    }

    @PreAuthorize("hasAuthority('unit.manage.delete')")
    @PostMapping(value = "/delete", name = "删除机构信息")
    public void delete(@RequestBody @Valid UnitNoDto dto) {
        unitService.delete(dto);
    }
}
