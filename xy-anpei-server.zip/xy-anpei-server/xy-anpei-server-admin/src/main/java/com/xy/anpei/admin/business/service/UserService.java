package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.domain.entity.User;
import com.xy.anpei.admin.business.dto.system.user.*;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:12
 */
public interface UserService {

    /**
     * 根据用户 ID 获取用户信息
     *
     * @param userId 用户 ID
     * @return User
     */
    User getByUserId(String userId);

    /**
     * 根据查询条件分页获取用户信息
     *
     * @param dto UserQueryDto
     * @return Object
     */
    Object getPageUsers(UserQueryDto dto);

    /**
     * 获取用户关联的角色
     *
     * @param dto UserIdDto
     * @return Object
     */
    Object getUserRoles(UserIdDto dto);

    /**
     * 新增用户
     *
     * @param dto UserAddDto
     */
    void add(UserAddDto dto);

    /**
     * 更新用户
     *
     * @param dto UserUpdDto
     */
    void update(UserUpdDto dto);

    /**
     * 删除用户
     *
     * @param dto UserIdDto
     */
    void delete(UserIdDto dto);

    /**
     * 修改账号密码
     *
     * @param dto UserPwdResDto
     */
    void changePassword(UserPwdChgDto dto);

    /**
     * 重置账号密码
     *
     * @param dto UserPwdResDto
     */
    void resetPassword(UserPwdResDto dto);
}
