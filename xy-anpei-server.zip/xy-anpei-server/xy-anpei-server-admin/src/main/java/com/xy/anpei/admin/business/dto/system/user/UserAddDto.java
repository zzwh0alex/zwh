package com.xy.anpei.admin.business.dto.system.user;

import lombok.Data;

import javax.validation.constraints.*;
import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 16:35
 */
@Data
public class UserAddDto {

    /**
     * 用户 ID
     */
    @NotBlank(message = "用户账号不能为空")
    private String userId;

    /**
     * 用户名称
     */
    @NotBlank(message = "用户名称不能为空")
    private String userName;

    /**
     * 身份证号
     */
    private String idNo;

    /**
     * 手机号码
     */
    @Pattern(regexp = "^$|^1[3-9]\\d{9}$", message = "手机号码格式不正确")
    private String phone;

    /**
     * 性别
     * 0-未知；1-男；2-女
     */
    @Min(value = 0, message = "性别不正确")
    @Max(value = 2, message = "性别不正确")
    private Integer gender;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @NotNull(message = "账号状态不能为空")
    @Min(value = 0, message = "账号状态不正确")
    @Max(value = 1, message = "账号状态不正确")
    private Integer status;

    /**
     * 账号密码
     */
    @NotBlank(message = "账号密码不能为空")
    private String password;

    /**
     * 角色 ID 列表
     */
    private Set<String> roleIds;
}
