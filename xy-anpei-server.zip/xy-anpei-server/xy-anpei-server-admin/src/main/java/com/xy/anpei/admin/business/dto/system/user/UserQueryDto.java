package com.xy.anpei.admin.business.dto.system.user;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 16:44
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "createTime", direction = SortExp.Direction.DESC))
public class UserQueryDto extends MyPage {

    /**
     * 用户 ID
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String userId;

    /**
     * 用户名称
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE, alias = "name")
    private String userName;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @Min(value = 0, message = "账号状态不正确")
    @Max(value = 1, message = "账号状态不正确")
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer status;
}
