package com.xy.anpei.admin.business.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 15:29
 */
@Getter
@Setter
@Entity
@Table(name = "sys_auth")
public class Auth implements Serializable {

    /**
     * 权限 ID
     */
    @Id
    @Column(name = "auth_id")
    private String authId;

    /**
     * 权限名称
     */
    @Column(name = "auth_name")
    private String authName;

    /**
     * 权限级别
     */
    @Column(name = "auth_level")
    private Integer level;

    /**
     * 权限状态
     * 0-停用；1-启用
     */
    @JsonIgnore
    @Column(name = "auth_status")
    private Integer status;

    /**
     * 父权限 ID
     */
    @JsonIgnore
    @Column(name = "parent_id")
    private String parentId;

    /**
     * 依赖权限 ID
     */
    @JsonIgnore
    @Column(name = "dependent_id")
    private String dependentId;

    /**
     * 显示顺序
     */
    @JsonIgnore
    @Column(name = "display_order")
    private Integer displayOrder;

    /**
     * 子权限
     */
    @Transient
    private List<Auth> children;

    /**
     * 获取权限状态的中文描述
     *
     * @return 权限状态的中文描述
     */
    @JsonIgnore
    public String getStatusDesc() {
        String statusDesc = "";
        if (MyConst.STATUS_ENABLED.equals(this.status)) {
            statusDesc = "启用";
        } else if (MyConst.STATUS_DISABLED.equals(this.status)) {
            statusDesc = "停用";
        }
        return statusDesc;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Auth auth = (Auth) o;
        return authId.equals(auth.authId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(authId);
    }
}
