package com.xy.anpei.admin.business.dto.system.user;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-06-29 15:23
 */
@Data
public class UserPwdChgDto {

    /**
     * 当前密码
     */
    @NotBlank(message = "当前密码不能为空")
    private String currPwd;

    /**
     * 新密码
     */
    @NotBlank(message = "新密码不能为空")
    private String newPwd;

    /**
     * 确认密码
     */
    @NotBlank(message = "确认密码不能为空")
    private String checkPwd;
}
