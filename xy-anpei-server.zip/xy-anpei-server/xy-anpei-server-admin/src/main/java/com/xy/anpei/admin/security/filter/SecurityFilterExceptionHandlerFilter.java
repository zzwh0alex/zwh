package com.xy.anpei.admin.security.filter;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.local.ResultLocal;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.response.Result;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.web.firewall.RequestRejectedException;
import org.springframework.util.StopWatch;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * SecurityFilterExceptionHandler 过滤器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 18:18
 */
@Slf4j
public class SecurityFilterExceptionHandlerFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        StopWatch watch = new StopWatch();
        Result failure = Result.failure();
        try {
            watch.start();
            filterChain.doFilter(request, response);
            if (StringUtils.endsWith(request.getRequestURI(), AdminConst.URL_LOGIN)) {
                this.printLog(request, ResultLocal.getResult(), watch);
                ResultLocal.removeResult();
            } else {
                watch.stop();
            }
        } catch (BusinessException be) {
            failure = Result.failure(be.getResult(), be.getMessage());
            this.printLog(request, failure, watch);
            this.doResponse(response, failure);
        } catch (RequestRejectedException rre) {
            failure = Result.failure(Response.METHOD_NOT_SUPPORTED, rre.getMessage());
            this.printLog(request, failure, watch);
            this.doResponse(response, failure);
        } catch (Exception e) {
            log.error("服务异常！", e);
            this.printLog(request, failure, watch);
            this.doResponse(response, failure);
        }
    }

    /**
     * 打印日志
     *
     * @param request HttpServletRequest
     * @param result  Result
     * @param watch   StopWatch
     */
    private void printLog(HttpServletRequest request, Result result, StopWatch watch) {
        // 停止计时
        watch.stop();
        // 从缓存中获取请求参数
        String reqBody = (String) request.getSession().getAttribute(AdminConst.SESSION_REQUEST_PARAMS);
        // 清除缓存
        request.getSession().removeAttribute(AdminConst.SESSION_REQUEST_PARAMS);
        if (JSONUtil.isTypeJSON(reqBody)) {
            reqBody = JSONUtil.toJsonStr(JSONUtil.parseObj(reqBody));
        }
        // 请求的 URI
        String uri = request.getRequestURI();
        // 请求的 IP
        String ip = StringUtils.defaultIfBlank(request.getHeader(MyConst.HEADER_REAL_IP), "%");
        if (result.getCode() == 0) {
            // 从左到右依次是：URI、IP、耗时、请求参数、应答数据
            log.info("{}, {}, {}ms, reqBody:{}, respBody:{}",
                    uri, ip, watch.getTotalTimeMillis(), reqBody, MyUtil.toJsonStr(result));
        } else {
            // 从左到右依次是：提示信息、URI、IP、耗时、请求参数、应答数据
            log.info("[{}] {}, {}, {}ms, reqBody:{}, respBody:{}",
                    result.getMsg(), uri, ip, watch.getTotalTimeMillis(), reqBody, MyUtil.toJsonStr(result));
        }
    }

    /**
     * 响应请求
     *
     * @param response HttpServletResponse
     * @param result   Result
     */
    private void doResponse(HttpServletResponse response, Result result) {
        String retJson = JSONUtil.toJsonStr(result);
        try {
            response.setContentType(AdminConst.RESPONSE_CONTENT_TYPE);
            response.getWriter().write(retJson);
        } catch (IOException e) {
            log.error("响应客户端时发生异常！retJson={}", retJson, e);
        }
    }
}
