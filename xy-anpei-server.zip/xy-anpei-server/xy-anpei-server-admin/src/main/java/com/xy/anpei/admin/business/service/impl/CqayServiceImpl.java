package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.dto.thirdparty.CqayUpdDto;
import com.xy.anpei.admin.business.service.CqayService;
import com.xy.anpei.admin.business.service.TrainRegistrationService;
import com.xy.anpei.admin.business.service.UnitService;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.util.cqay.CqayUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-07-19 10:57
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class CqayServiceImpl implements CqayService {

    private final TrainRegistrationService trainRegistrationService;

    private final UnitService unitService;

    public CqayServiceImpl(TrainRegistrationService trainRegistrationService,
                           UnitService unitService) {
        this.trainRegistrationService = trainRegistrationService;
        this.unitService = unitService;
    }

    @Override
    public void update(CqayUpdDto dto) {
        TrainRegistration tr = trainRegistrationService.getByTrainId(dto.getTrainId());

        Map<String, Object> data = new HashMap<>(8);
        data.put("areaCode", String.valueOf(tr.getAreaCode()));
        data.put("trainId", tr.getTrainId());
        if (StringUtils.isNotBlank(dto.getUnitNo())) {
            Unit unit = unitService.getByUnitNo(dto.getUnitNo());
            data.put("unitNo", unit.getUnitNo());
            data.put("unitName", unit.getFullName());
        }
        if (StringUtils.isNotBlank(dto.getPhoto())) {
            data.put("photo", dto.getPhoto());
        }
        if (Boolean.TRUE.equals(dto.getIsDelete())) {
            data.put("deleteStatus", "1");
        }

        CqayUtil.update(data);
    }

    @Override
    public Object queryStorage() {
        return CqayUtil.queryStorage();
    }
}
