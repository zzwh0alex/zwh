package com.xy.anpei.admin.security.config;

import com.xy.anpei.admin.security.filter.MyUsernamePasswordAuthenticationFilter;
import com.xy.anpei.admin.security.handler.LoginFailureHandler;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.HttpSecurityBuilder;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;

/**
 * 登录配置类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 18:15
 */
public class LoginConfig<T extends LoginConfig<T, B>, B extends HttpSecurityBuilder<B>> extends AbstractHttpConfigurer<T, B> {

    private final MyUsernamePasswordAuthenticationFilter authFilter;

    public LoginConfig() {
        this.authFilter = new MyUsernamePasswordAuthenticationFilter();
    }

    @Override
    public void configure(B builder) {
        authFilter.setAuthenticationManager(builder.getSharedObject(AuthenticationManager.class));
        authFilter.setAuthenticationFailureHandler(new LoginFailureHandler());
        authFilter.setSessionAuthenticationStrategy(new NullAuthenticatedSessionStrategy());

        MyUsernamePasswordAuthenticationFilter filter = postProcess(authFilter);
        builder.addFilterBefore(filter, LogoutFilter.class);
    }

    public LoginConfig<T, B> authenticationSuccessHandler(AuthenticationSuccessHandler authSuccessHandler) {
        authFilter.setAuthenticationSuccessHandler(authSuccessHandler);
        return this;
    }
}
