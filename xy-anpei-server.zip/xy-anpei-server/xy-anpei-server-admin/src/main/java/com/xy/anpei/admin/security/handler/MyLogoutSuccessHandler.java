package com.xy.anpei.admin.security.handler;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 登出成功处理器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 18:09
 */
public class MyLogoutSuccessHandler implements LogoutSuccessHandler {

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        // 返回成功
        throw new BusinessException(Response.SUCCESS);
    }
}
