package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.thirdparty.CqayUpdDto;

/**
 * @author Chen Guibiao
 * Create at 2023-07-19 10:57
 */
public interface CqayService {

    /**
     * 教练信息修改
     *
     * @param dto CqayUpdDto
     */
    void update(CqayUpdDto dto);

    /**
     * 查询虚拟卡使用情况
     *
     * @return Object
     */
    Object queryStorage();
}
