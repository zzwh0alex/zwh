package com.xy.anpei.admin.business.dto.unit.coach;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 16:17
 */
@Data
public class CoachPwdDto {

    /**
     * 身份证号
     */
    @NotBlank(message = "身份证号不能为空")
    private String idNo;

    /**
     * 密码
     */
    @NotBlank(message = "密码不能为空")
    private String password;
}
