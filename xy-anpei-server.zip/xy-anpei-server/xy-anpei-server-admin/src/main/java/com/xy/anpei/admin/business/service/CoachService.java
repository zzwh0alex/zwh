package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.unit.coach.CoachDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachIdNoDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachPwdDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachQueryDto;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 11:21
 */
public interface CoachService {

    /**
     * 分页获取教练员信息
     *
     * @param dto CoachQueryDto
     * @return 教练员信息
     */
    Object getCoachs(CoachQueryDto dto);

    /**
     * 根据身份证号获取教练员详细信息
     *
     * @param dto CoachIdNoDto
     * @return 教练员详细信息
     */
    Object getCoachDetail(CoachIdNoDto dto);

    /**
     * 添加教练员信息
     *
     * @param dto CoachDto
     */
    void add(CoachDto dto);

    /**
     * 更新教练员信息
     *
     * @param dto CoachDto
     */
    void update(CoachDto dto);

    /**
     * 更新教练员信息（不包含照片）
     *
     * @param dto CoachDto
     */
    void updateText(CoachDto dto);

    /**
     * 删除教练员信息
     *
     * @param dto CoachIdNoDto
     */
    void delete(CoachIdNoDto dto);

    /**
     * 重置密码
     *
     * @param dto CoachPwdDto
     */
    void resetPassword(CoachPwdDto dto);
}
