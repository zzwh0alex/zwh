package com.xy.anpei.admin.business.dto.unit.coach;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 15:55
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "registrationTime", direction = SortExp.Direction.DESC))
public class CoachQueryDto extends MyPage {

    /**
     * 培训机构全国统一编号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String unitNo;

    /**
     * 教练员姓名
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String coachName;

    /**
     * 身份证号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String idNo;
}
