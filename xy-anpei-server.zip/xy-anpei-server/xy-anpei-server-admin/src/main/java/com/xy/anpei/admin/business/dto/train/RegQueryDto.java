package com.xy.anpei.admin.business.dto.train;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

/**
 * @author Chen Guibiao
 * Create at 2023-07-10 17:28
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "createTime", direction = SortExp.Direction.DESC))
public class RegQueryDto extends MyPage {

    /**
     * 培训机构全国统一编号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String unitNo;

    /**
     * 教练员姓名
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE)
    private String coachName;

    /**
     * 身份证号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String idNo;

    /**
     * 培训年度
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer trainYear;

    /**
     * 商户订单号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String orderCode;

    /**
     * 支付状态
     * 0-待支付；1-支付成功；2-支付失败
     */
    @Min(value = 0, message = "支付状态不正确")
    @Max(value = 2, message = "支付状态不正确")
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer payStatus;
}
