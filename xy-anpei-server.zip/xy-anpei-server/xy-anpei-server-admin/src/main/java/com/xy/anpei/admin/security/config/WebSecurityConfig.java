package com.xy.anpei.admin.security.config;

import com.xy.anpei.admin.business.service.UserService;
import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.security.config.jwt.JwtAuthenticationProvider;
import com.xy.anpei.admin.security.config.jwt.JwtConfig;
import com.xy.anpei.admin.security.filter.OptionsRequestFilter;
import com.xy.anpei.admin.security.filter.SecurityFilterExceptionHandlerFilter;
import com.xy.anpei.admin.security.handler.JwtSuccessHandler;
import com.xy.anpei.admin.security.handler.LoginSuccessHandler;
import com.xy.anpei.admin.security.handler.MyLogoutSuccessHandler;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.header.Header;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.web.filter.CorsFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Security 配置类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 18:16
 */
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private final UserService userService;

    public WebSecurityConfig(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void configure(WebSecurity web) {
        // 放行指定请求
        List<String> permittedRequests = new ArrayList<>();
        permittedRequests.add(AdminConst.URL_CAPTCHA);
        permittedRequests.add(AdminConst.URL_CATEGORY_HELPER);
        web.ignoring().antMatchers(permittedRequests.toArray(new String[0]));
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                // 任何请求都需要认证
                .anyRequest().authenticated()
                .and()
                // 禁用 CRSF，因为不使用 session
                .csrf().disable()
                // 禁用 session
                .sessionManagement().disable()
                // 禁用匿名用户
                .anonymous().disable()
                // 禁用表单登录
                .formLogin().disable()
                // 支持跨域
                .cors()
                .and()
                // 添加 request header 设置，支持跨域和 ajax 请求
                .headers().addHeaderWriter(
                new StaticHeadersWriter(Arrays.asList(
                        new Header("Access-control-Allow-Origin", "*"),
                        new Header("Access-Control-Expose-Headers", AdminConst.HEADER_AUTHORIZATION)
                )))
                .and()
                // 过滤 OPTIONS 请求，直接返回 header
                .addFilterAfter(new OptionsRequestFilter(), CorsFilter.class)
                // 登录配置
                .apply(new LoginConfig<>()).authenticationSuccessHandler(new LoginSuccessHandler())
                .and()
                // JWT 配置
                .apply(new JwtConfig<>()).authenticationSuccessHandler(new JwtSuccessHandler())
                .and()
                // 使用默认的 LogoutFilter
                .logout()
                .logoutSuccessHandler(new MyLogoutSuccessHandler());
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());

        auth.authenticationProvider(provider).authenticationProvider(new JwtAuthenticationProvider());
    }

    @Override
    protected UserDetailsService userDetailsService() {
        return username -> (UserDetails) userService.getByUserId(username);
    }

    @Bean
    public FilterRegistrationBean<SecurityFilterExceptionHandlerFilter> filterRegistrationBean() {
        FilterRegistrationBean<SecurityFilterExceptionHandlerFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new SecurityFilterExceptionHandlerFilter());
        // 任何接口路径都要执行
        bean.addUrlPatterns("/*");
        // 优先级最高
        bean.setOrder(Integer.MIN_VALUE);
        return bean;
    }
}
