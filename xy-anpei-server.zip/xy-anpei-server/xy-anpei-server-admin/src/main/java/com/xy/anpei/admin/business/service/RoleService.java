package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.domain.entity.Role;
import com.xy.anpei.admin.business.dto.system.role.RoleIdDto;
import com.xy.anpei.admin.business.dto.system.role.RoleDto;
import com.xy.anpei.admin.business.dto.system.role.RoleQueryDto;

import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 17:31
 */
public interface RoleService {

    /**
     * 根据角色 ID 集获取角色信息
     *
     * @param roleIds 角色 ID 集
     * @return a set of Role
     */
    Set<Role> getRolesByRoleIds(Set<String> roleIds);

    /**
     * 根据查询条件分页获取系统角色信息
     *
     * @param dto RoleQueryDto
     * @return Object
     */
    Object getSysRoles(RoleQueryDto dto);

    /**
     * 获取角色关联的权限
     *
     * @param dto RoleIdDto
     * @return Object
     */
    Object getRoleAuths(RoleIdDto dto);

    /**
     * 新增权限
     *
     * @param dto RoleDto
     */
    void add(RoleDto dto);

    /**
     * 更新权限
     *
     * @param dto RoleDto
     */
    void update(RoleDto dto);

    /**
     * 删除权限
     *
     * @param dto RoleIdDto
     */
    void delete(RoleIdDto dto);
}
