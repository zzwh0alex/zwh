package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.dto.train.CertQueryDto;
import com.xy.anpei.admin.business.repository.ViewCertificateRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.TrainCertificateService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 14:51
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class TrainCertificateServiceImpl extends AbstractService implements TrainCertificateService {

    private final ViewCertificateRepository viewCertificateRepository;

    public TrainCertificateServiceImpl(ViewCertificateRepository viewCertificateRepository) {
        this.viewCertificateRepository = viewCertificateRepository;
    }

    @Override
    public Object getCertificates(CertQueryDto dto) {
        String[] fileds = {"trainId", "trainYear", "unitNo", "unitName", "unitFullName", "coachName", "idNo", "certUrl", "createTime"};
        return getPage(viewCertificateRepository, dto, fileds);
    }
}
