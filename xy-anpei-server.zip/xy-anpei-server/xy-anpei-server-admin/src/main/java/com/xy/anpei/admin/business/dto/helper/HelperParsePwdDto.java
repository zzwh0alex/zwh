package com.xy.anpei.admin.business.dto.helper;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-07-03 17:15
 */
@Data
public class HelperParsePwdDto {

    /**
     * 鉴权码
     */
    @NotBlank(message = "鉴权码不能为空")
    private String auth;

    /**
     * 密码
     */
    @NotNull(message = "目标参数不能为空")
    private String password;
}
