package com.xy.anpei.admin.business.dto.home;

import lombok.Data;

/**
 * @author Chen Guibiao
 * Create at 2023-06-27 17:58
 */
@Data
public class CaptchaDto {

    /**
     * 验证码长度
     */
    private Integer length;

    /**
     * 验证码图片宽度
     */
    private Integer width;

    /**
     * 验证码图片高度
     */
    private Integer height;
}
