package com.xy.anpei.admin.business.dto.system.role;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 16:58
 */
@Data
public class RoleIdDto {

    /**
     * 角色 ID
     */
    @NotBlank(message = "角色ID不能为空")
    private String roleId;
}
