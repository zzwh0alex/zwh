package com.xy.anpei.admin.local;

import com.xy.anpei.base.response.Result;

/**
 * @author Chen Guibiao
 * Create at 2023-06-27 16:06
 */
public class ResultLocal {

    private static final ThreadLocal<Result> RESULT_LOCAL = new ThreadLocal<>();

    /**
     * 获取返回数据
     *
     * @return Result
     */
    public static Result getResult() {
        return RESULT_LOCAL.get();
    }

    /**
     * 缓存返回数据
     *
     * @param result Result
     */
    public static void setResult(Result result) {
        RESULT_LOCAL.set(result);
    }

    /**
     * 清除返回数据
     */
    public static void removeResult() {
        RESULT_LOCAL.remove();
    }
}
