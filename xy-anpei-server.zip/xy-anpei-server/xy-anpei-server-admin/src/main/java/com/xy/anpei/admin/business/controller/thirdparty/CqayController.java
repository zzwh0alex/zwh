package com.xy.anpei.admin.business.controller.thirdparty;

import com.xy.anpei.admin.business.dto.thirdparty.CqayUpdDto;
import com.xy.anpei.admin.business.service.CqayService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-19 09:22
 */
@RestController
@RequestMapping("/cqay")
public class CqayController {

    private final CqayService cqayService;

    public CqayController(CqayService cqayService) {
        this.cqayService = cqayService;
    }

    @PreAuthorize("hasAuthority('cqay.update.submit')")
    @PostMapping(value = "/update", name = "教练信息更新")
    public void update(@RequestBody @Valid CqayUpdDto dto) {
        cqayService.update(dto);
    }

    @PreAuthorize("hasAuthority('cqay.storage.query')")
    @GetMapping(value = "/queryStorage", name = "查询虚拟卡使用情况")
    public Object queryStorage() {
        return cqayService.queryStorage();
    }
}
