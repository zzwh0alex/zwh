package com.xy.anpei.admin.business.dto.region;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:44
 */
@Data
public class ProvinceDto {

    /**
     * 省行政区划唯一标识
     */
    @NotNull(message = "省区划代码不能为空")
    private Integer provinceId;
}
