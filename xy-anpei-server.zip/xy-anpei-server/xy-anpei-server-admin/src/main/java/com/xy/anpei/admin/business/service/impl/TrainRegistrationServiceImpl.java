package com.xy.anpei.admin.business.service.impl;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import com.xy.anpei.admin.business.domain.model.ViewRegistration;
import com.xy.anpei.admin.business.dto.train.RegQueryDto;
import com.xy.anpei.admin.business.repository.ViewRegistrationRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.TrainRegistrationService;
import com.xy.anpei.admin.config.AdminConfig;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.repository.TrainRegistrationRepository;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-07-07 16:18
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class TrainRegistrationServiceImpl extends AbstractService implements TrainRegistrationService {

    private final AdminConfig adminConfig;

    private final TrainRegistrationRepository trainRegistrationRepository;

    private final ViewRegistrationRepository viewRegistrationRepository;

    public TrainRegistrationServiceImpl(AdminConfig adminConfig,
                                        TrainRegistrationRepository trainRegistrationRepository,
                                        ViewRegistrationRepository viewRegistrationRepository) {
        this.adminConfig = adminConfig;
        this.trainRegistrationRepository = trainRegistrationRepository;
        this.viewRegistrationRepository = viewRegistrationRepository;
    }

    @Override
    public Object getRegistrations(RegQueryDto dto) {
        String[] fileds = {"trainId", "trainYear", "cityId", "cityFullName", "unitNo", "unitName", "unitFullName", "coachName",
                "idNo", "phone", "photo", "orderCode", "totalAmount", "tradeNo", "payStatus", "payStatusDesc", "payTime",
                "refundOrderCode", "refundAmount", "refundTime", "createTime"};
        Map<String, Object> page = getPage(viewRegistrationRepository, dto, fileds);
        ((JSONArray) page.get("content")).forEach(obj -> {
            JSONObject jsonObj = (JSONObject) obj;
            String photo = String.valueOf(jsonObj.get("photo"));
            if (StringUtils.isNotBlank(photo)) {
                jsonObj.set("photo", adminConfig.getRegisterPhotoUrl() + photo.replace(File.separator, "/"));
            }
        });
        return page;
    }

    @Override
    public TrainRegistration getByTrainId(String trainId) {
        return trainRegistrationRepository.findByTrainId(trainId)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在注册记录[%s]", trainId)));
    }

    @Override
    public TrainRegistration getByOrderCode(String orderCode) {
        return trainRegistrationRepository.findByOrderCode(orderCode)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在订单[%s]", orderCode)));
    }

    @Override
    public void save(TrainRegistration registration) {
        trainRegistrationRepository.save(registration);
    }
}
