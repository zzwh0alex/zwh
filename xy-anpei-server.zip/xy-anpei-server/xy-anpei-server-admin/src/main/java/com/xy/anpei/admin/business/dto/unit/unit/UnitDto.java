package com.xy.anpei.admin.business.dto.unit.unit;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 14:38
 */
@Data
public class UnitDto {

    /**
     * 培训机构全国统一编号
     */
    @NotBlank(message = "机构编号不能为空")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @NotBlank(message = "机构简称不能为空")
    private String unitName;

    /**
     * 培训机构全称
     */
    @NotBlank(message = "机构全称不能为空")
    private String fullName;

    /**
     * 培训机构地址
     */
    private String address;

    /**
     * 邮政编码
     */
    private String postalCode;

    /**
     * 所属省
     */
    @NotNull(message = "所属省区划代码不能为空")
    private Integer provinceId;

    /**
     * 所属市
     */
    @NotNull(message = "所属市区划代码不能为空")
    private Integer cityId;

    /**
     * 所属区/县
     */
    @NotNull(message = "所属区/县区划代码不能为空")
    private Integer districtId;

    /**
     * 经营许可证编号
     */
    private String businessLicenseNo;

    /**
     * 经营许可日期
     */
    private String businessLicenseDate;

    /**
     * 营业执照注册号
     */
    private String businessLicenseRegNo;

    /**
     * 经营范围
     */
    private String businessScope;

    /**
     * 统一社会信用代码
     */
    private String unifiedSocialCreditCode;

    /**
     * 法人代表
     */
    private String legalPerson;

    /**
     * 联系电话
     */
    private String contactNumber;

    /**
     * 显示顺序
     */
    private Integer displayOrder;
}
