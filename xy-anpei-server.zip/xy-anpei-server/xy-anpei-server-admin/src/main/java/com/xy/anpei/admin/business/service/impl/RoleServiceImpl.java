package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.domain.entity.Auth;
import com.xy.anpei.admin.business.domain.entity.Role;
import com.xy.anpei.admin.business.dto.system.role.RoleIdDto;
import com.xy.anpei.admin.business.dto.system.role.RoleDto;
import com.xy.anpei.admin.business.dto.system.role.RoleQueryDto;
import com.xy.anpei.admin.business.repository.RoleRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.AuthService;
import com.xy.anpei.admin.business.service.RoleService;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 17:31
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class RoleServiceImpl extends AbstractService implements RoleService {

    private final RoleRepository roleRepository;

    private final AuthService authService;

    public RoleServiceImpl(RoleRepository roleRepository, AuthService authService) {
        this.roleRepository = roleRepository;
        this.authService = authService;
    }

    @Override
    public Set<Role> getRolesByRoleIds(Set<String> roleIds) {
        Set<Role> roles = new HashSet<>();
        if (CollectionUtils.isEmpty(roleIds)) {
            return roles;
        }
        roles = roleRepository.findByRoleIdIn(roleIds);
        if (CollectionUtils.isEmpty(roles)) {
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在角色[%s]", roleIds));
        }
        // 若角色集合元素个数与 roleIds 的个数不一致，也提示错误
        if (roles.size() != roleIds.size()) {
            Set<String> resultIds = roles.stream().map(Role::getRoleId).collect(Collectors.toSet());
            roleIds.removeAll(resultIds);
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在角色[%s]", roleIds));
        }
        return roles;
    }

    @Override
    public Object getSysRoles(RoleQueryDto dto) {
        String[] fileds = {"roleId", "roleName", "roleDesc", "userCount", "createUser", "createTime", "updateUser", "updateTime"};
        return getPage(roleRepository, dto, fileds);
    }

    @Override
    public Object getRoleAuths(RoleIdDto dto) {
        Role role = this.getByRoleId(dto.getRoleId());
        Set<String> authIds = role.getAuthorities().stream().map(Auth::getAuthId).collect(Collectors.toSet());
        return authService.getHierarchyAuthsByAuthIds(authIds);
    }

    @Override
    public void add(RoleDto dto) {
        roleRepository.findById(dto.getRoleId()).ifPresent(r -> {
            throw new BusinessException(Response.DATA_ALREADY_EXISTS, String.format("已存在角色[%s]", dto.getRoleId()));
        });
        Role role = this.fillRole(new Role(), dto);
        doCreate(role);
        roleRepository.save(role);
    }

    @Override
    public void update(RoleDto dto) {
        Role role = this.fillRole(this.getByRoleId(dto.getRoleId()), dto);
        doUpdate(role);
        roleRepository.save(role);
    }

    @Override
    public void delete(RoleIdDto dto) {
        Role role = this.getByRoleId(dto.getRoleId());
        Integer userCount = role.getUserCount();
        if (null != userCount && userCount > 0) {
            throw new BusinessException(Response.PARAM_ERROR, String.format("目前仍有[%s]个用户关联此角色", userCount));
        }
        roleRepository.delete(role);
    }

    /**
     * 填充角色信息
     *
     * @param role Role
     * @param dto  RoleDto
     * @return Role
     */
    private Role fillRole(Role role, RoleDto dto) {
        // 查询权限
        Set<Auth> authorities = authService.getByAuthIds(dto.getAuthIds());
        // 封装信息
        role.setRoleId(dto.getRoleId());
        role.setRoleName(StringUtils.deleteWhitespace(dto.getRoleName()));
        role.setRoleDesc(dto.getRoleDesc());
        role.setAuthorities(authorities);
        return role;
    }

    /**
     * 根据角色 ID 获取角色信息
     *
     * @param roleId 角色 ID
     * @return Role
     */
    private Role getByRoleId(String roleId) {
        return roleRepository.findById(roleId)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在角色[%s]", roleId)));
    }
}
