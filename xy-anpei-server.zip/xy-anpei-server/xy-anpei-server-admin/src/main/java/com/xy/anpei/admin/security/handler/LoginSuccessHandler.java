package com.xy.anpei.admin.security.handler;

import cn.hutool.extra.spring.SpringUtil;
import com.xy.anpei.admin.business.service.AuthService;
import com.xy.anpei.admin.local.ResultLocal;
import com.xy.anpei.base.response.Result;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 登录成功处理器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:51
 */
@Slf4j
public class LoginSuccessHandler extends CommonSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException {
        addTokenToHeader(response);
        Result success = Result.success(SpringUtil.getBean(AuthService.class).getUserAuths());
        ResultLocal.setResult(success);
        response.getWriter().write(MyUtil.toJsonStr(success));
    }
}
