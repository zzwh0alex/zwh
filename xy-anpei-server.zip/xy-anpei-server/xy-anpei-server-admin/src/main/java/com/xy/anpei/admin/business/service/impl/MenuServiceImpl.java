package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.domain.entity.Auth;
import com.xy.anpei.admin.business.domain.entity.Menu;
import com.xy.anpei.admin.business.dto.system.menu.MenuIdDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuQueryDto;
import com.xy.anpei.admin.business.repository.MenuRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.AuthService;
import com.xy.anpei.admin.business.service.MenuService;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 10:57
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class MenuServiceImpl extends AbstractService implements MenuService {

    private final MenuRepository menuRepository;

    private final AuthService authService;

    public MenuServiceImpl(MenuRepository menuRepository, AuthService authService) {
        this.menuRepository = menuRepository;
        this.authService = authService;
    }

    @Override
    public List<Menu> getUserMenus() {
        List<Menu> userMenus = new ArrayList<>();
        // 获取当前用户的权限
        Set<String> authIds = authService.getUserAuthIds();
        // 查找权限对应的菜单
        this.getAvailableMenus().forEach(menu -> {
            if (authIds.contains(menu.getAuthId())) {
                userMenus.add(menu);
            }
        });
        // 返回具有层次结构的菜单列表
        return this.getHierarchyMenus(userMenus);
    }

    @Override
    public Object getSysMenus(MenuQueryDto dto) {
        String[] fileds = {"menuId", "menuName", "path", "level", "status", "statusDesc", "iconCls", "vueComponent",
                "parentId", "displayOrder", "authId", "createUser", "createTime", "updateUser", "updateTime"};
        return getPage(menuRepository, dto, fileds);
    }

    @Override
    public void add(MenuDto dto) {
        menuRepository.findById(dto.getMenuId()).ifPresent(m -> {
            throw new BusinessException(Response.DATA_ALREADY_EXISTS, String.format("已存在菜单[%s]", m.getMenuId()));
        });
        Menu menu = this.fillMenu(new Menu(), dto);
        doCreate(menu);
        menuRepository.save(menu);
    }

    @Override
    public void update(MenuDto dto) {
        Menu menu = this.fillMenu(this.getByMenuId(dto.getMenuId()), dto);
        doUpdate(menu);
        menuRepository.save(menu);
    }

    @Override
    public void delete(MenuIdDto dto) {
        // TODO 级联删除
    }

    /**
     * 填充菜单信息
     *
     * @param menu Menu
     * @param dto  MenuDto
     * @return Menuthis.getAvailableAuths()
     */
    private Menu fillMenu(Menu menu, MenuDto dto) {
        if (StringUtils.isNotBlank(dto.getParentId())) {
            Menu parentMenu = this.getByMenuId(dto.getParentId());
            menu.setParentId(StringUtils.deleteWhitespace(parentMenu.getMenuId()));
        }
        if (StringUtils.isNotBlank(dto.getAuthId())) {
            Auth auth = authService.getByAuthId(dto.getAuthId());
            menu.setAuthId(auth.getAuthId());
        }
        menu.setMenuId(dto.getMenuId());
        menu.setMenuName(StringUtils.deleteWhitespace(dto.getMenuName()));
        menu.setPath(StringUtils.deleteWhitespace(dto.getPath()));
        menu.setLevel(dto.getLevel());
        menu.setStatus(dto.getStatus());
        menu.setIconCls(StringUtils.deleteWhitespace(dto.getIconCls()));
        menu.setDisplayOrder(dto.getDisplayOrder());
        return menu;
    }

    /**
     * 根据菜单 ID 获取菜单信息
     *
     * @param menuId 菜单 ID
     * @return Menu
     */
    private Menu getByMenuId(String menuId) {
        return menuRepository.findById(menuId)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在菜单[%s]", menuId)));
    }

    /**
     * 获取可用的菜单
     *
     * @return a list of Menu
     */
    private List<Menu> getAvailableMenus() {
        // 查询并返回启用的菜单
        return menuRepository.findByStatusOrderByDisplayOrder(MyConst.STATUS_ENABLED);
    }

    /**
     * 获取所有的菜单
     *
     * @return a list of Menu
     */
    private List<Menu> getAllMenus() {
        // 获取所有的菜单
        List<Menu> availableMenus = menuRepository.findAll(Sort.by("displayOrder"));
        // 返回具有层次结构的菜单列表
        return this.getHierarchyMenus(availableMenus);
    }

    /**
     * 获取具有层次结构的菜单列表
     *
     * @param menus List<Menu>
     * @return 具有层次结构的菜单列表
     */
    private List<Menu> getHierarchyMenus(List<Menu> menus) {
        List<Menu> hierarchyMenus = new ArrayList<>();
        // 若菜单列表不空，则设置菜单层级
        if (!CollectionUtils.isEmpty(menus)) {
            Map<String, Menu> tempMap = new HashMap<>(menus.size());
            // 设置一级菜单
            menus.forEach(menu -> {
                if (null == menu.getParentId()) {
                    hierarchyMenus.add(menu);
                }
                // 初始化子菜单
                menu.setChildren(new ArrayList<>());
                // 缓存各实例供后续使用
                tempMap.put(menu.getMenuId(), menu);
            });
            // 设置各级子菜单
            menus.forEach(menu -> {
                if (StringUtils.isNotBlank(menu.getParentId())) {
                    tempMap.get(menu.getParentId()).getChildren().add(menu);
                }
            });
        }
        // 返回
        return hierarchyMenus;
    }
}
