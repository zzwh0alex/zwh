package com.xy.anpei.admin.business.controller.system;

import com.xy.anpei.admin.business.dto.system.role.RoleIdDto;
import com.xy.anpei.admin.business.dto.system.role.RoleDto;
import com.xy.anpei.admin.business.dto.system.role.RoleQueryDto;
import com.xy.anpei.admin.business.service.RoleService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-04 09:53
 */
@RestController
@RequestMapping("/role")
public class RoleController {

    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @PreAuthorize("hasAuthority('system.role.query')")
    @PostMapping(value = "/getSysRoles", name = "获取系统角色信息")
    public Object getSysRoles(@RequestBody RoleQueryDto dto) {
        return roleService.getSysRoles(dto);
    }

    @PreAuthorize("hasAuthority('system.role.query')")
    @PostMapping(value = "/getRoleAuths", name = "获取角色权限信息")
    public Object getRoleAuths(@RequestBody @Valid RoleIdDto dto) {
        return roleService.getRoleAuths(dto);
    }

    @PreAuthorize("hasAuthority('system.role.add')")
    @PostMapping(value = "/add", name = "添加系统角色")
    public void add(@RequestBody @Valid RoleDto dto) {
        roleService.add(dto);
    }

    @PreAuthorize("hasAuthority('system.role.update')")
    @PostMapping(value = "/update", name = "更新系统角色")
    public void update(@RequestBody @Valid RoleDto dto) {
        roleService.update(dto);
    }

    @PreAuthorize("hasAuthority('system.role.delete')")
    @PostMapping(value = "/delete", name = "删除系统角色")
    public void delete(@RequestBody @Valid RoleIdDto dto) {
        roleService.delete(dto);
    }
}
