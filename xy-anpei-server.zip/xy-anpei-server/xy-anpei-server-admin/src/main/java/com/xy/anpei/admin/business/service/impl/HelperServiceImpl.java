package com.xy.anpei.admin.business.service.impl;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.admin.business.dto.helper.HelperGenPwdDto;
import com.xy.anpei.admin.business.dto.helper.HelperParsePwdDto;
import com.xy.anpei.admin.business.service.HelperService;
import com.xy.anpei.admin.util.RsaUtil;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-06-28 09:19
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class HelperServiceImpl implements HelperService {

    @Override
    public Object generatePassword(HelperGenPwdDto dto) {
        this.verify("生成密码", dto);
        return RsaUtil.generatePassword(dto.getPassword());
    }

    @Override
    public Object parsePassword(HelperParsePwdDto dto) {
        this.verify("解析密码", dto);
        return RsaUtil.parsePassword(dto.getPassword());
    }

    /**
     * 校验请求参数
     *
     * @param requestType 请求类型描述
     * @param dto         请求参数
     */
    private void verify(String requestType, Object dto) {
        // 对象转 JSON
        JSONObject jsonObj = JSONUtil.parseObj(dto);
        // 格式化日志
        String format = String.format("【%s】{}！reqBody:%s", requestType, jsonObj);
        // 生成鉴权码
        String authCode = generateAuthCode();
        // 鉴权
        if (!StringUtils.equals(authCode, (String) jsonObj.get("auth"))) {
            log.info(format, "鉴权失败！authCode=" + authCode);
            throw new BusinessException(Response.PARAM_ERROR);
        }
    }

    /**
     * 生成鉴权码
     *
     * @return 鉴权码
     */
    private String generateAuthCode() {
        String date = MyUtil.formatTime(new Date(), MyConst.FORMAT_YMD);
        String[] split = date.split("-");
        String year = split[0];
        int month = Integer.parseInt(split[1]);
        int day = Integer.parseInt(split[2]);
        return year + month * month + day * day;
    }
}
