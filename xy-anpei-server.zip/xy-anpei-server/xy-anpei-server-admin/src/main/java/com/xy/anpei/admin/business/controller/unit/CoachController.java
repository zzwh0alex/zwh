package com.xy.anpei.admin.business.controller.unit;

import com.xy.anpei.admin.business.dto.unit.coach.CoachDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachIdNoDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachPwdDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachQueryDto;
import com.xy.anpei.admin.business.service.CoachService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 11:21
 */
@RestController
@RequestMapping("/coach")
public class CoachController {

    private final CoachService coachService;

    public CoachController(CoachService coachService) {
        this.coachService = coachService;
    }

    @PreAuthorize("hasAuthority('coach.manage.query')")
    @PostMapping(value = "/getCoachs", name = "分页获取教练信息")
    public Object getCoachs(@RequestBody @Valid CoachQueryDto dto) {
        return coachService.getCoachs(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.query')")
    @PostMapping(value = "/getCoachDetail", name = "获取教练详细信息")
    public Object getCoachDetail(@RequestBody @Valid CoachIdNoDto dto) {
        return coachService.getCoachDetail(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.add')")
    @PostMapping(value = "/add", name = "添加教练信息")
    public void add(@Valid CoachDto dto) {
        coachService.add(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.update')")
    @PostMapping(value = "/update", name = "修改教练信息")
    public void update(@Valid CoachDto dto) {
        coachService.update(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.update')")
    @PostMapping(value = "/updateText", name = "修改教练信息")
    public void updateText(@RequestBody @Valid CoachDto dto) {
        coachService.updateText(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.delete')")
    @PostMapping(value = "/delete", name = "删除教练信息")
    public void delete(@RequestBody @Valid CoachIdNoDto dto) {
        coachService.delete(dto);
    }

    @PreAuthorize("hasAuthority('coach.manage.update')")
    @PostMapping(value = "/resetPassword", name = "重置教练密码")
    public void resetPassword(@RequestBody @Valid CoachPwdDto dto) {
        coachService.resetPassword(dto);
    }
}
