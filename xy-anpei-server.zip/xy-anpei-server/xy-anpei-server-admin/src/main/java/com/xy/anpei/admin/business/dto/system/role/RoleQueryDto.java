package com.xy.anpei.admin.business.dto.system.role;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 16:45
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "createTime", direction = SortExp.Direction.DESC))
public class RoleQueryDto extends MyPage {

    /**
     * 角色 ID
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String roleId;

    /**
     * 角色名称
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE)
    private String roleName;
}
