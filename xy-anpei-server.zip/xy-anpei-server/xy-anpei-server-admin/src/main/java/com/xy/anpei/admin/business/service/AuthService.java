package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.domain.entity.Auth;

import java.util.List;
import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 11:24
 */
public interface AuthService {

    /**
     * 根据权限 ID 获取权限信息
     *
     * @param authId 权限 ID
     * @return Auth
     */
    Auth getByAuthId(String authId);

    /**
     * 根据权限 ID 集获取权限信息
     *
     * @param authIds 权限 ID 集
     * @return a set of Auth
     */
    Set<Auth> getByAuthIds(Set<String> authIds);

    /**
     * 获取所有可用的权限
     *
     * @return Object
     */
    Object getSysAuths();

    /**
     * 获取用户权限 ID 集
     *
     * @return a set of String
     */
    Set<String> getUserAuthIds();

    /**
     * 获取用户权限
     *
     * @return a list of Auth
     */
    List<Auth> getUserAuths();

    /**
     * 根据子权限获取具有层次结构的权限列表
     *
     * @param authIds 权限 ID 集
     * @return a list of Auth
     */
    List<Auth> getHierarchyAuthsByAuthIds(Set<String> authIds);
}
