package com.xy.anpei.admin.business.dto.order;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-07-13 14:55
 */
@Data
public class ClearDateDto {

    /**
     * 交易日期（yyyyMMdd）
     */
    @NotBlank(message = "交易日期不能为空")
    @Pattern(regexp = "^((\\d{3}[1-9]|\\d{2}[1-9]\\d|\\d[1-9]\\d{2}|[1-9]\\d{3})(((0[13578]|1[02])(0[1-9]|[12]\\d|3[01]))|((0[469]|11)(0[1-9]|[12]\\d|30))|(02(0[1-9]|[1]\\d|2[0-8]))))|(((\\d{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))0229)$", message = "交易日期格式不正确")
    private String clearDate;
}
