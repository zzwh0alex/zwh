package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.order.ClearDateDto;
import com.xy.anpei.admin.business.dto.order.OrderCodeDto;
import com.xy.anpei.admin.business.dto.order.RefundDto;

/**
 * @author Chen Guibiao
 * Create at 2023-07-13 14:38
 */
public interface SandPayService {

    /**
     * 订单查询
     *
     * @param dto OrderCodeDto
     * @return 订单详情
     */
    Object orderQuery(OrderCodeDto dto);

    /**
     * 申请退款
     *
     * @param dto RefundDto
     * @return 杉德申请退款响应参数
     */
    Object orderRefund(RefundDto dto);

    /**
     * 对账单下载
     *
     * @param dto ClearDateDto
     * @return 文件下载地址
     */
    Object clearFileDownload(ClearDateDto dto);
}
