package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.train.CertQueryDto;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 14:51
 */
public interface TrainCertificateService {

    /**
     * 分页获取结业证信息
     *
     * @param dto CertQueryDto
     * @return 结业证信息
     */
    Object getCertificates(CertQueryDto dto);
}
