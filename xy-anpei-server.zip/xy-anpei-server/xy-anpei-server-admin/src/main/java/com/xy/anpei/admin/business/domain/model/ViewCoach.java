package com.xy.anpei.admin.business.domain.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.xy.anpei.base.business.domain.entity.parent.DeletableEntity;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 11:32
 */
@Getter
@Setter
@Entity
@Table(name = "view_coach")
public class ViewCoach extends DeletableEntity implements Serializable {

    /**
     * 教练员 ID
     */
    @Id
    @Column(name = "coach_id")
    private Integer coachId;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 培训机构 ID
     */
    @Column(name = "unit_id")
    private Integer unitId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "unit_full_name")
    private String unitFullName;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 联系地址
     */
    @Column(name = "address")
    private String address;

    /**
     * 个人照片相对路径
     */
    @Column(name = "photo_path")
    private String photo;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @Column(name = "status")
    private Integer status;

    /**
     * 注册时间
     */
    @Column(name = "registration_time")
    @JsonFormat(pattern = MyConst.FORMAT_YMDHMS, timezone = "GMT+8")
    private Date registrationTime;

    /**
     * 微信小程序用户 openId
     */
    @Column(name = "open_id")
    private String openId;

    /**
     * 获取账号状态的中文描述
     *
     * @return 账号状态的中文描述
     */
    public String getStatusDesc() {
        String statusDesc = "";
        if (MyConst.STATUS_ENABLED.equals(this.status)) {
            statusDesc = "启用";
        } else if (MyConst.STATUS_DISABLED.equals(this.status)) {
            statusDesc = "停用";
        }
        return statusDesc;
    }
}
