package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.dto.region.CityDto;
import com.xy.anpei.admin.business.dto.region.ProvinceDto;
import com.xy.anpei.admin.business.service.RegionService;
import com.xy.anpei.base.business.domain.entity.City;
import com.xy.anpei.base.business.domain.entity.District;
import com.xy.anpei.base.business.domain.entity.Province;
import com.xy.anpei.base.business.repository.CityRepository;
import com.xy.anpei.base.business.repository.DistrictRepository;
import com.xy.anpei.base.business.repository.ProvinceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:47
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class RegionServiceImpl implements RegionService {

    private final ProvinceRepository provinceRepository;

    private final CityRepository cityRepository;

    private final DistrictRepository districtRepository;

    public RegionServiceImpl(ProvinceRepository provinceRepository,
                             CityRepository cityRepository,
                             DistrictRepository districtRepository) {
        this.provinceRepository = provinceRepository;
        this.cityRepository = cityRepository;
        this.districtRepository = districtRepository;
    }

    @Override
    public List<Province> getProvinces() {
        return provinceRepository.findAll();
    }

    @Override
    public List<City> getCities(ProvinceDto dto) {
        return cityRepository.findByParentId(dto.getProvinceId());
    }

    @Override
    public List<District> getDistricts(CityDto dto) {
        return districtRepository.findByParentId(dto.getCityId());
    }
}
