package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.domain.entity.Menu;
import com.xy.anpei.admin.business.dto.system.menu.MenuIdDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuDto;
import com.xy.anpei.admin.business.dto.system.menu.MenuQueryDto;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 10:57
 */
public interface MenuService {

    /**
     * 获取当前用户的菜单列表
     *
     * @return a list of Menu
     */
    List<Menu> getUserMenus();

    /**
     * 根据查询条件分页获取系统菜单信息
     *
     * @param dto MenuQueryDto
     * @return Object
     */
    Object getSysMenus(MenuQueryDto dto);

    /**
     * 新增菜单
     *
     * @param dto MenuDto
     */
    void add(MenuDto dto);

    /**
     * 更新菜单
     *
     * @param dto MenuDto
     */
    void update(MenuDto dto);

    /**
     * 删除菜单
     *
     * @param dto MenuIdDto
     */
    void delete(MenuIdDto dto);
}
