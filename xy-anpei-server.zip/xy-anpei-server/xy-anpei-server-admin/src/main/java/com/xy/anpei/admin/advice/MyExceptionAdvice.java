package com.xy.anpei.admin.advice;

import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.response.Result;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:18
 */
@RestControllerAdvice
public class MyExceptionAdvice {

    /**
     * UsernameNotFoundException 异常处理器
     *
     * @param unfe UsernameNotFoundException
     * @return json
     */
    @ExceptionHandler(UsernameNotFoundException.class)
    public Result usernameNotFoundExceptionHandler(UsernameNotFoundException unfe) {
        return Result.failure(Response.DATA_NOT_FOUND, unfe.getMessage());
    }
}
