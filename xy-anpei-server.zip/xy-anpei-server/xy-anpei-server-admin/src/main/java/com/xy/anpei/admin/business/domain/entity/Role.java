package com.xy.anpei.admin.business.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.business.domain.entity.parent.BasicEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;
import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 15:26
 */
@Getter
@Setter
@Entity
@Table(name = "sys_role")
public class Role extends BasicEntity implements Serializable {

    /**
     * 角色 ID
     */
    @Id
    @Column(name = "role_id")
    private String roleId;

    /**
     * 角色名称
     */
    @Column(name = "role_name")
    private String roleName;

    /**
     * 角色描述
     */
    @JsonIgnore
    @Column(name = "role_desc")
    private String roleDesc;

    /**
     * 关联用户记数
     */
    @JsonIgnore
    @Column(name = "user_count")
    private Integer userCount;

    /**
     * 角色关联的权限
     */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "sys_role_auth",
            joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "auth_id", referencedColumnName = "auth_id")
    )
    private Set<Auth> authorities;

    /**
     * 关联用户记数 +1
     */
    public void increase() {
        this.userCount++;
    }

    /**
     * 关联用户记数 -1
     */
    public void decrease() {
        this.userCount--;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Role role = (Role) o;
        return roleId.equals(role.roleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roleId);
    }
}
