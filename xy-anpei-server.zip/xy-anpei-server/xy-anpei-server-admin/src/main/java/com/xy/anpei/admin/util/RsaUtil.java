package com.xy.anpei.admin.util;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RSA 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 16:40
 */
@Slf4j
public class RsaUtil {

    /**
     * 字符串分隔符
     */
    public static final String STRING_SEPARATOR = ":";

    /**
     * 公钥键名
     */
    private static final String PUBLIC_KEY = "public_key";

    /**
     * 公钥键名
     */
    private static final String PRIVATE_KEY = "private_key";

    /**
     * Key map
     */
    private static final ConcurrentHashMap<String, Object> KEY = new ConcurrentHashMap<>();

    /**
     * 算法名称
     */
    public static final String ALGORITHM = "RSA";

    /**
     * RSA 公钥
     */
    public static final String CONTENT_PUBLIC_KEY = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAqT9TFXvI1oU5FcY7HbIn" +
            "fdh09Xyqdi865huQMw5NOwbYEFkr4X2Q08ZwCFxa3FL+3bBCNa2NmCD7QE2/us62" +
            "dkhLhb31rZMQMCQ06XXrPp9O1qHDxaAcBzyRkAfabXK1h4b9ipJK9d56MXy79/Zn" +
            "3kN6m58bZhhAx8rvOHIisGZr67CIE8ft4Nr5FoGQJRUowSxCzcntcjvX+O5Vt3BD" +
            "j45DT+nTCzfPj4Kk2j04GuAsc9YAxnkP/rGVa9rCTdM8H2iVVt7feW76bc7uApdH" +
            "VF1fReiqA1R/RfkM7yjoe+LScZcgFCjUrWmBrcB50elPiSw0/kG9hlN61CgtIUx3" +
            "iKOTIBXCIt1xgn6jquwNTWogcYq+5pjJ0INQFoKpBQdZnvNxLs1a2FbSP+rfrw9G" +
            "pEXbX+O6V2yeUp9tTZ2TLB+AEXJepij2OYysvzZdBam2/5At/yxznK1sfknlf+k2" +
            "HmXH4OSj2JSAQTXulthZtBE10N1WMvdpXg/KYhq/osxuOOQlDgzfaKHCp7ZtO1Wv" +
            "EhtuP3ym8RbdUb+OcxCGbWZoiZBov8sG3pb+tTa7FQ8248Csl9rQEgzk8z7AMeZ0" +
            "ORLjBLkJOuW/fcbPgJvYDKP8SfUXFlN+LQafalzFiyNHtyiEknIIGOIcmRgqv1Vr" +
            "3ojn34L6BQ+IvGOr/77quy0CAwEAAQ==";

    /**
     * RSA 私钥
     */
    public static final String CONTENT_PRIVATE_KEY = "MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQCpP1MVe8jWhTkV" +
            "xjsdsid92HT1fKp2LzrmG5AzDk07BtgQWSvhfZDTxnAIXFrcUv7dsEI1rY2YIPtA" +
            "Tb+6zrZ2SEuFvfWtkxAwJDTpdes+n07WocPFoBwHPJGQB9ptcrWHhv2Kkkr13nox" +
            "fLv39mfeQ3qbnxtmGEDHyu84ciKwZmvrsIgTx+3g2vkWgZAlFSjBLELNye1yO9f4" +
            "7lW3cEOPjkNP6dMLN8+PgqTaPTga4Cxz1gDGeQ/+sZVr2sJN0zwfaJVW3t95bvpt" +
            "zu4Cl0dUXV9F6KoDVH9F+QzvKOh74tJxlyAUKNStaYGtwHnR6U+JLDT+Qb2GU3rU" +
            "KC0hTHeIo5MgFcIi3XGCfqOq7A1NaiBxir7mmMnQg1AWgqkFB1me83EuzVrYVtI/" +
            "6t+vD0akRdtf47pXbJ5Sn21NnZMsH4ARcl6mKPY5jKy/Nl0Fqbb/kC3/LHOcrWx+" +
            "SeV/6TYeZcfg5KPYlIBBNe6W2Fm0ETXQ3VYy92leD8piGr+izG445CUODN9oocKn" +
            "tm07Va8SG24/fKbxFt1Rv45zEIZtZmiJkGi/ywbelv61NrsVDzbjwKyX2tASDOTz" +
            "PsAx5nQ5EuMEuQk65b99xs+Am9gMo/xJ9RcWU34tBp9qXMWLI0e3KISScggY4hyZ" +
            "GCq/VWveiOffgvoFD4i8Y6v/vuq7LQIDAQABAoICAFHtIV7I6NNO8e8kYgFh99Pn" +
            "L9aVXj6PZkd1GDxes+vayERBpgglLDIXYKvraOA2HMFbTPGG7X+yl2ztNd5Lqe9f" +
            "148KAR7gjXmATUyllBZgL12eOJI1itvF6gB6jLVmTZEpOxoU7sxNwYCrDKJfWLAy" +
            "oesq/axSGSmdhmcgeMJDEgKpFXXd1bx+wwyt8wTAVVYNAtly4cnmRglt9Xgyk8Gt" +
            "78+DNHG9tm+Vog8yizIXSe1Yrk9k0uVLOTVYU64wjm31xjSi9jJmEjuNa5E9gX3J" +
            "JRFGKuYpxOIuSKCMgN1XUt9BdHnNugWniOp+vXlrIuEX0R8y23dmeZKxUAdKaKGm" +
            "YrRmM2ptElD9YO5SmnG47uJNRgaMeTBfApHRATH1dRbAxmkDwhXfZEVt6JB8mYXd" +
            "UsK8/xjsgDly/+s4nOFjq8fJT9Co+RRz3kQIvjkHsSDYzU0Ne0TRqXZcn8qkbgVX" +
            "XU8B3Mt+p+d3rDYX+OsdWWcsd+0BNhwBbYB0p3sUYwzbh7ZDJIiRFiYb2j6uAP9t" +
            "xS/59wwcVGcsyD2Y2pP8VDcziNlLaTaqe7q/uwGGIKl7fn4ioCE59WwVYzhVDbTK" +
            "CGvp2GEdQXiqkPskOH9k6zALj8PD/9ScL5jPXQw8OKsKjzjJgR5IUtALCK/R+t0V" +
            "qb2n/R5vW1/5rS295BnRAoIBAQDTC7XuvLLjj8n2dcn5+eifc8L4+jt3ZiptE5zD" +
            "ZWIqNJulwhAg5tTzsqMHuAmUlOOaFpzZ/U9vckSRQeTtixE82ncj+mT6GBCS9EJs" +
            "ucmIo0TfRUI6lphTjItp6HD2YbnbhgBwmi7enrKvNd3kBZeGfd98rLiXYK8SZehg" +
            "JXT+6rOPjT3cMnTVCeISY9xRgeKjrZEOAYvU+ZZiLQ2RjQUpDN1Z2WU++YMsPkSH" +
            "uOkfDK4Gk9bLX1nxSPpvhP8Td9m9iC1pc8sKDErQPUGAzdQWUGELLg2WlPbBwrhL" +
            "N2tlzMM3Ij7b18K47JOOtLpBkpuNNDCQR90lTmCHts/6ohxPAoIBAQDNTFrgn6BT" +
            "QS8HRqvBKvROdl0QrywoyHrMx3Wu+Ln0KrE0Vgyczi+YwL1wSs9/EWfqKF9dQpVv" +
            "p4EJiu9hj+JUQeYvFbSSbsF7t1OC9kXcoSL3jJm9Jm6KHNNaudQSKqiaoiTj4k36" +
            "zOGlhIvcKPZvX+IYRNJ0JogAUVG39LjTsas8mwbQfuS2bYFbFaYXYn9ua1K8ceUN" +
            "dx57b7V5GSFM8mqoX4ruKITM5BkNWBYsYPUKLfrtLLWz0BXF2AaA8zDB/oJV+PWr" +
            "17DAdZoOdEp03GJa6yM9iy4aOHzAx5Uw5oryj2R2YRQj0g5mC7Q7HB4mONZYk5GX" +
            "MXzW2TS2fGXDAoIBADcEnYhAXy5d5NvAd0gYs2EmL5Tyvx/wXW0UKNDzlDTGhDEh" +
            "N00sgCWL016GxtCaQ/9+l6NomxXFp0Rq9kBK+dJwbZDOjRZ5wZBd5xcrE/PwBFtk" +
            "VdCqQ8m8IPgaJaDFd0tYUrMILuHQY2qz00XHg2oHVITPDkxAY0Obl4nBGg/+pZLt" +
            "0kueR8DmE66Ro/UHtErRS7hoBMkfy+mKLzhbmBXMicQLnY5eQ6j8DqeHOBblGlUS" +
            "o3NfRzZUvRznggvUOcpkPtp32l2jOLmyzmnCvuCWUcY1WkuASBfZKGxLZU8jo1yz" +
            "K8nqJJRK8GjKiqffjXexPFvQsEEyfo3CxdNkAZcCggEBAIqBhCJdr3Xb2VWoWUI2" +
            "r6Kr+nfCJyHQuACmZQBKMHLJxsoPb+zusm/1QRmcb0dEP/5bhJNP07ADq2v7vyrs" +
            "Pv8ngpuroirU7FaCRaZqbpG+aO/ofOR/JD6r2fAwxSIIg73nvMm+KWwWg/n+ZbmA" +
            "LVrQrqI+9FmGkWTdeCuKwJOaH3QBB2Ts53MoiAgin+7Q9jZR0/ztPmKKRhdzM1Tj" +
            "HnNibZDw/LNWxNnS3hABqNwCAe//O3Z+HoyUy8uxxhmDeRa4lchY8a4hE8+Ux/4O" +
            "eRlEglrinuDroIvyJkCNplraf03MbjPrpQHRuwMfzFXAz5pr6DjUPnpp2da9rfGc" +
            "Fa8CggEBAMt+UeMACDOYIzAc7th/m6b+1frtsMbaMuuqgd1OgLgjLLjsPSgTYRPL" +
            "uGIjYtxs+FauFnaO55ci7e4BqYATUOETwt98BZmfydGPOHC8YhBz7GNDp974b9NE" +
            "baA1P2whwCQpFjQEiwT3nB51gSbyutbffH/vQf0KPbOdjFX4fx+OtKmxSshleQJy" +
            "sUom5lNLOYr5FqGiOXnxVm4SkhPqklkv2Y0u++skUsWr7p+FUIdIJvuM3pxl0cN+" +
            "zo1wFvoYapqPeZLmhQItLq0QWGTyCR0VYyaIdyq8JC7Oi7zLqRVTk+5nNT9SoRj8" +
            "0b/4h0svJd2Ymw7QgAOKpU/ivJEV4MM=";

    /**
     * RSA 公钥加密
     *
     * @param plaintext 明文
     * @return 密文
     */
    public static String encrypt(String plaintext) {
        String ciphertext;
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, getPublicKey());
            ciphertext = Base64.getEncoder().encodeToString(cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            log.error("RSA加密时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION, "RSA加密时发生异常");
        }
        return ciphertext;
    }

    /**
     * RSA 私钥解密
     *
     * @param ciphertext 密文
     * @return 明文
     */
    public static String decrypt(String ciphertext) {
        String plaintext;
        try {
            byte[] inputByte = Base64.getDecoder().decode(ciphertext.getBytes(StandardCharsets.UTF_8));
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, getPrivateKey());
            plaintext = new String(cipher.doFinal(inputByte));
        } catch (Exception e) {
            log.error("RSA解密时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION, "RSA解密时发生异常");
        }
        return plaintext;
    }

    /**
     * RSA 私钥签名
     *
     * @param plaintext 明文
     * @return 签文
     */
    public static String sign(String plaintext) {
        try {
            Signature privateSignature = getSignature();
            privateSignature.initSign(getPrivateKey());
            privateSignature.update(plaintext.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(privateSignature.sign());
        } catch (Exception e) {
            log.error("RSA签名时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION, "RSA签名时发生异常");
        }
    }

    /**
     * RSA 公钥验证签名
     *
     * @param plaintext 明文
     * @param signature 签文
     * @return 验签结果
     */
    public static boolean verify(String plaintext, String signature) {
        boolean result = false;
        try {
            Signature publicSignature = getSignature();
            publicSignature.initVerify(getPublicKey());
            publicSignature.update(plaintext.getBytes(StandardCharsets.UTF_8));
            byte[] signatureBytes = Base64.getDecoder().decode(signature);
            result = publicSignature.verify(signatureBytes);
        } catch (Exception e) {
            log.error("RSA验签时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION, "RSA验签时发生异常");
        }
        return result;
    }

    /**
     * 获取公钥
     *
     * @return PublicKey
     * @throws Exception Exception
     */
    private static PublicKey getPublicKey() throws Exception {
        PublicKey publicKey = (PublicKey) KEY.get(PUBLIC_KEY);
        if (null == publicKey) {
            byte[] decode = Base64.getDecoder().decode(CONTENT_PUBLIC_KEY);
            publicKey = KeyFactory.getInstance(ALGORITHM).generatePublic(new X509EncodedKeySpec(decode));
            KEY.put(PUBLIC_KEY, publicKey);
        }
        return publicKey;
    }

    /**
     * 获取私钥
     *
     * @return PrivateKey
     * @throws Exception Exception
     */
    private static PrivateKey getPrivateKey() throws Exception {
        PrivateKey privateKey = (PrivateKey) KEY.get(PRIVATE_KEY);
        if (null == privateKey) {
            byte[] decode = Base64.getDecoder().decode(CONTENT_PRIVATE_KEY);
            privateKey = KeyFactory.getInstance(ALGORITHM).generatePrivate(new PKCS8EncodedKeySpec(decode));
            KEY.put(PRIVATE_KEY, privateKey);
        }
        return privateKey;
    }

    /**
     * 获取签名对象
     *
     * @return Signature
     * @throws NoSuchAlgorithmException NoSuchAlgorithmException
     */
    private static Signature getSignature() throws NoSuchAlgorithmException {
        return Signature.getInstance("SHA256withRSA");
    }

    /**
     * 检查并获取密码明文
     *
     * @param ciphertext 密文
     * @return 密码明文
     */
    public static String checkAndGetPwd(String ciphertext) {
        // 解析密码
        Map<String, Object> map = parsePassword(ciphertext);
        // 时间戳
        long timestamp = (long) map.get("timestamp");
        // 密码
        String password = (String) map.get("password");
        // 失效时间：300 秒
        long expire = 300L;
        // 除以 1000 忽略毫秒；求绝对值（即允许请求时间比服务器时间快或慢 expire 秒）
        long difference = Math.abs((System.currentTimeMillis() - timestamp) / 1000);
        if (difference > expire) {
            log.info("密码已过时！createTime={}, plaintext={}", map.get("formatTime"), map.get("plaintext"));
            throw new BusinessException(Response.NO_AUTH);
        }
        return password;
    }

    /**
     * 解析密码
     *
     * @param ciphertext 密文
     * @return Map<String, Object>
     */
    public static Map<String, Object> parsePassword(String ciphertext) {
        String plaintext = null;
        try {
            plaintext = decrypt(ciphertext);
            int index = plaintext.indexOf(STRING_SEPARATOR);
            long timestamp = Long.parseLong(plaintext.substring(0, index));

            Map<String, Object> map = new LinkedHashMap<>(5);
            map.put("ciphertext", ciphertext);
            map.put("plaintext", plaintext);
            map.put("timestamp", timestamp);
            map.put("formatTime", MyUtil.formatTime(timestamp));
            map.put("password", plaintext.substring(index + 1));

            return map;
        } catch (Exception e) {
            log.info("密码解析失败！plaintext={}, ciphertext={}", plaintext, ciphertext);
            throw new BusinessException(Response.PARAM_ERROR, "密码格式不正确");
        }
    }

    /**
     * 生成密码
     *
     * @param plaintext 明文
     * @return 密码
     */
    public static String generatePassword(String plaintext) {
        String format = String.format("%s%s%s", System.currentTimeMillis(), STRING_SEPARATOR, plaintext);
        return encrypt(format);
    }
}
