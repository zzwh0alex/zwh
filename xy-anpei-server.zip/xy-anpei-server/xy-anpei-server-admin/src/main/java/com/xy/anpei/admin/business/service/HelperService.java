package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.helper.HelperGenPwdDto;
import com.xy.anpei.admin.business.dto.helper.HelperParsePwdDto;

/**
 * @author Chen Guibiao
 * Create at 2023-06-28 09:19
 */
public interface HelperService {

    /**
     * 生成密码
     *
     * @param dto HelperGenPwdDto
     * @return 密码
     */
    Object generatePassword(HelperGenPwdDto dto);

    /**
     * 解析密码
     *
     * @param dto HelperParsePwdDto
     * @return 密码
     */
    Object parsePassword(HelperParsePwdDto dto);
}
