package com.xy.anpei.admin.business.dto.region;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:44
 */
@Data
public class CityDto {

    /**
     * 市行政区划唯一标识
     */
    @NotNull(message = "市区划代码不能为空")
    private Integer cityId;
}
