package com.xy.anpei.admin.security.handler;

import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.util.JwtUtil;
import com.xy.anpei.admin.util.SecurityUtil;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import javax.servlet.http.HttpServletResponse;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 17:24
 */
public abstract class CommonSuccessHandler implements AuthenticationSuccessHandler {

    /**
     * 请求响应头添加 Token
     *
     * @param response HttpServletResponse
     */
    protected void addTokenToHeader(HttpServletResponse response) {
        String token = JwtUtil.buildToken(AdminConst.FIELD_USER_ID, SecurityUtil.getCurrUserId());
        response.setHeader(AdminConst.HEADER_AUTHORIZATION, token);
        response.setContentType(AdminConst.RESPONSE_CONTENT_TYPE);
    }
}
