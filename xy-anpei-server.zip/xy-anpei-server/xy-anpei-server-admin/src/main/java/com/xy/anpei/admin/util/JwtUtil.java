package com.xy.anpei.admin.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JWT 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 16:39
 */
public class JwtUtil {

    /**
     * salt
     * <p>
     * salt = MD5(xyap@2023-06-06, 32)
     */
    private static final String TOKEN_SECRET = "47B0A5B8A6B2B144BD9405D91BE14AAA";

    /**
     * 生成 token
     *
     * @param name  键名
     * @param value 键值
     * @return token
     */
    public static String buildToken(String name, String value) {
        Map<String, String> claims = new LinkedHashMap<>(1);
        claims.put(name, value);
        return buildToken(claims);
    }

    /**
     * 生成 token
     *
     * @param claims 自定义属性集
     * @return token
     */
    public static String buildToken(Map<String, String> claims) {
        JWTCreator.Builder builder = JWT.create();
        // 设置自定义属性
        claims.forEach(builder::withClaim);
        // 设置有效期（30 分钟内有效）
        Calendar instance = Calendar.getInstance();
        instance.add(Calendar.SECOND, 60 * 30);
        builder.withExpiresAt(instance.getTime());
        // 使用指定签名算法生成 JWT
        return builder.sign(Algorithm.HMAC256(TOKEN_SECRET));
    }

    /**
     * 校验 token
     *
     * @param token token
     */
    public static void verify(String token) {
        JWT.require(Algorithm.HMAC256(TOKEN_SECRET)).build().verify(token);
    }

    /**
     * 判断 token 是否需要刷新
     *
     * @param token token
     * @return 如果需要刷新则返回 true，否则返回 false
     */
    public static boolean needToRefresh(String token) {
        LocalDateTime expirationTime = LocalDateTime.ofInstant(JWT.decode(token).getExpiresAt().toInstant(), ZoneId.systemDefault());
        // Token 到期前 10 分钟内刷新
        return expirationTime.minusSeconds(60 * 10).isBefore(LocalDateTime.now());
    }

    /**
     * 获取 token 中的自定义属性集合
     *
     * @param token token
     * @return claims
     */
    public static Map<String, Claim> getClaims(String token) {
        return JWT.decode(token).getClaims();
    }

    /**
     * 获取 token 中 key 指定的属性值
     *
     * @param token token
     * @param key   key
     * @return claim
     */
    public static String getClaim(String token, String key) {
        return getClaims(token).get(key).asString();
    }
}
