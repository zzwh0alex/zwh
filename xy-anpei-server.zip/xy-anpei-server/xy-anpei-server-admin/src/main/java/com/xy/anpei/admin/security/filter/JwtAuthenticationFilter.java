package com.xy.anpei.admin.security.filter;

import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.security.config.jwt.JwtAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * JWT 认证过滤器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:35
 */
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private AuthenticationManager authenticationManager;

    private AuthenticationSuccessHandler successHandler;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // 获取请求头中的 token
        String token = request.getHeader(AdminConst.HEADER_AUTHORIZATION);
        // 校验 token
        Authentication authResult = this.authenticationManager.authenticate(new JwtAuthenticationToken(token));
        // 校验通过时的回调
        successHandler.onAuthenticationSuccess(request, response, filterChain, authResult);
    }

    public void setAuthenticationManager(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    public void setAuthenticationSuccessHandler(AuthenticationSuccessHandler successHandler) {
        this.successHandler = successHandler;
    }
}
