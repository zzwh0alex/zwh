package com.xy.anpei.admin.business.service.impl;

import cn.hutool.json.JSONObject;
import com.xy.anpei.admin.business.domain.model.ViewRegistration;
import com.xy.anpei.admin.business.dto.order.ClearDateDto;
import com.xy.anpei.admin.business.dto.order.OrderCodeDto;
import com.xy.anpei.admin.business.dto.order.RefundDto;
import com.xy.anpei.admin.business.service.SandPayService;
import com.xy.anpei.admin.business.service.TrainRegistrationService;
import com.xy.anpei.admin.config.AdminConfig;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.constant.SandPayConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.sandpay.SandPayUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-07-13 14:38
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class SandPayServiceImpl implements SandPayService {

    private final AdminConfig adminConfig;

    private final TrainRegistrationService trainRegistrationService;

    public SandPayServiceImpl(AdminConfig adminConfig, TrainRegistrationService trainRegistrationService) {
        this.adminConfig = adminConfig;
        this.trainRegistrationService = trainRegistrationService;
    }

    @Override
    public Object orderQuery(OrderCodeDto dto) {
        // 检查订单是否存在
        trainRegistrationService.getByOrderCode(dto.getOrderCode());

        // 请求参数
        Map<String, Object> reqMap = new HashMap<>(16);
        // 商户订单号
        reqMap.put("orderCode", dto.getOrderCode());

        // 发送请求，获取响应数据
        JSONObject respData = SandPayUtil.send(SandPayConst.URL_ORDER_QUERY, SandPayConst.METHOD_ORDER_QUERY, reqMap);

        // 响应数据
        Map<String, Object> respMap = new LinkedHashMap<>(32);
        // 原商户订单号
        respMap.put("oriOrderCode", respData.get("oriOrderCode"));
        // 原交易应答码
        respMap.put("oriRespCode", respData.get("oriRespCode"));
        // 原交易应答描述
        respMap.put("oriRespMsg", respData.get("oriRespMsg"));
        // 订单金额
        respMap.put("totalAmount", this.parseToInt(respData.get("totalAmount")));
        // 订单状态
        respMap.put("orderStatus", this.getOrderStatusDesc(respData.get("orderStatus")));
        // 原交易流水号
        respMap.put("oriTradeNo", respData.get("oriTradeNo"));
        // 买家付款金额
        respMap.put("buyerPayAmount", this.parseToInt(respData.get("buyerPayAmount")));
        // 优惠金额
        respMap.put("discAmount", this.parseToInt(respData.get("discAmount")));
        // 应结订单金额
        respMap.put("settleAmount", this.parseToInt(respData.get("settleAmount")));
        // 商户手续费
        respMap.put("midFee", this.parseToInt(respData.get("midFee")));
        // 平台手续费
        respMap.put("plMidFee", this.parseToInt(respData.get("plMidFee")));
        // 节假日手续费
        respMap.put("specialFee", this.parseToInt(respData.get("specialFee")));
        // 额外手续费
        respMap.put("extraFee", this.parseToInt(respData.get("extraFee")));
        // 支付时间
        respMap.put("payTime", this.formatTime(respData.get("payTime")));
        // 通道支付时间
        respMap.put("txnCompleteTime", this.formatTime(respData.get("txnCompleteTime")));
        // 交易日期
        respMap.put("clearDate", this.formatDate(respData.get("clearDate")));
        // 订单状态描述
        respMap.put("orderMsg", respData.get("orderMsg"));
        // 通道订单号
        respMap.put("bankserial", respData.get("bankserial"));
        // 渠道订单号
        respMap.put("payOrderCode", respData.get("payOrderCode"));
        // 付款账号
        respMap.put("accNo", respData.get("accNo"));
        // 产品编号
        respMap.put("externalProductCode", respData.get("externalProductCode"));
        // 支付明细
        respMap.put("payDetail", respData.get("payDetail"));
        // 分账标识
        respMap.put("accsplitFlag", respData.get("accsplitFlag"));
        // 订单分账状态
        respMap.put("multipartyOrderStatus", respData.get("multipartyOrderStatus"));
        // 分账冻结天数
        respMap.put("accsplitFrozenDays", respData.get("accsplitFrozenDays"));
        // 识别码
        respMap.put("remittanceCode", respData.get("remittanceCode"));
        // 付款人用户号
        respMap.put("accLogonNo", respData.get("accLogonNo"));

        return respMap;
    }

    @Override
    public Object orderRefund(RefundDto dto){
        String orderCode = dto.getOrderCode();
        // 检查订单是否存在
        TrainRegistration order = trainRegistrationService.getByOrderCode(orderCode);
        // 判断订单支付状态
        if (!MyConst.PAY_STATUS_SUCCESS.equals(order.getPayStatus())) {
            throw new BusinessException(Response.PARAM_ERROR, String.format("订单[%s]%s，不支持申请退款", orderCode, order.getPayStatusDesc()));
        }
        // 判断是否已退款
        if (StringUtils.isNotBlank(order.getRefundOrderCode())) {
            throw new BusinessException(Response.PARAM_ERROR, String.format("订单[%s]已退款，请勿重复操作", orderCode));
        }

        // 退款订单号
        String refundOrderCode = System.currentTimeMillis() + MyUtil.getRandomNum(3);

        // 请求参数
        Map<String, Object> reqMap = new HashMap<>(16);
        // 商户订单号
        reqMap.put("orderCode", refundOrderCode);
        // 原商户订单号
        reqMap.put("oriOrderCode", orderCode);
        // 退款金额
        reqMap.put("refundAmount", String.format("%012d", order.getTotalAmount()));
        // 异步通知地址
        reqMap.put("notifyUrl", adminConfig.getSandPayRefundNotifyUrl());
        // 退款原因
        reqMap.put("refundReason", StringUtils.isBlank(dto.getRefundReason()) ? "星云安全学习退费" : StringUtils.deleteWhitespace(dto.getRefundReason()));

        // 发送请求，获取响应数据
        JSONObject respData = SandPayUtil.send(SandPayConst.URL_ORDER_REFUND, SandPayConst.METHOD_ORDER_REFUND, reqMap);

        // 退款时间
        String refundTime = this.formatTime(respData.get("refundTime"));

        // 响应数据
        Map<String, Object> respMap = new LinkedHashMap<>(16);
        // 商户订单号（退款单号）
        respMap.put("refundOrderCode", respData.get("orderCode"));
        // 交易流水号
        respMap.put("tradeNo", respData.get("tradeNo"));
        // 退款时间
        respMap.put("refundTime", this.formatTime(refundTime));
        // 实际退款金额
        respMap.put("refundAmount", this.parseToInt(respData.get("refundAmount")));

        // 保存退款时间
        order.setRefundTime(MyUtil.parseToDate(refundTime));
        trainRegistrationService.save(order);

        return respMap;
    }

    @Override
    public Object clearFileDownload(ClearDateDto dto) {
        try {
            Date clearDate = new SimpleDateFormat("yyyyMMdd").parse(dto.getClearDate());
            long diff = System.currentTimeMillis() - clearDate.getTime();
            if (diff < 0 || diff / 24 / 60 / 60 / 1000 > 7) {
                throw new BusinessException(Response.PARAM_ERROR, "接口仅支持7天内对账单下载，若超过7天请登录相关管理平台下载");
            }
        } catch (ParseException e) {
            throw new BusinessException(Response.PARAM_ERROR, "交易日期格式不正确");
        }

        // 请求参数
        Map<String, Object> reqMap = new HashMap<>(8);
        // 交易日期
        reqMap.put("clearDate", dto.getClearDate());
        // 文件返回类型（默认1-订单明细文件）
        reqMap.put("fileType", "1");

        // 发送请求，获取响应数据
        JSONObject respData = SandPayUtil.send(SandPayConst.URL_CLEARFILE_DOWNLOAD, SandPayConst.METHOD_CLEAR_FILE_DOWNLOAD, reqMap);
        // 返回文件下载地址
        return respData.get("content");
    }

    /**
     * Object 转 Integer
     *
     * @param value Object
     * @return Integer
     */
    private Integer parseToInt(Object value) {
        return null == value ? null : Integer.parseInt(value.toString());
    }

    /**
     * 获取订单状态描述
     *
     * @param orderStatus 订单状态
     * @return 订单状态描述
     */
    private String getOrderStatusDesc(Object orderStatus) {
        String orderStatusDesc = "";
        String status = (String) orderStatus;
        if ("00".equals(status)) {
            orderStatusDesc = "成功";
        } else if ("01".equals(status)) {
            orderStatusDesc = "处理中";
        } else if ("02".equals(status)) {
            orderStatusDesc = "失败";
        } else if ("03".equals(status)) {
            orderStatusDesc = "已撤销";
        } else if ("04".equals(status)) {
            orderStatusDesc = "已退货";
        } else if ("05".equals(status)) {
            orderStatusDesc = "退款处理中";
        }
        return orderStatusDesc;
    }

    /**
     * 格式化时间字符串
     *
     * @param time 时间字符串（yyyyMMddHHmmss）
     * @return 时间字符串（yyyy-MM-dd HH:mm:ss）
     */
    private String formatTime(Object time) {
        String timeStr = String.valueOf(time);
        return StringUtils.isBlank(timeStr) ? "" : String.format("%s-%s-%s %s:%s:%s",
                timeStr.substring(0, 4),
                timeStr.substring(4, 6),
                timeStr.substring(6, 8),
                timeStr.substring(8, 10),
                timeStr.substring(10, 12),
                timeStr.substring(12));
    }

    /**
     * 格式化日期字符串
     *
     * @param date 日期字符串（yyyyMMdd）
     * @return 日期字符串（yyyy-MM-dd）
     */
    private String formatDate(Object date) {
        String dateStr = String.valueOf(date);
        return StringUtils.isBlank(dateStr) ? "" : String.format("%s-%s-%s",
                dateStr.substring(0, 4),
                dateStr.substring(4, 6),
                dateStr.substring(6));
    }
}
