package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.train.TimeQueryDto;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 14:50
 */
public interface TrainStudyTimeService {

    /**
     * 分页获取培训学时信息
     *
     * @param dto TimeQueryDto
     * @return 培训学时信息
     */
    Object getStudyTimes(TimeQueryDto dto);
}
