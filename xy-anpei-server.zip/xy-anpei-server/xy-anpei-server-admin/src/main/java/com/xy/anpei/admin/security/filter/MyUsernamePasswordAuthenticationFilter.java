package com.xy.anpei.admin.security.filter;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.admin.constant.AdminConst;
import com.xy.anpei.admin.util.RsaUtil;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.StreamUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 自定义认证过滤器
 *
 * @author Chen Guibiao
 * Create at 2023-06-20 17:36
 */
public class MyUsernamePasswordAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

    public MyUsernamePasswordAuthenticationFilter() {
        super(new AntPathRequestMatcher(AdminConst.URL_LOGIN, AdminConst.REQUEST_METHOD_POST));
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException {
        // 账号 ID
        String userId = null;
        // 账号密码
        String password = null;
        // 验证码
        String captcha = null;
        // Session
        HttpSession session = request.getSession();

        // 解析请求参数
        String reqBody = StreamUtils.copyToString(request.getInputStream(), StandardCharsets.UTF_8);
        // 缓存请求参数
        session.setAttribute(AdminConst.SESSION_REQUEST_PARAMS, reqBody);
        if (StringUtils.isNotBlank(reqBody)) {
            JSONObject json = JSONUtil.parseObj(reqBody);
            userId = String.valueOf(json.get("userId"));
            password = String.valueOf(json.get("password"));
            captcha = String.valueOf(json.get("captcha"));
        }

        // 获取 Session 中的验证码
        String sessionCaptcha = (String) session.getAttribute(AdminConst.SESSION_CAPTCHA);
        // 清除 Session 中的验证码
        session.removeAttribute(AdminConst.SESSION_CAPTCHA);
        // 若验证码不一致，则直接返回
        if (!StringUtils.equalsIgnoreCase(captcha, sessionCaptcha)) {
            throw new BusinessException(Response.CAPTCHA_ERROR);
        }

        if (null == userId) {
            userId = "";
        }
        // 若 password 不为 null，则通过 RSA 解密获取明文密码
        password = null == password ? "" : RsaUtil.checkAndGetPwd(password);
        // 创建 UsernamePasswordAuthenticationToken
        UsernamePasswordAuthenticationToken upaToken = new UsernamePasswordAuthenticationToken(userId, password);

        return this.getAuthenticationManager().authenticate(upaToken);
    }
}
