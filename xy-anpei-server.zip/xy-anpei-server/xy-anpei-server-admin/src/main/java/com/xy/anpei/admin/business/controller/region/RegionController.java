package com.xy.anpei.admin.business.controller.region;

import com.xy.anpei.admin.business.dto.region.CityDto;
import com.xy.anpei.admin.business.dto.region.ProvinceDto;
import com.xy.anpei.admin.business.service.RegionService;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:57
 */
@RestController
@RequestMapping("/region")
public class RegionController {

    private final RegionService regionService;

    public RegionController(RegionService regionService) {
        this.regionService = regionService;
    }

    @GetMapping(value = "/getProvinces", name = "获取省列表")
    public Object getProvinces() {
        return regionService.getProvinces();
    }

    @PostMapping(value = "/getCities", name = "获取市列表")
    public Object getCities(@RequestBody @Valid ProvinceDto dto) {
        return regionService.getCities(dto);
    }

    @PostMapping(value = "/getDistricts", name = "获取区/县列表")
    public Object getDistricts(@RequestBody @Valid CityDto dto) {
        return regionService.getDistricts(dto);
    }
}
