package com.xy.anpei.admin.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 15:43
 */
@Getter
@Setter
@Entity
@Table(name = "view_certificate")
public class ViewCertificate implements Serializable {

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Id
    @Column(name = "train_id")
    private String trainId;

    /**
     * 培训年度
     */
    @Column(name = "train_year")
    private Integer trainYear;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "full_name")
    private String unitFullName;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 结业证地址
     */
    @Column(name = "cert_url")
    private String certUrl;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;
}
