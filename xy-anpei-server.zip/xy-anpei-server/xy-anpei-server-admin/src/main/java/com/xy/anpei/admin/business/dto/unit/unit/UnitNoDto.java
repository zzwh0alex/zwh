package com.xy.anpei.admin.business.dto.unit.unit;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 14:45
 */
@Data
public class UnitNoDto {

    /**
     * 培训机构全国统一编号
     */
    @NotBlank(message = "机构编号不能为空")
    private String unitNo;
}
