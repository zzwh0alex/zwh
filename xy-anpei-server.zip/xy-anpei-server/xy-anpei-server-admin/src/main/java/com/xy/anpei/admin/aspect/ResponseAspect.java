package com.xy.anpei.admin.aspect;

import com.xy.anpei.base.response.Result;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 应答切面
 *
 * @author Chen Guibiao
 * Create at 2023-06-27 15:35
 */
@Aspect
@Component
@Order(2)
public class ResponseAspect {

    @Around("execution(* com.xy.anpei.admin.business.controller..*(..))")
    public Object aroundController(ProceedingJoinPoint jp) throws Throwable {
        // 执行业务代码
        Object retObj = jp.proceed(jp.getArgs());
        // 判断返回结果是否为空
        if (null == retObj) {
            // 若返回结果为空（即业务方法返回类型为 void），则构造通用应答数据并返回
            return Result.success();
        }
        // 若返回结果类型不为 Result，则先封装后返回
        return (retObj instanceof Result) ? retObj : Result.success(retObj);
    }
}
