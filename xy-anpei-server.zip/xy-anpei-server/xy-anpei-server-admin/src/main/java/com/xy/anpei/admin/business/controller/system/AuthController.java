package com.xy.anpei.admin.business.controller.system;

import com.xy.anpei.admin.business.service.AuthService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 16:29
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PreAuthorize("hasAuthority('system.auth.query')")
    @GetMapping(value = "/getSysAuths", name = "获取系统权限信息")
    public Object getSysAuths() {
        return authService.getSysAuths();
    }
}
