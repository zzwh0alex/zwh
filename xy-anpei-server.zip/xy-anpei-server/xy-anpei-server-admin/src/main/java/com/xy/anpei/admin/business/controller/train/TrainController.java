package com.xy.anpei.admin.business.controller.train;

import com.xy.anpei.admin.business.dto.train.CertQueryDto;
import com.xy.anpei.admin.business.dto.train.RegQueryDto;
import com.xy.anpei.admin.business.dto.train.TimeQueryDto;
import com.xy.anpei.admin.business.service.TrainCertificateService;
import com.xy.anpei.admin.business.service.TrainRegistrationService;
import com.xy.anpei.admin.business.service.TrainStudyTimeService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-07-10 15:02
 */
@RestController
@RequestMapping("/train")
public class TrainController {

    private final TrainRegistrationService trainRegistrationService;

    private final TrainStudyTimeService trainStudyTimeService;

    private final TrainCertificateService trainCertificateService;

    public TrainController(TrainRegistrationService trainRegistrationService,
                           TrainStudyTimeService trainStudyTimeService,
                           TrainCertificateService trainCertificateService) {
        this.trainRegistrationService = trainRegistrationService;
        this.trainStudyTimeService = trainStudyTimeService;
        this.trainCertificateService = trainCertificateService;
    }

    @PreAuthorize("hasAuthority('train.registration.query')")
    @PostMapping(value = "/getRegistrations", name = "分页获取培训报名信息")
    public Object getRegistrations(@RequestBody @Valid RegQueryDto dto) {
        return trainRegistrationService.getRegistrations(dto);
//        return trainRegistrationService
    }

    @PreAuthorize("hasAuthority('train.time.query')")
    @PostMapping(value = "/getStudyTimes", name = "分页获取培训学时信息")
    public Object getStudyTimes(@RequestBody @Valid TimeQueryDto dto) {
        return trainStudyTimeService.getStudyTimes(dto);
    }

    @PreAuthorize("hasAuthority('train.graduation.query')")
    @PostMapping(value = "/getCertificates", name = "分页获取结业证信息")
    public Object getCertificates(@RequestBody @Valid CertQueryDto dto) {
        return trainCertificateService.getCertificates(dto);
    }

}
