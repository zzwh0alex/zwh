package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.domain.entity.Role;
import com.xy.anpei.admin.business.domain.entity.User;
import com.xy.anpei.admin.business.dto.system.user.*;
import com.xy.anpei.admin.business.repository.UserRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.RoleService;
import com.xy.anpei.admin.business.service.UserService;
import com.xy.anpei.admin.util.RsaUtil;
import com.xy.anpei.base.business.service.RedisService;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.IdCardUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:12
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UserServiceImpl extends AbstractService implements UserService {

    private final UserRepository userRepository;

    private final RoleService roleService;

    private final RedisService redisService;

    public UserServiceImpl(UserRepository userRepository,
                           RoleService roleService,
                           RedisService redisService) {
        this.userRepository = userRepository;
        this.roleService = roleService;
        this.redisService = redisService;
    }

    @Override
    public User getByUserId(String userId) {
        userId = StringUtils.deleteWhitespace(userId);
        String cacheKey = getCacheKey(userId);
        User user = redisService.get(cacheKey, User.class);
        if (null == user) {
            if (StringUtils.isNotBlank(userId)) {
                user = userRepository.findById(userId).orElse(null);
            }
            if (null == user) {
                // 登录时，未找到员工须抛出 UsernameNotFoundException 异常，交由 Spring Security 捕获并处理（实际处理类是 LoginFailureHandler）；
                // 不能直接 return null，否则 Spring Security 会报异常：
                // org.springframework.security.authentication.InternalAuthenticationServiceException: UserDetailsService returned null, which is an interface contract violation
                // 非登录时，由 MyExceptionHandler 类捕获并处理该异常
                throw new UsernameNotFoundException("User not found");
            } else {
                // 缓存，避免重复查询
                redisService.set(cacheKey, user);
            }
        }
        return user;
    }

    @Override
    public Object getPageUsers(UserQueryDto dto) {
        String[] fileds = {"userId", "name:userName", "idNo", "phone", "gender", "genderDesc", "status", "statusDesc",
                "createUser", "createTime", "updateUser", "updateTime"};
        return getPage(userRepository, dto, fileds);
    }

    @Override
    public Object getUserRoles(UserIdDto dto) {
        List<Map<String, String>> list = new ArrayList<>();
        Set<Role> roles = this.getByUserId(dto.getUserId()).getRoles();
        for (Role role : roles) {
            Map<String, String> map = new LinkedHashMap<>(2);
            map.put("roleId", role.getRoleId());
            map.put("roleName", role.getRoleName());
            list.add(map);
        }
        return list;
    }

    @Override
    public void add(UserAddDto dto) {
        // 校验身份证号
        IdCardUtil.verify(dto.getIdNo(), true);
        // 获取密码
        String password = this.checkAndGetPassword(dto.getPassword());
        // 用户校验
        String userId = StringUtils.deleteWhitespace(dto.getUserId());
        User user = userRepository.findById(userId).orElse(null);
        if (null != user) {
            throw new BusinessException(Response.DATA_ALREADY_EXISTS, String.format("已存在用户[%s]", userId));
        }
        // 封装用户信息
        user = new User();
        user.setUserId(userId);
        user.setName(StringUtils.deleteWhitespace(dto.getUserName()));
        user.setPhone(dto.getPhone());
        user.setGender(dto.getGender());
        user.setStatus(dto.getStatus());
        user.setPassword(getPasswordEncoder().encode(password));
        user.setPlaintext(password);
        user.setDeleteFlag(MyConst.NOT_DELETED);
        if (StringUtils.isNotBlank(dto.getIdNo())) {
            user.setIdNo(dto.getIdNo());
        }
        doCreate(user);
        // 保存用户关联的角色信息
        if (!CollectionUtils.isEmpty(dto.getRoleIds())) {
            Set<Role> roles = roleService.getRolesByRoleIds(dto.getRoleIds());
            // 关联角色用户记数 +1
            roles.forEach(Role::increase);
            user.setRoles(roles);
        }

        userRepository.save(user);
    }

    @Override
    public void update(UserUpdDto dto) {
        // 校验身份证号
        IdCardUtil.verify(dto.getIdNo(), true);
        // 用户校验
        String userId = StringUtils.deleteWhitespace(dto.getUserId());
        User user = userRepository.findById(userId).orElse(null);
        if (null == user) {
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在用户[%s]", userId));
        }
        // 获取角色信息
        Set<Role> roles = roleService.getRolesByRoleIds(dto.getRoleIds());
        // 关联角色用户记数 +1
        roles.forEach(Role::increase);
        // 原关联角色用户记数 -1
        user.getRoles().forEach(Role::decrease);
        // 封装用户信息
        user.setName(StringUtils.deleteWhitespace(dto.getUserName()));
        user.setIdNo(dto.getIdNo());
        user.setPhone(dto.getPhone());
        user.setGender(dto.getGender());
        user.setStatus(dto.getStatus());
        user.setRoles(roles);
        doUpdate(user);
        userRepository.save(user);

        // 清除用户信息缓存
        redisService.delete(getCacheKey(user.getUserId()));
    }

    @Override
    public void delete(UserIdDto dto) {
        String userId = StringUtils.deleteWhitespace(dto.getUserId());
        User user = userRepository.findById(userId).orElse(null);
        if (null == user) {
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在用户[%s]", userId));
        }
        // 原关联角色用户记数 -1
        user.getRoles().forEach(Role::decrease);
        // 删除用户信息
        userRepository.delete(user);
        // 清除用户信息缓存
        redisService.delete(getCacheKey(userId));
    }

    @Override
    public void changePassword(UserPwdChgDto dto) {
        String currPwd = this.checkAndGetPassword(dto.getCurrPwd());
        String newPwd = this.checkAndGetPassword(dto.getNewPwd());
        String checkPwd = this.checkAndGetPassword(dto.getCheckPwd());

        if (!StringUtils.equals(newPwd, checkPwd)) {
            throw new BusinessException(Response.PARAM_ERROR, "新密码与确认密码不一致");
        }
        User currUser = getCurrUser();
        PasswordEncoder encoder = getPasswordEncoder();
        if (!encoder.matches(currPwd, currUser.getPassword())) {
            throw new BusinessException(Response.PARAM_ERROR, "当前密码不正确");
        }
        currUser.setPassword(encoder.encode(newPwd));
        currUser.setPlaintext(newPwd);
        userRepository.save(currUser);

        // 清除用户信息缓存
        redisService.delete(getCacheKey(currUser.getUserId()));
    }

    @Override
    public void resetPassword(UserPwdResDto dto) {
        String adminPwd = this.checkAndGetPassword(dto.getAdminPwd());
        String newPwd = this.checkAndGetPassword(dto.getNewPwd());
        String checkPwd = this.checkAndGetPassword(dto.getCheckPwd());

        if (!StringUtils.equals(newPwd, checkPwd)) {
            throw new BusinessException(Response.PARAM_ERROR, "新密码与确认密码不一致");
        }
        User currUser = getCurrUser();
        PasswordEncoder encoder = getPasswordEncoder();
        if (!encoder.matches(adminPwd, currUser.getPassword())) {
            throw new BusinessException(Response.PARAM_ERROR, "您的账号密码不正确");
        }
        User user = getByUserId(dto.getUserId());
        user.setPassword(encoder.encode(newPwd));
        user.setPlaintext(newPwd);
        userRepository.save(user);

        // 清除用户信息缓存
        redisService.delete(getCacheKey(user.getUserId()));
    }

    /**
     * 获取缓存 key
     *
     * @param userId 用户 ID
     * @return String
     */
    private String getCacheKey(String userId) {
        return String.format("user_%s", userId);
    }

    /**
     * 检查并获取密码
     *
     * @param ciphertext 密文
     * @return 密码明文
     */
    private String checkAndGetPassword(String ciphertext) {
        String password = RsaUtil.checkAndGetPwd(ciphertext);
        int minLen = 6;
        if (null == password || password.length() < minLen) {
            throw new BusinessException(Response.PARAM_ERROR, "密码长度不能少于6个字符");
        }
        return password;
    }
}
