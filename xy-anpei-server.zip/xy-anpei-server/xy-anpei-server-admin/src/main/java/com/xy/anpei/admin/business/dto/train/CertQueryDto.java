package com.xy.anpei.admin.business.dto.train;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 14:57
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "createTime", direction = SortExp.Direction.DESC))
public class CertQueryDto extends MyPage {

    /**
     * 培训机构全国统一编号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String unitNo;

    /**
     * 学员身份证号
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String idNo;
}
