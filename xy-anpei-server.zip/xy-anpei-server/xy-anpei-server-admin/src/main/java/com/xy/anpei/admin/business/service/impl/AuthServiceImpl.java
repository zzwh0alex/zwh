package com.xy.anpei.admin.business.service.impl;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.admin.business.domain.entity.Auth;
import com.xy.anpei.admin.business.repository.AuthRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.AuthService;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Chen Guibiao
 * Create at 2023-06-30 11:24
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class AuthServiceImpl extends AbstractService implements AuthService {

    private final AuthRepository authRepository;

    public AuthServiceImpl(AuthRepository authRepository) {
        this.authRepository = authRepository;
    }

    @Override
    public Auth getByAuthId(String authId) {
        return authRepository.findById(authId)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在权限[%s]", authId)));
    }

    @Override
    public Set<Auth> getByAuthIds(Set<String> authIds) {
        Set<Auth> auths = new HashSet<>();
        if (CollectionUtils.isEmpty(authIds)) {
            return auths;
        }
        auths = authRepository.findByAuthIdIn(authIds);
        if (CollectionUtils.isEmpty(auths)) {
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在权限[%s]", authIds));
        }
        // 若权限集合元素个数与 authIds 的个数不一致，也提示错误
        if (auths.size() != authIds.size()) {
            Set<String> resultIds = auths.stream().map(Auth::getAuthId).collect(Collectors.toSet());
            authIds.removeAll(resultIds);
            throw new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在权限[%s]", authIds));
        }
        return auths;
    }

    @Override
    public Object getSysAuths() {
        // 获取具有层次结构的权限列表
        List<Auth> hierarchyAuths = this.getHierarchyAuths(this.getAvailableAuths());
        // 使用 hutool 转换一下，忽略 Jackson 的注解
        return JSONUtil.parseArray(hierarchyAuths);
    }

    @Override
    public Set<String> getUserAuthIds() {
        return this.getFullAuthIds(getCurrUser().getAuthIds());
    }

    @Override
    public List<Auth> getUserAuths() {
        // 获取系统启用的权限
        Map<String, Auth> authMap = this.getAvailableAuths().stream().collect(Collectors.toMap(Auth::getAuthId, Function.identity(), (key1, key2) -> key2));
        // 获取用户权限集合
        List<Auth> auths = this.getUserAuthIds().stream().map(authMap::get).collect(Collectors.toList());
        // 返回具有层次结构的权限列表
        return this.getHierarchyAuths(auths);
    }

    @Override
    public List<Auth> getHierarchyAuthsByAuthIds(Set<String> authIds) {
        Set<String> fullAuthIds = this.getFullAuthIds(authIds);
        // 获取系统启用的权限
        Map<String, Auth> authMap = this.getAvailableAuths().stream().collect(Collectors.toMap(Auth::getAuthId, Function.identity(), (key1, key2) -> key2));
        // 获取权限集合
        List<Auth> auths = fullAuthIds.stream().map(authMap::get).collect(Collectors.toList());
        // 返回具有层次结构的权限列表
        return this.getHierarchyAuths(auths);
    }

    /**
     * 根据子权限获取包含父权限在内的所有权限
     *
     * @param authIds 权限 ID 集
     * @return a set of String
     */
    private Set<String> getFullAuthIds(Set<String> authIds) {
        Set<String> fullAuthIds = new HashSet<>();
        // 若权限集为空，则直接返回
        if (CollectionUtils.isEmpty(authIds)) {
            return fullAuthIds;
        }
        // 获取系统启用的权限
        List<Auth> availableAuths = this.getAvailableAuths();
        // List<Auth> 转 Map<String, Auth>
        Map<String, Auth> authMap = availableAuths.stream().collect(Collectors.toMap(Auth::getAuthId, Function.identity(), (key1, key2) -> key2));
        // 根据子节点获取父节点
        authIds.forEach(authId -> this.getFullAuthIds(fullAuthIds, authId, authMap));
        // 返回
        return fullAuthIds;
    }

    /**
     * 根据子权限获取包含父权限在内的所有权限
     *
     * @param retAuthIds 待返回的权限 ID 集
     * @param authId     权限 ID
     * @param authMap    权限 Map
     */
    private void getFullAuthIds(Set<String> retAuthIds, String authId, Map<String, Auth> authMap) {
        retAuthIds.add(authId);
        String parentId = authMap.get(authId).getParentId();
        if (StringUtils.isNotBlank(parentId)) {
            this.getFullAuthIds(retAuthIds, parentId, authMap);
        }
    }

    /**
     * 获取系统启用的权限
     *
     * @return 系统启用的权限
     */
    private List<Auth> getAvailableAuths() {
        return authRepository.findByStatusOrderByDisplayOrder(MyConst.STATUS_ENABLED);
    }

    /**
     * 获取具有层次结构的权限列表
     *
     * @param auths List<Auth>
     * @return 具有层次结构的权限列表
     */
    private List<Auth> getHierarchyAuths(List<Auth> auths) {
        List<Auth> hierarchyAuths = new ArrayList<>();
        // 若权限列表不空，则设置权限层级
        if (!CollectionUtils.isEmpty(auths)) {
            Map<String, Auth> tempMap = new HashMap<>(auths.size());
            // 设置一级权限
            auths.forEach(auth -> {
                if (null == auth.getParentId()) {
                    hierarchyAuths.add(auth);
                }
                // 初始化子权限
                auth.setChildren(new ArrayList<>());
                // 缓存各实例供后续使用
                tempMap.put(auth.getAuthId(), auth);
            });
            // 设置各级子权限
            auths.forEach(auth -> {
                if (StringUtils.isNotBlank(auth.getParentId())) {
                    tempMap.get(auth.getParentId()).getChildren().add(auth);
                }
            });
        }
        // 返回
        return hierarchyAuths;
    }
}
