package com.xy.anpei.admin.business.dto.system.menu;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 10:58
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "displayOrder"))
public class MenuQueryDto extends MyPage {

    /**
     * 菜单名称
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE)
    private String menuName;

    /**
     * 菜单级别
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer level;

    /**
     * 菜单状态
     * 0-停用；1-启用
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer status;

    /**
     * 父菜单 ID
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private String parentId;
}
