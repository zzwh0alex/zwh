package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.model.ViewRegistration;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 16:58
 */
@Repository
public interface ViewRegistrationRepository extends MyRepository<ViewRegistration, Integer> {

    /**
     * 根据商户单号查询培训报名记录
     *
     * @param orderCode 商户单号
     * @return Optional<ViewRegistration>
     */
    Optional<ViewRegistration> findByOrderCode(String orderCode);
}
