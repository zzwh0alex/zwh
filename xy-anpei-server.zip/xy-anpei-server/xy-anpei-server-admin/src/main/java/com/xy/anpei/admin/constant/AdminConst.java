package com.xy.anpei.admin.constant;

/**
 * @author Chen Guibiao
 * Create at 2023-06-28 08:31
 */
public class AdminConst {

    /**
     * 请求方法 - POST
     */
    public static final String REQUEST_METHOD_POST = "POST";

    /**
     * 请求方法 - OPTIONS
     */
    public static final String REQUEST_METHOD_OPTIONS = "OPTIONS";

    /**
     * 响应属性 - ContentType
     */
    public static final String RESPONSE_CONTENT_TYPE = "application/json;charset=UTF-8";

    /**
     * 请求头 - authorization
     */
    public static final String HEADER_AUTHORIZATION = "authorization";

    /**
     * 字段 - userId
     */
    public static final String FIELD_USER_ID = "userId";

    /**
     * 存储验证码的 session key
     */
    public static final String SESSION_CAPTCHA = "SESSION_CAPTCHA";

    /**
     * 存储请求参数的 session key
     */
    public static final String SESSION_REQUEST_PARAMS = "SESSION_REQUEST_PARAMS";

    /**
     * URL - 获取验证码
     */
    public static final String URL_CAPTCHA = "/getCaptcha";

    /**
     * URL - 登录
     */
    public static final String URL_LOGIN = "/login";

    /**
     * URL - 辅助接口类
     */
    public static final String URL_CATEGORY_HELPER = "/helper/*";
}
