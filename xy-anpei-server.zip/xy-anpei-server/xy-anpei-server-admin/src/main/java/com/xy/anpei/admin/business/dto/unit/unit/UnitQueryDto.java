package com.xy.anpei.admin.business.dto.unit.unit;

import com.xy.anpei.admin.business.dto.common.MyPage;
import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Chen Guibiao
 * Create at 2023-07-05 10:17
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JpaFmt(orderBy = @SortExp(name = "displayOrder"))
public class UnitQueryDto extends MyPage {

    /**
     * 培训机构全国统一编号
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE)
    private String unitNo;

    /**
     * 培训机构简称
     */
    @JpaFmt(opt = JpaFmt.Opt.LIKE, alias = "fullName")
    private String unitName;

    /**
     * 所属省
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer provinceId;

    /**
     * 所属市
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer cityId;

    /**
     * 所属区/县
     */
    @JpaFmt(opt = JpaFmt.Opt.EQUAL)
    private Integer districtId;
}
