package com.xy.anpei.admin.business.dto.thirdparty;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-07-19 11:01
 */
@Data
public class CqayUpdDto {

    /**
     * （重庆安运科技）报名记录 ID
     */
    @NotBlank(message = "培训编号不能为空")
    private String trainId;

    /**
     * 培训机构编号
     */
    private String unitNo;

    /**
     * 登记照片
     */
    @Pattern(regexp = "^$|^data:image/.*;base64,.*", message = "登记照片格式不正确")
    private String photo;

    /**
     * 是否注销
     */
    private Boolean isDelete;
}
