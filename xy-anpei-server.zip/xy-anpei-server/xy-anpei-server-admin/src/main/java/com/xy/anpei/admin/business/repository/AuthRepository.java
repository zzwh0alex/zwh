package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.entity.Auth;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:05
 */
@Repository
public interface AuthRepository extends MyRepository<Auth, String> {

    /**
     * 根据权限 ID 集查询权限信息
     *
     * @param authIds 权限 ID 集
     * @return a set of Auth
     */
    Set<Auth> findByAuthIdIn(Set<String> authIds);

    /**
     * 根据权限状态查询权限信息，并根据显示顺序升序排序
     *
     * @param status 权限状态
     * @return a list of Auth
     */
    List<Auth> findByStatusOrderByDisplayOrder(Integer status);
}
