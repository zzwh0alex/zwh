package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.entity.Menu;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:05
 */
@Repository
public interface MenuRepository extends MyRepository<Menu, String> {

    /**
     * 根据菜单状态查询菜单信息，并根据显示顺序升序排序
     *
     * @param status 菜单状态
     * @return a list of Menu
     */
    List<Menu> findByStatusOrderByDisplayOrder(Integer status);
}
