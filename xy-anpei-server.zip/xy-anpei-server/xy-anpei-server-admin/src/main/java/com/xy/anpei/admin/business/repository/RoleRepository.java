package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.entity.Role;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Set;

/**
 * @author Chen Guibiao
 * Create at 2023-06-20 16:00
 */
@Repository
public interface RoleRepository extends MyRepository<Role, String> {

    /**
     * 根据角色 ID 集查询角色信息
     *
     * @param roleIds 角色 ID 集
     * @return a set of Role
     */
    Set<Role> findByRoleIdIn(Set<String> roleIds);
}
