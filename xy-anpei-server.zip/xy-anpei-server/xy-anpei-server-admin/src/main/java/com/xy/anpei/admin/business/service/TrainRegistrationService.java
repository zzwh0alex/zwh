package com.xy.anpei.admin.business.service;

import com.xy.anpei.admin.business.dto.train.RegQueryDto;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;

/**
 * @author Chen Guibiao
 * Create at 2023-07-07 16:18
 */
public interface TrainRegistrationService {

    /**
     * 分页获取培训报名信息
     *
     * @param dto RegQueryDto
     * @return 培训报名信息
     */
    Object getRegistrations(RegQueryDto dto);

    /**
     * 根据培训编号获取培训报名记录
     *
     * @param trainId 培训编号
     * @return TrainRegistration
     */
    TrainRegistration getByTrainId(String trainId);

    /**
     * 根据商户单号获取培训报名记录
     *
     * @param orderCode 商户单号
     * @return TrainRegistration
     */
    TrainRegistration getByOrderCode(String orderCode);

    /**
     * 保存培训报名记录
     *
     * @param registration TrainRegistration
     */
    void save(TrainRegistration registration);
}
