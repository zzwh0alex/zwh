package com.xy.anpei.admin.business.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.business.domain.entity.parent.DeletableEntity;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 15:23
 */
@Getter
@Setter
@Entity
@Table(name = "sys_user")
public class User extends DeletableEntity implements UserDetails, Serializable {

    /**
     * 用户 ID
     */
    @Id
    @Column(name = "user_id")
    private String userId;

    /**
     * 用户名称
     */
    @Column(name = "user_name")
    private String name;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 性别
     * 0-未知；1-男；2-女
     */
    @Column(name = "gender")
    private Integer gender;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @Column(name = "status")
    private Integer status;

    /**
     * 账号密码
     */
    @Column(name = "password")
    private String password;

    /**
     * 盐
     */
    @JsonIgnore
    @Column(name = "salt")
    private String salt;

    /**
     * 密码明文
     */
    @JsonIgnore
    @Column(name = "plaintext")
    private String plaintext;

    /**
     * 用户关联的角色
     */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "sys_user_role",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "role_id")
    )
    private Set<Role> roles;

    /**
     * 用户权限
     */
    @Transient
    private Set<GrantedAuthority> grantedAuthorities = new HashSet<>();

    @JsonIgnore
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (this.grantedAuthorities.isEmpty()) {
            this.roles.forEach(role -> {
                role.getAuthorities().forEach(authority -> {
                    this.grantedAuthorities.add(new SimpleGrantedAuthority(authority.getAuthId()));
                });
            });
        }
        return this.grantedAuthorities;
    }

    @JsonIgnore
    public Set<String> getAuthIds() {
        return this.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toSet());
    }

    /**
     * 获取用户 ID
     *
     * @return 用户 ID
     */
    @JsonIgnore
    @Override
    public String getUsername() {
        return this.userId;
    }

    /**
     * 当前账号是否未过期
     *
     * @return true
     */
    @JsonIgnore
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * 当前账号是否未锁定
     *
     * @return true
     */
    @JsonIgnore
    @Override
    public boolean isAccountNonLocked() {
        return MyConst.NOT_DELETED.equals(this.getDeleteFlag());
    }

    /**
     * 当前账号凭证是否未过期
     *
     * @return true
     */
    @JsonIgnore
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * 当前账号是否可用
     *
     * @return 账号状态
     */
    @JsonIgnore
    @Override
    public boolean isEnabled() {
        return MyConst.STATUS_ENABLED.equals(this.status);
    }

    /**
     * 获取性别的中文描述
     *
     * @return 性别的中文描述
     */
    @JsonIgnore
    public String getGenderDesc() {
        String genderDesc = "未知";
        if (MyConst.GENDER_MALE.equals(this.gender)) {
            genderDesc = "男";
        } else if (MyConst.GENDER_FEMALE.equals(this.gender)) {
            genderDesc = "女";
        }
        return genderDesc;
    }

    /**
     * 获取账号状态的中文描述
     *
     * @return 账号状态的中文描述
     */
    @JsonIgnore
    public String getStatusDesc() {
        String statusDesc = "";
        if (MyConst.STATUS_ENABLED.equals(this.status)) {
            statusDesc = "启用";
        } else if (MyConst.STATUS_DISABLED.equals(this.status)) {
            statusDesc = "停用";
        }
        return statusDesc;
    }
}
