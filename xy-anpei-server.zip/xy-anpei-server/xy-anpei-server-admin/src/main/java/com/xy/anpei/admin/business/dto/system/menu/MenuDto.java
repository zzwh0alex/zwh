package com.xy.anpei.admin.business.dto.system.menu;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 16:55
 */
@Data
public class MenuDto {

    /**
     * 菜单 ID
     */
    @NotBlank(message = "菜单ID不能为空")
    private String menuId;

    /**
     * 菜单名称
     */
    @NotBlank(message = "菜单名称不能为空")
    private String menuName;

    /**
     * 菜单路径
     */
    @NotBlank(message = "菜单路径不能为空")
    private String path;

    /**
     * 菜单级别
     */
    @NotNull(message = "菜单级别不能为空")
    @Min(value = 0, message = "菜单级别不正确")
    private Integer level;

    /**
     * 菜单状态
     * 0-停用；1-启用
     */
    @NotNull(message = "菜单状态不能为空")
    @Min(value = 0, message = "菜单状态不正确")
    @Max(value = 1, message = "菜单状态不正确")
    private Integer status;

    /**
     * ElementUI 图标名称
     */
    private String iconCls;

    /**
     * 父菜单 ID
     */
    private String parentId;

    /**
     * 显示顺序
     */
    private Integer displayOrder;

    /**
     * 权限 ID
     */
    @NotBlank(message = "权限ID不能为空")
    private String authId;
}
