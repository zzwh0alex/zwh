package com.xy.anpei.admin.business.repository;

import com.xy.anpei.admin.business.domain.model.ViewStudyTime;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-07-11 18:03
 */
@Repository
public interface ViewStudyTimeRepository extends MyRepository<ViewStudyTime, String> {
}
