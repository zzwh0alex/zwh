package com.xy.anpei.admin.business.domain.model;

import com.xy.anpei.base.business.domain.entity.parent.DeletableEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 10:41
 */
@Getter
@Setter
@Entity
@Table(name = "view_unit")
public class ViewUnit extends DeletableEntity implements Serializable {

    /**
     * 培训机构 ID
     */
    @Id
    @Column(name = "unit_id")
    private Integer unitId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "full_name")
    private String fullName;

    /**
     * 培训机构地址
     */
    @Column(name = "address")
    private String address;

    /**
     * 邮政编码
     */
    @Column(name = "postal_code")
    private String postalCode;

    /**
     * 所属省
     */
    @Column(name = "province_id")
    private Integer provinceId;

    /**
     * 所属省全称
     */
    @Column(name = "province_full_name")
    private String provinceFullName;

    /**
     * 所属市
     */
    @Column(name = "city_id")
    private Integer cityId;

    /**
     * 所属市全称
     */
    @Column(name = "city_full_name")
    private String cityFullName;

    /**
     * 所属区/县
     */
    @Column(name = "district_id")
    private Integer districtId;

    /**
     * 所属区/县全称
     */
    @Column(name = "district_full_name")
    private String districtFullName;

    /**
     * 经营许可证编号
     */
    @Column(name = "business_license_no")
    private String businessLicenseNo;

    /**
     * 经营许可日期
     */
    @Column(name = "business_license_date")
    private String businessLicenseDate;

    /**
     * 营业执照注册号
     */
    @Column(name = "business_license_reg_no")
    private String businessLicenseRegNo;

    /**
     * 经营范围
     */
    @Column(name = "business_scope")
    private String businessScope;

    /**
     * 统一社会信用代码
     */
    @Column(name = "unified_social_credit_code")
    private String unifiedSocialCreditCode;

    /**
     * 法人代表
     */
    @Column(name = "legal_person")
    private String legalPerson;

    /**
     * 联系电话
     */
    @Column(name = "contact_number")
    private String contactNumber;

    /**
     * 显示顺序
     */
    @Column(name = "display_order")
    private Integer displayOrder;
}
