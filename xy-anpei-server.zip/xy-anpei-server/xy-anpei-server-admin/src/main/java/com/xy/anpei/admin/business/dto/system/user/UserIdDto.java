package com.xy.anpei.admin.business.dto.system.user;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 16:44
 */
@Data
public class UserIdDto {

    /**
     * 用户 ID
     */
    @NotBlank(message = "用户账号不能为空")
    private String userId;
}
