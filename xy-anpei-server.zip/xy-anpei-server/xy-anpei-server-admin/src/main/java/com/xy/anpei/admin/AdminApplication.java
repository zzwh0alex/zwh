package com.xy.anpei.admin;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author Chen Guibiao
 * Create at 2023-05-16 11:43
 */
@EntityScan(basePackages = {"com.xy.anpei.base.business.domain", "com.xy.anpei.admin.business.domain"})
@EnableJpaRepositories(basePackages = {"com.xy.anpei.base.business.repository", "com.xy.anpei.admin.business.repository"})
@SpringBootApplication(scanBasePackages = "com.xy.anpei", exclude = UserDetailsServiceAutoConfiguration.class)
public class AdminApplication {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(AdminApplication.class);
        // 将 banner 信息输出到日志文件
        application.setBannerMode(Banner.Mode.LOG);
        application.run(args);
    }
}
