package com.xy.anpei.admin.business.controller.home;

import com.xy.anpei.admin.business.dto.home.CaptchaDto;
import com.xy.anpei.admin.util.CaptchaUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Chen Guibiao
 * Create at 2023-06-21 10:08
 */
@RestController
public class LoginController {

    @GetMapping(value = "/getCaptcha", name = "获取验证码")
    public void getCaptcha(@RequestBody(required = false) CaptchaDto dto, HttpServletRequest request, HttpServletResponse response) throws IOException {
        if (null == dto) {
            CaptchaUtil.generateCaptcha(request, response, 4, 100, 40);
        } else {
            CaptchaUtil.generateCaptcha(request, response, dto.getLength(), dto.getWidth(), dto.getHeight());
        }
    }
}
