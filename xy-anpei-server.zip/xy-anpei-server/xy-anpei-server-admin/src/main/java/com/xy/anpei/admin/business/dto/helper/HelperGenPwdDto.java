package com.xy.anpei.admin.business.dto.helper;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Chen Guibiao
 * Create at 2023-06-28 09:23
 */
@Data
public class HelperGenPwdDto {

    /**
     * 鉴权码
     */
    @NotBlank(message = "鉴权码不能为空")
    private String auth;

    /**
     * 明文密码
     */
    @NotNull(message = "目标参数不能为空")
    private String password;
}
