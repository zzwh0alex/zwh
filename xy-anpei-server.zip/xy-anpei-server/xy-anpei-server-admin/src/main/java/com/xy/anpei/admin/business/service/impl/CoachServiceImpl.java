package com.xy.anpei.admin.business.service.impl;

import com.xy.anpei.admin.business.domain.model.ViewCoach;
import com.xy.anpei.admin.business.dto.unit.coach.CoachDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachIdNoDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachPwdDto;
import com.xy.anpei.admin.business.dto.unit.coach.CoachQueryDto;
import com.xy.anpei.admin.business.repository.ViewCoachRepository;
import com.xy.anpei.admin.business.service.AbstractService;
import com.xy.anpei.admin.business.service.CoachService;
import com.xy.anpei.admin.business.service.UnitService;
import com.xy.anpei.admin.config.AdminConfig;
import com.xy.anpei.admin.util.RsaUtil;
import com.xy.anpei.base.business.domain.entity.Coach;
import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.business.repository.CoachRepository;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.FileUtil;
import com.xy.anpei.base.util.IdCardUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-07-06 11:21
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class CoachServiceImpl extends AbstractService implements CoachService {

    private final AdminConfig adminConfig;

    private final CoachRepository coachRepository;

    private final ViewCoachRepository viewCoachRepository;

    private final UnitService unitService;

    public CoachServiceImpl(AdminConfig adminConfig,
                            CoachRepository coachRepository,
                            ViewCoachRepository viewCoachRepository,
                            UnitService unitService) {
        this.adminConfig = adminConfig;
        this.coachRepository = coachRepository;
        this.viewCoachRepository = viewCoachRepository;
        this.unitService = unitService;
    }

    @Override
    public Object getCoachs(CoachQueryDto dto) {
        String[] fileds = {"unitNo", "unitName", "unitFullName", "coachName", "idNo", "phone", "address", "status", "statusDesc",
                "registrationTime", "createUser", "createTime", "updateUser", "updateTime"};
        return getPage(viewCoachRepository, dto, fileds);
    }

    @Override
    public Object getCoachDetail(CoachIdNoDto dto) {
        String idNo = dto.getIdNo();
        IdCardUtil.verify(idNo);
        ViewCoach coach = viewCoachRepository.findByIdNo(idNo)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在教练[%s]", idNo)));
        String[] fileds = {"unitNo", "unitName", "unitFullName", "coachName", "idNo", "phone", "address", "status", "statusDesc",
                "registrationTime", "photo", "deleteFlag", "deleteDesc", "createUser", "createTime", "updateUser", "updateTime",
                "deleteUser", "deleteTime"};
        Map<String, Object> map = beanToMap(coach, fileds);
        map.put("photo", StringUtils.defaultIfBlank(adminConfig.getPersonalPhotoUrl() + coach.getPhoto().replace(File.separator, "/"), ""));
        return map;
    }

    @Override
    public void add(CoachDto dto) {
        if (null == dto.getFile()) {
            throw new BusinessException(Response.PARAM_ERROR, "个人照片不能为空");
        }
        coachRepository.findByIdNo(dto.getIdNo()).ifPresent(coach -> {
            throw new BusinessException(Response.DATA_ALREADY_EXISTS, String.format("已存在教练[%s]", coach.getIdNo()));
        });
        Coach coach = this.fillCoach(new Coach(), dto);
        this.savePhoto(coach, dto);
        doCreate(coach);
        coachRepository.save(coach);
    }

    @Override
    public void update(CoachDto dto) {
        String idNo = dto.getIdNo();
        Coach coach = this.fillCoach(this.getByIdNo(idNo), dto);
        if (null != dto.getFile()) {
            this.savePhoto(coach, dto);
        }
        coach.setPassword(idNo.substring(12));
        coach.setPlaintext(idNo.substring(12));
        coach.setRegistrationTime(new Date());
        coach.setDeleteFlag(MyConst.NOT_DELETED);
        doUpdate(coach);
        coachRepository.save(coach);
    }

    @Override
    public void updateText(CoachDto dto) {
        Coach coach = this.fillCoach(this.getByIdNo(dto.getIdNo()), dto);
        doUpdate(coach);
        coachRepository.save(coach);
    }

    @Override
    public void delete(CoachIdNoDto dto) {
        Coach coach = this.getByIdNo(dto.getIdNo());
        doDelete(coach);
        coachRepository.save(coach);
    }

    @Override
    public void resetPassword(CoachPwdDto dto) {
        String password = RsaUtil.checkAndGetPwd(dto.getPassword());
        Coach coach = this.getByIdNo(dto.getIdNo());
        coach.setPassword(password);
        coach.setPlaintext(password);
        doUpdate(coach);
        coachRepository.save(coach);
    }

    /**
     * 根据身份证号获取教练员信息
     *
     * @param idNo 身份证号
     * @return 教练员信息
     */
    private Coach getByIdNo(String idNo) {
        IdCardUtil.verify(idNo);
        return coachRepository.findByIdNo(idNo)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("不存在教练[%s]", idNo)));
    }

    /**
     * 填充教练信息
     *
     * @param coach Coach
     * @param dto   CoachDto
     * @return Coach
     */
    private Coach fillCoach(Coach coach, CoachDto dto) {
        String idNo = dto.getIdNo();
        // 校验身份证号
        IdCardUtil.verify(idNo);
        // 查询机构信息
        Unit unit = unitService.getByUnitNo(dto.getUnitNo());
        // 填充教练信息
        coach.setUnitId(unit.getUnitId());
        coach.setCoachName(StringUtils.deleteWhitespace(dto.getCoachName()));
        coach.setIdNo(idNo);
        coach.setPhone(dto.getPhone());
        coach.setAddress(dto.getAddress());
        coach.setStatus(dto.getStatus());

        return coach;
    }

    /**
     * 保存图片
     *
     * @param coach Coach
     * @param dto   CoachDto
     */
    private void savePhoto(Coach coach, CoachDto dto) {
        MultipartFile file = dto.getFile();
        String fileName = file.getOriginalFilename();
        String fileType = StringUtils.isBlank(fileName) ? "jpg" : fileName.substring(fileName.lastIndexOf(".") + 1);
        String fullPath = String.format("%s%s%s%s.%s", adminConfig.getPersonalPhotoPath(), dto.getUnitNo(), File.separator, dto.getIdNo(), fileType);
        File imageFile = new File(fullPath);
        FileUtil.createParentPath(imageFile);
        try (InputStream is = file.getInputStream();
             FileOutputStream fos = new FileOutputStream(imageFile)) {
            int length = 2048;
            byte[] buffer = new byte[length];
            while ((length = is.read(buffer, 0, length)) != -1) {
                fos.write(buffer, 0, length);
            }
            coach.setPhotoPath(fullPath.replace(adminConfig.getPersonalPhotoPath(), ""));
            log.info("保存了图片：{}", fullPath);
        } catch (Exception e) {
            log.error("保存图片时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }
}
