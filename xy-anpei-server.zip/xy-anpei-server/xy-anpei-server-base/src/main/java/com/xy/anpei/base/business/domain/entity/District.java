package com.xy.anpei.base.business.domain.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 行政区划（区/县）表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 17:31
 */
@Getter
@Setter
@Entity
@Table(name = "region_district")
public class District implements Serializable {

    /**
     * 区/县行政区划唯一标识
     */
    @Id
    @Column(name = "district_id")
    private Integer districtId;

    /**
     * 父标识
     */
    @Column(name = "parent_id")
    private Integer parentId;

    /**
     * 全称
     */
    @Column(name = "full_name")
    private String fullName;
}
