package com.xy.anpei.base.util;

import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 签名工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-22 14:11
 */
@Slf4j
public class SignUtil {

    /**
     * 校验签名
     *
     * @param obj       请求参数
     * @param secretKey 密钥
     * @param validTime 有效时间，毫秒
     */
    public static void verify(Object obj, String secretKey, long validTime) {
        // 对象转 Map
        Map<String, String> data = MyUtil.beanToMap(obj);

        // 当前时间
        long currTime = System.currentTimeMillis();
        // 请求时间
        long requestTime = Long.parseLong(data.get(MyConst.FIELD_REQUEST_TIME));
        // 判断请求是否失效
        if (Math.abs(currTime - requestTime) > validTime) {
            log.info("请求失效！currTime={}, requestTime={}", currTime, requestTime);
            throw new BusinessException(Response.REQUEST_INVALID);
        }

        // 生成签名
        String sign = generateSignature(convertMap(data), secretKey);
        // 比对签名
        if (!StringUtils.equals(sign, data.get(MyConst.FIELD_SIGN))) {
            log.info("签名无效！ourSign={}, reqSign={}", sign, data.get(MyConst.FIELD_SIGN));
            throw new BusinessException(Response.SIGNATURE_MISMATCH);
        }
    }

    /**
     * 生成签名
     *
     * @param data      请求参数
     * @param secretKey 密钥
     * @return 签名
     */
    public static String generateSignature(final Map<String, Object> data, String secretKey) {
        Object fieldSignType = data.get(MyConst.FIELD_SIGN_TYPE);
        // 签名类型，默认为 MD5
        String signType = null == fieldSignType ? MyConst.SIGN_TYPE_MD5 : String.valueOf(fieldSignType);
        // 生成待签名字符串
        String targetStr = getTargetStr(data, secretKey);
        // 生成并返回签名
        return sign(targetStr, secretKey, signType);
    }

    /**
     * 生成签名（测试用）
     *
     * @param data      请求参数
     * @param secretKey 密钥
     * @return 签名
     */
    public static String generateSignatureTest(final Map<String, Object> data, String secretKey) {
        Object fieldSignType = data.get(MyConst.FIELD_SIGN_TYPE);
        // 签名类型，默认为 MD5
        String signType = null == fieldSignType ? MyConst.SIGN_TYPE_MD5 : String.valueOf(fieldSignType);
        // 生成待签名字符串
        String targetStr = getTargetStr(data, secretKey);
        // 处理待签名字符串
        targetStr = targetStr.replace("\",\"", "\", \"")
                .replace("},{", "}, {")
                .replace("\":", "=")
                .replace("\"", "");
        log.info("targetStr = " + targetStr);
        // 生成并返回签名
        return sign(targetStr, secretKey, signType);
    }

    /**
     * 生成待签名字符串
     *
     * @param data      待签名数据
     * @param secretKey 密钥
     * @return 待签名字符串
     */
    private static String getTargetStr(final Map<String, Object> data, String secretKey) {
        Set<String> keySet = data.keySet();
        String[] keyArray = keySet.toArray(new String[0]);
        Arrays.sort(keyArray);
        StringBuilder builder = new StringBuilder();
        for (String key : keyArray) {
            if (MyConst.FIELD_SIGN.equals(key)) {
                continue;
            }
            String value = String.valueOf(data.get(key)).trim();
            // 若参数值为空，则不参与签名
            if (value.length() > 0) {
                builder.append(key).append("=").append(value).append("&");
            }
        }
        return builder.append("key=").append(secretKey).toString();
    }

    /**
     * 生成签名
     *
     * @param targetStr 待签名字符串
     * @param secretKey 密钥
     * @param signType  签名方式
     * @return 签名
     */
    private static String sign(String targetStr, String secretKey, String signType) {
        return MyConst.SIGN_TYPE_HMACSHA256.equals(signType) ? hmacsha256(targetStr, secretKey) : md5(targetStr);
    }

    /**
     * 转换 Map
     *
     * @param map Map<String, String>
     * @return Map<String, Object>
     */
    private static Map<String, Object> convertMap(final Map<String, String> map) {
        Map<String, Object> data = new HashMap<>(map.size());
        for (Map.Entry<String, String> entry : map.entrySet()) {
            data.put(entry.getKey(), entry.getValue());
        }
        return data;
    }

    /**
     * 生成 MD5
     *
     * @param data 待处理数据
     * @return MD5
     */
    private static String md5(String data) {
        StringBuilder sb = new StringBuilder();
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] array = md.digest(data.getBytes(StandardCharsets.UTF_8));
            for (byte item : array) {
                sb.append(Integer.toHexString((item & 0xFF) | 0x100), 1, 3);
            }
        } catch (NoSuchAlgorithmException e) {
            log.error("生成MD5时发生异常！data={}", data, e);
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 生成 HMACSHA256
     *
     * @param data 待处理数据
     * @param key  密钥
     * @return HMACSHA256
     */
    private static String hmacsha256(String data, String key) {
        StringBuilder sb = new StringBuilder();
        try {
            Mac sha256hmac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            sha256hmac.init(secretKey);
            byte[] array = sha256hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            for (byte item : array) {
                sb.append(Integer.toHexString((item & 0xFF) | 0x100), 1, 3);
            }
        } catch (Exception e) {
            log.error("生成HMACSHA256时发生异常！data={}", data, e);
        }
        return sb.toString().toUpperCase();
    }
}
