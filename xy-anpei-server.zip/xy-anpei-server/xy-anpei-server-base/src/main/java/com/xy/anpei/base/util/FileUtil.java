package com.xy.anpei.base.util;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.FileChannel;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 文件工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-18 13:45
 */
@Slf4j
public class FileUtil {

    /**
     * 图片类型正则表达式
     */
    private static final Pattern PATTERN_IMAGE_TYPE = Pattern.compile(".*/(.*);.*");

    /**
     * Base64 转图片
     *
     * @param base64     图片的 Base64 字符串表示
     * @param parentPath 图片文件父路径
     * @param imageName  图片文件名
     * @return 图文文件全路径
     */
    public static String base64ToImage(String base64, String parentPath, String imageName) {
        // 截取 data:image/jpg;base64 及需要解析的数据
        String[] arr = base64.split(",");
        // Base64 解码
        byte[] bytes = Base64.getDecoder().decode(arr[1]);
        // 修正异常数据
        for (int i = 0; i < bytes.length; i++) {
            if (bytes[i] < 0) {
                bytes[i] += 256;
            }
        }
        // 图片类型，默认为 JPG
        Matcher matcher = PATTERN_IMAGE_TYPE.matcher(arr[0]);
        String imageType = matcher.find() ? matcher.group(1) : "jpg";
        // 图片文件全路径
        String imageFullPath = String.format("%s%s.%s",
                parentPath.endsWith(File.separator) ? parentPath : parentPath + File.separator,
                imageName,
                imageType);
        // 图片文件
        File imageFile = new File(imageFullPath);
        // 如果父目录不存在，则创建
        createParentPath(imageFile);
        // 生成图片文件
        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            fos.write(bytes);
            fos.flush();
        } catch (Exception e) {
            log.error("Base64转图片时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
        // 返回图片文件全路径
        return imageFullPath;
    }

    /**
     * 图片转 Base64
     *
     * @param imageFullPath 图片文件全路径
     * @return 图片的 Base64 字符串表示
     */
    public static String imageToBase64(String imageFullPath) {
        return imageToBase64(imageFullPath, true);
    }

    /**
     * 图片转 Base64
     *
     * @param imageFullPath 图片文件全路径
     * @param withPrefix    是否包含前缀：data:image/xxx;base64,
     * @return 图片的 Base64 字符串表示
     */
    public static String imageToBase64(String imageFullPath, boolean withPrefix) {
        try (FileInputStream fis = new FileInputStream(imageFullPath)) {
            byte[] bytes = new byte[fis.available()];
            if (fis.read(bytes) == -1) {
                return "";
            }
            String imageBase64 = Base64.getEncoder().encodeToString(bytes);
            String imageType = imageFullPath.substring(imageFullPath.lastIndexOf(".") + 1);
            return withPrefix ? String.format("data:image/%s;base64,%s", imageType, imageBase64) : imageBase64;
        } catch (Exception e) {
            log.error("图片转Base64时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 下载图片
     *
     * @param imageUrl   图片 URL
     * @param parentPath 父目录
     * @param imageName  图片文件名
     */
    public static void downloadImage(String imageUrl, String parentPath, String imageName) {
        try {
            // 构造 URL
            URL url = new URL(imageUrl);
            // 打开连接
            URLConnection connection = url.openConnection();
            // 输入流
            InputStream is = connection.getInputStream();
            // 数据缓冲
            byte[] bytes = new byte[1024];
            // 读取到的数据长度
            int len;
            // 图片文件全路径
            String imageFullPath = String.format("%s%s.jpg",
                    parentPath.endsWith(File.separator) ? parentPath : parentPath + File.separator,
                    imageName);
            // 图片文件
            File imageFile = new File(imageFullPath);
            // 如果父目录不存在，则创建
            createParentPath(imageFile);
            // 文件输出流
            FileOutputStream fos = new FileOutputStream(imageFile);
            // 开始读取
            while ((len = is.read(bytes)) != -1) {
                fos.write(bytes, 0, len);
            }
            // 关闭所有资源
            fos.close();
            is.close();

            log.info("下载图片成功：{}", imageFullPath);
        } catch (Exception e) {
            log.error("下载图片是发生异常！", e);
        }
    }

    /**
     * 创建文件
     *
     * @param filePath 文件全路径
     * @return File
     */
    public static File create(String filePath) {
        return create(new File(filePath));
    }

    /**
     * 创建文件
     *
     * @param file File
     * @return File
     */
    public static File create(File file) {
        if (!file.exists()) {
            // 如果父目录不存在，则创建
            createParentPath(file);
            try {
                // 创建文件
                if (file.createNewFile()) {
                    log.info("创建文件：{}", file.getAbsolutePath());
                }
            } catch (IOException ioe) {
                log.error("创建文件时发生异常！", ioe);
            }
        }
        return file;
    }

    /**
     * 文件复制
     *
     * @param source 源文件
     * @param dest   目标文件
     */
    public static void copy(File source, File dest) {
        try (FileChannel inputChannel = new FileInputStream(source).getChannel();
             FileChannel outputChannel = new FileOutputStream(dest).getChannel()) {
            outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 如果父目录不存在，则创建
     *
     * @param file File
     */
    public static void createParentPath(File file) {
        // 文件父目录
        File parentFile = file.getParentFile();
        // 如果父目录不存在，则创建
        if (!parentFile.exists() && parentFile.mkdirs()) {
            log.info("创建目录：{}", parentFile.getAbsolutePath());
        }
    }
}
