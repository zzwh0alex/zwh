package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:00
 */
@Repository
public interface TrainRegistrationRepository extends MyRepository<TrainRegistration, Integer> {

    /**
     * 根据培训编号查询报名记录
     *
     * @param trainId 培训编号
     * @return Optional<TrainRegistration>
     */
    Optional<TrainRegistration> findByTrainId(String trainId);

    /**
     * 根据商户订单号查询报名记录
     *
     * @param orderCode 商户订单号
     * @return Optional<TrainRegistration>
     */
    Optional<TrainRegistration> findByOrderCode(String orderCode);
}
