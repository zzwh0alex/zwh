package com.xy.anpei.base.business.domain.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 区域费用表
 *
 * @author Chen Guibiao
 * Create at 2023-05-26 14:57
 */
@Getter
@Setter
@Entity
@Table(name = "region_fee")
public class RegionFee implements Serializable {

    /**
     * 费用 ID
     */
    @Id
    @Column(name = "fee_id")
    private Integer feeId;

    /**
     * 培训费（单位：分）
     */
    @Column(name = "training_fee")
    private Integer trainingFee;

    /**
     * 省 ID
     */
    @Column(name = "province_id")
    private Integer provinceId;

    /**
     * 市 ID
     */
    @Column(name = "city_id")
    private Integer cityId;
}
