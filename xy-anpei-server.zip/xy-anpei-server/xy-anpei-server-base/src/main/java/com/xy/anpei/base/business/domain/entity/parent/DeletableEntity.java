package com.xy.anpei.base.business.domain.entity.parent;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 11:11
 */
@Getter
@Setter
@MappedSuperclass
public class DeletableEntity extends BasicEntity implements Serializable {

    /**
     * 删除标记
     * 0-未删除；1-已删除
     */
    @Column(name = "delete_flag")
    private Integer deleteFlag;

    /**
     * 删除人 ID
     */
    @JsonIgnore
    @Column(name = "delete_user")
    private String deleteUser;

    /**
     * 删除时间
     */
    @JsonIgnore
    @Column(name = "delete_time")
    private Date deleteTime;

    /**
     * 获取删除标记的中文描述
     *
     * @return 删除标记的中文描述
     */
    @JsonIgnore
    public String getDeleteDesc() {
        String deleteDesc = "";
        if (MyConst.NOT_DELETED.equals(this.deleteFlag)) {
            deleteDesc = "未删除";
        } else if (MyConst.DELETED.equals(this.deleteFlag)) {
            deleteDesc = "已删除";
        }
        return deleteDesc;
    }
}
