package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.model.ViewCoachUnit;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-20 08:53
 */
@Repository
public interface ViewCoachUnitRepository extends MyRepository<ViewCoachUnit, Integer> {

    /**
     * 根据身份证号获取教练员信息
     *
     * @param idNo 身份证号
     * @return Optional<ViewCoachUnit>
     */
    Optional<ViewCoachUnit> findByIdNo(String idNo);

    /**
     * 根据手机号码获取教练员信息
     *
     * @param phone 手机号码
     * @return Optional<ViewCoachUnit>
     */
    Optional<ViewCoachUnit> findByPhone(String phone);
}
