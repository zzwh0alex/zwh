package com.xy.anpei.base.exception;

import com.xy.anpei.base.response.ResultInterface;

/**
 * 自定义业务异常类
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 11:08
 */
public class BusinessException extends RuntimeException {

    /**
     * 返回结果
     */
    private final ResultInterface ri;

    public BusinessException(ResultInterface ri) {
        this(ri, ri.getMsg());
    }

    public BusinessException(ResultInterface ri, String errMsg) {
        super(errMsg);
        this.ri = ri;
    }

    public ResultInterface getResult() {
        return this.ri;
    }
}
