package com.xy.anpei.base.business.domain.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 教练员学时记录表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 17:59
 */
@Getter
@Setter
@Entity
@Table(name = "train_study_time")
public class TrainStudyTime implements Serializable {

    /**
     * 记录 ID
     */
    @Id
    @Column(name = "record_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer recordId;

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Column(name = "train_id")
    private String trainId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 教练员 ID
     */
    @Column(name = "coach_id")
    private Integer coachId;

    /**
     * 课程名称
     */
    @Column(name = "subject_name")
    private String subjectName;

    /**
     * 课件名称
     */
    @Column(name = "course_name")
    private String courseName;

    /**
     * 学时类型
     * 1-视频（video）；2-练习（practice）
     */
    @Column(name = "time_type")
    private Integer timeType;

    /**
     * 开始时间
     */
    @Column(name = "start_time")
    private Date startTime;

    /**
     * 结束时间
     */
    @Column(name = "end_time")
    private Date endTime;

    /**
     * 有效时长（单位：分钟）
     */
    @Column(name = "duration")
    private Integer duration;

    /**
     * 学时状态
     * 0-无效；1-有效
     */
    @Column(name = "status")
    private Integer status;

    /**
     * 学员身份证号
     */
    @Column(name = "stu_id_no")
    private String stuIdNo;

    /**
     * 访问客户端
     */
    @Column(name = "client")
    private String client;

    /**
     * 访问 IP
     */
    @Column(name = "request_ip")
    private String requestIp;

    /**
     * 备注
     */
    @Column(name = "remark")
    private String remark;

    /**
     * 照片集合
     */
    @Column(name = "photo_list")
    private String photoList;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;
}
