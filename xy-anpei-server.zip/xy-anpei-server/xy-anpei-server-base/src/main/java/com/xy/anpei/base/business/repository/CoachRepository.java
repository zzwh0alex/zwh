package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.Coach;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:03
 */
@Repository
public interface CoachRepository extends MyRepository<Coach, Integer> {

    /**
     * 根据身份证号获取教练员信息
     *
     * @param idNo 身份证号
     * @return Optional<Coach>
     */
    Optional<Coach> findByIdNo(String idNo);

    /**
     * 根据手机号码获取教练员信息
     *
     * @param phone 手机号码
     * @return Optional<Coach>
     */
    Optional<Coach> findByPhone(String phone);
}
