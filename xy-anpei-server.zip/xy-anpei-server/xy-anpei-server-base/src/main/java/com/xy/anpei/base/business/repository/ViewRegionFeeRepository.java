package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.model.ViewRegionFee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-05-26 15:16
 */
@Repository
public interface ViewRegionFeeRepository extends JpaRepository<ViewRegionFee, Integer> {
}
