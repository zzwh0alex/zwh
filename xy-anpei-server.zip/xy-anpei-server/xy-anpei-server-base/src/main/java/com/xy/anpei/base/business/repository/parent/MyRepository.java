package com.xy.anpei.base.business.repository.parent;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * 自定义 Repository 的父接口
 *
 * @author Chen Guibiao
 * Create at 2023-05-17 08:51
 */
@NoRepositoryBean
public interface MyRepository<T, ID> extends JpaRepository<T, ID> {

    /**
     * 分页查询
     *
     * @param spec     Specification
     * @param pageable Pageable
     * @return a page of T
     */
    Page<T> findAll(Specification<T> spec, Pageable pageable);
}
