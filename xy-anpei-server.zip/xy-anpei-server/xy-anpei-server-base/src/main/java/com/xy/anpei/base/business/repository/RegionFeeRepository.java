package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.RegionFee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-26 15:17
 */
@Repository
public interface RegionFeeRepository extends JpaRepository<RegionFee, Integer> {

    /**
     * 根据市 ID 查询区域费用信息
     *
     * @param cityId 市 ID
     * @return Optional<Coach>
     */
    Optional<RegionFee> findByCityId(Integer cityId);
}
