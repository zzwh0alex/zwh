package com.xy.anpei.base.util.sandpay;

import com.xy.anpei.base.constant.SandPayConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;

/**
 * 杉德支付签名工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-24 14:48
 */
@Slf4j
public class SandPayCryptoUtil {

    /**
     * 签名
     *
     * @param plaintext 明文
     * @return 签名
     */
    public static String sign(String plaintext) {
        return sign(plaintext, SandPayConst.SIGN_ALGORITHM_SHA1WITHRSA);
    }

    /**
     * 签名
     *
     * @param plaintext     明文
     * @param signAlgorithm 签名算法
     * @return 签名
     */
    public static String sign(String plaintext, String signAlgorithm) {
        return sign(plaintext, signAlgorithm, SandPayCertUtil.getPrivateKey());
    }

    /**
     * 签名
     *
     * @param plaintext     明文
     * @param signAlgorithm 签名算法
     * @param privateKey    私钥
     * @return 签名
     */
    private static String sign(String plaintext, String signAlgorithm, PrivateKey privateKey) {
        try {
            Signature signature = Signature.getInstance(signAlgorithm);
            signature.initSign(privateKey);
            signature.update(plaintext.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(signature.sign());
        } catch (Exception e) {
            log.error("[杉德支付]签名时发生异常！plaintext={}, signAlgorithm={}", plaintext, signAlgorithm, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 验签
     *
     * @param plaintext  明文
     * @param ciphertext 密文
     * @return 验签通过返回 true，否则返回 false
     */
    public static boolean verifySign(String plaintext, String ciphertext) {
        return verifySign(plaintext, ciphertext, SandPayConst.SIGN_ALGORITHM_SHA1WITHRSA);
    }

    /**
     * 验签
     *
     * @param plaintext     明文
     * @param ciphertext    密文
     * @param signAlgorithm 签名算法
     * @return 验签通过返回 true，否则返回 false
     */
    public static boolean verifySign(String plaintext, String ciphertext, String signAlgorithm) {
        return verifySign(plaintext, ciphertext, signAlgorithm, SandPayCertUtil.getPublicKey());
    }

    /**
     * 验签
     *
     * @param plaintext     明文
     * @param ciphertext    密文
     * @param signAlgorithm 签名算法
     * @param publicKey     公钥
     * @return 验签通过返回 true，否则返回 false
     */
    private static boolean verifySign(String plaintext, String ciphertext, String signAlgorithm, PublicKey publicKey) {
        if (StringUtils.isAnyBlank(plaintext, ciphertext, signAlgorithm)) {
            return false;
        }
        try {
            Signature signature = Signature.getInstance(signAlgorithm);
            signature.initVerify(publicKey);
            signature.update(plaintext.getBytes(StandardCharsets.UTF_8));
            byte[] signBytes = Base64.getDecoder().decode(ciphertext);
            return signature.verify(signBytes);
        } catch (Exception e) {
            log.error("[杉德支付]验签时发生异常！plaintext={}, ciphertext={}, signAlgorithm={}", plaintext, ciphertext, signAlgorithm, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }
}
