package com.xy.anpei.base.handler;

import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.response.Result;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;
import java.nio.file.AccessDeniedException;
import java.util.Objects;

/**
 * 全局异常处理类
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 11:25
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 1001 异常处理器
     *
     * @param manv MethodArgumentNotValidException
     * @return Result
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException manv) {
        return this.logExpMsg(Result.failure(Response.PARAM_ERROR, Objects.requireNonNull(manv.getBindingResult().getFieldError()).getDefaultMessage()), manv);
    }

    /**
     * 1001 异常处理器
     *
     * @param msrpe MissingServletRequestParameterException
     * @return Result
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public Result missingServletRequestParameterExceptionHandler(MissingServletRequestParameterException msrpe) {
        return this.logExpMsg(Result.failure(Response.PARAM_ERROR, msrpe.getMessage()), msrpe);
    }

    /**
     * 1001 异常处理器
     *
     * @param hmnre HttpMessageNotReadableException
     * @return Result
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Result httpMessageNotReadableExceptionHandler(HttpMessageNotReadableException hmnre) {
        return this.logExpMsg(Result.failure(Response.PARAM_ERROR, Objects.requireNonNull(hmnre.getMessage()).split(":")[0]), hmnre);
    }

    /**
     * 5001 异常处理器
     *
     * @param hrmnse HttpRequestMethodNotSupportedException
     * @return Result
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Result httpRequestMethodNotSupportedExceptionHandler(HttpRequestMethodNotSupportedException hrmnse) {
        return this.logExpMsg(Result.failure(Response.METHOD_NOT_SUPPORTED, hrmnse.getMessage()), hrmnse);
    }

    /**
     * 5003 异常处理器
     *
     * @param ade AccessDeniedException
     * @return Result
     */
    @ExceptionHandler(AccessDeniedException.class)
    public Result accessDeniedExceptionHandler(AccessDeniedException ade) {
        return this.logExpMsg(Result.failure(Response.FORBIDDEN, ade.getMessage()), ade);
    }

    /**
     * 5004 异常处理器
     *
     * @param nhfe NoHandlerFoundException
     * @return Result
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public Result noHandlerFoundExceptionHandler(NoHandlerFoundException nhfe) {
        return this.logExpMsg(Result.failure(Response.NOT_FOUND, nhfe.getMessage()), nhfe);
    }

    /**
     * 自定义业务异常处理器
     *
     * @param be BusinessException
     * @return Result
     */
    @ExceptionHandler(BusinessException.class)
    public Result businessExceptionHandler(BusinessException be) {
        return this.logExpMsg(Result.failure(be.getResult(), be.getMessage()), be);
    }

    /**
     * 未知异常处理器
     *
     * @param e Exception
     * @return Result
     */
    @ExceptionHandler(Exception.class)
    public Result exceptionHandler(Exception e) {
        return this.printExpMsg(Result.failure(), e);
    }

    /**
     * 记录异常日志
     *
     * @param result Result
     * @param e      Exception
     * @return Result
     */
    private Result logExpMsg(Result result, Exception e) {
        return this.logExpMsg(result, e, false);
    }

    /**
     * 打印异常日志
     *
     * @param result Result
     * @param e      Exception
     * @return Result
     */
    private Result printExpMsg(Result result, Exception e) {
        return this.logExpMsg(result, e, true);
    }

    /**
     * 记录异常日志
     *
     * @param result          Result
     * @param e               Exception
     * @param printStackTrace 是否打印堆栈跟踪信息
     * @return Result
     */
    private Result logExpMsg(Result result, Exception e, boolean printStackTrace) {
        HttpServletRequest request = SpringUtil.getRequest();
        String uri = request.getRequestURI();
        String ip = request.getHeader(MyConst.HEADER_REAL_IP);
        String simpleName = e.getClass().getSimpleName();
        String respBody = this.toJsonStr(result);
        if (printStackTrace) {
            // 从左到右依次是：异常信息、URI、IP、异常类型、应答数据
            log.error("[{}] {}, {}, {}, respBody:{}", e.getMessage(), uri, ip, simpleName, respBody, e);
        } else {
            // 从左到右依次是：提示信息、URI、IP、异常类型、应答数据
            log.info("[{}] {}, {}, {}, respBody:{}", result.getMsg(), uri, ip, simpleName, respBody);
        }
        return result;
    }

    /**
     * 对象转 JSON
     *
     * @param result Result
     * @return JSON 字符串
     */
    private String toJsonStr(Result result) {
        String jsonStr;
        try {
            jsonStr = MyUtil.toJsonStr(result);
        } catch (BusinessException be) {
            // 若转换过程中出现异常，则直接拼接 JSON 字符串
            jsonStr = String.format("{\"code\":%s,\"msg\":%s,\"traceId\":%s}", result.getCode(), result.getMsg(), result.getTraceId());
        }
        return jsonStr;
    }
}
