package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:06
 */
@Repository
public interface ProvinceRepository extends JpaRepository<Province, Integer> {
}
