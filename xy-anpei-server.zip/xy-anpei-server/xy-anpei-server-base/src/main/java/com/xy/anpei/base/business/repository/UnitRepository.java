package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 08:50
 */
@Repository
public interface UnitRepository extends MyRepository<Unit, Integer> {

    /**
     * 根据机构编号查询机构信息
     *
     * @param unitNo 机构编号
     * @return Optional<Unit>
     */
    Optional<Unit> findByUnitNo(String unitNo);
}
