package com.xy.anpei.base.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Chen Guibiao
 * Create at 2023-05-28 18:37
 */
@Getter
@Setter
@Entity
@Table(name = "view_coach_registration")
public class ViewCoachRegistration {

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Id
    @Column(name = "train_id")
    private String trainId;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 结业证地址
     */
    @Column(name = "cert_url")
    private String certUrl;
}
