package com.xy.anpei.base.page;

import org.springframework.data.domain.Pageable;

/**
 * @author Chen Guibiao
 * Create at 2023-06-26 09:53
 */
public interface PageInterface {

    /**
     * 获取 Pageable
     *
     * @return Pageable
     */
    Pageable getPageable();
}
