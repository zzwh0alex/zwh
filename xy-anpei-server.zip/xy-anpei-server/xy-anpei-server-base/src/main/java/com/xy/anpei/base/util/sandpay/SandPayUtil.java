package com.xy.anpei.base.util.sandpay;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.constant.SandPayConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 杉德支付工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-23 16:11
 */
@Slf4j
public class SandPayUtil {

    /**
     * 接口名称 Map
     */
    private static final ConcurrentHashMap<String, String> METHOD = new ConcurrentHashMap<>();

    static {
        METHOD.put(SandPayConst.METHOD_ORDER_QUERY, "订单查询");
        METHOD.put(SandPayConst.METHOD_UNIFIED_ORDER, "统一下单");
        METHOD.put(SandPayConst.METHOD_ORDER_REFUND, "退货申请");
        METHOD.put(SandPayConst.METHOD_MC_AUTO_NOTICE, "商户自主重发异步通知");
        METHOD.put(SandPayConst.METHOD_CLEAR_FILE_DOWNLOAD, "对账单申请");
        METHOD.put(SandPayConst.METHOD_ORDER_FILE_DOWNLOAD, "收款凭证下载");
    }

    /**
     * 获取接口名称描述
     *
     * @param method 接口名称
     * @return 接口名称描述
     */
    private static String getMethodDesc(String method) {
        return String.format("[%s]", METHOD.get(method));
    }

    /**
     * 获取杉德支付描述
     *
     * @param method 接口名称
     * @return 杉德支付描述
     */
    public static String getSandPayDesc(String method) {
        return String.format("[杉德支付]%s", getMethodDesc(method));
    }

    /**
     * 发送请求
     *
     * @param url    请求地址
     * @param method 接口名称
     * @param data   业务数据
     * @return 应答数据
     */
    public static JSONObject send(String url, String method, Map<String, Object> data) {
        // 获取请求参数
        Map<String, Object> params = getParams(method, data);
        // 发送请求
        HttpResponse response = HttpRequest.post(url)
                .header(SandPayConst.HEADER_KEY_CONTENT_TYPE, SandPayConst.HEADER_VALUE_CONTENT_TYPE)
                .form(params)
                .execute();
        // 应答报文
        String respBody = response.body();

        // 接口名称描述
        String methodDesc = getMethodDesc(method);
        // 日志提示信息前缀
        String logMsgPrefix = getSandPayDesc(method);
        // 日志提示信息
        String logMsg = String.format("%s{} 请求报文：%s，应答状态：%s，应答报文：{}", logMsgPrefix, JSONUtil.toJsonStr(params), JSONUtil.toJsonStr(response));

        try {
            // 解析应答报文
            respBody = URLDecoder.decode(respBody, SandPayConst.ENCODING_UTF8);
        } catch (UnsupportedEncodingException e) {
            log.error(logMsg, "[解析应答报文时发生异常]", respBody, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION, methodDesc + "应答报文解析失败");
        }
        // 日志记录请求报文和应答报文
        log.info(logMsg, "", respBody);

        // 应答报文转 Map
        Map<String, String> map = convertResultToMap(respBody);
        // 应答数据
        String respData = map.get("data");
        // 应答签名
        String respSign = map.get("sign");
        // 验签
        boolean valid = SandPayCryptoUtil.verifySign(respData, respSign);
        if (!valid) {
            log.info("{}[验签失败]", logMsgPrefix);
            throw new BusinessException(Response.SERVICE_EXCEPTION, methodDesc + "应答报文验签失败");
        }

        // 应答数据转 JSON
        JSONObject dataJson = JSONUtil.parseObj(respData);
        // 响应码
        String respCode = (String) dataJson.getByPath("head.respCode");
        // 响应描述
        String respMsg = (String) dataJson.getByPath("head.respMsg");
        if (!SandPayConst.RESP_CODE_SUCCESS.equals(respCode)) {
            log.info("{}[{} - {}]", logMsgPrefix, respCode, respMsg);
            throw new BusinessException(Response.SERVICE_EXCEPTION, methodDesc + "响应失败");
        }

        // 返回应答数据主体
        return (JSONObject) dataJson.get("body");
    }

    /**
     * 获取请求参数
     *
     * @param method 接口名称
     * @param data   业务数据
     * @return 请求参数
     */
    private static Map<String, Object> getParams(String method, Map<String, Object> data) {
        // 封装交易报文
        Map<String, Object> reqData = new LinkedHashMap<>(2);
        reqData.put("head", getHeader(method));
        reqData.put("body", data);

        // 交易报文 JSON
        String dataJson = JSONUtil.toJsonStr(reqData);

        // 整体请求报文
        Map<String, Object> reqMap = new LinkedHashMap<>(4);
        reqMap.put("charset", SandPayConst.ENCODING_UTF8);
        reqMap.put("data", dataJson);
        reqMap.put("signType", SandPayConst.SIGN_TYPE);
        reqMap.put("sign", SandPayCryptoUtil.sign(dataJson));

        // 返回整体请求报文
        return reqMap;
    }

    /**
     * 获取请求头
     *
     * @param method 接口名称
     * @return 请求头
     */
    private static Map<String, String> getHeader(String method) {
        Map<String, String> header = new LinkedHashMap<>(8);
        header.put("version", SandPayConst.VERSION);
        header.put("method", method);
        header.put("productId", SandPayConst.PRODUCT_ID);
        header.put("accessType", SandPayConst.ACCESS_TYPE);
        header.put("mid", SandPayConst.MID);
        header.put("channelType", SandPayConst.CHANNEL_TYPE);
        header.put("reqTime", MyUtil.formatTime(new Date(), MyConst.FORMAT_YMDHMS_PLAIN));
        return header;
    }

    /**
     * 结果字符串转 Map
     *
     * @param result 结果字符串
     * @return Map<String, String>
     */
    public static Map<String, String> convertResultToMap(String result) {
        if (StringUtils.isBlank(result)) {
            return new HashMap<>();
        }
        if (result.startsWith("{") && result.endsWith("}")) {
            result = result.substring(1, result.length() - 1);
        }
        return parseString(result);
    }

    /**
     * 解析字符串
     *
     * @param str 待解析的字符串
     * @return Map<String, String>
     */
    private static Map<String, String> parseString(String str) {
        Map<String, String> map = new HashMap<>(16);

        int length = str.length();
        if (length == 0) {
            return map;
        }

        // 临时值
        StringBuilder temp = new StringBuilder();
        // 当前字符
        char currChar;
        // 键名
        String key = null;
        // 是否为键名
        boolean isKey = true;
        // 值里是否有嵌套
        boolean isNest = false;
        // 嵌套配对字符
        char pairChar = 0;
        // 遍历整个待解析的字符串
        for (int i = 0; i < length; i++) {
            // 取当前字符
            currChar = str.charAt(i);
            // 如果当前是键名
            if (isKey) {
                // 如果读取到“=”，则缓存键名
                if (currChar == '=') {
                    key = temp.toString();
                    temp.setLength(0);
                    isKey = false;
                } else {
                    temp.append(currChar);
                }
                // 直接下一次循环
                continue;
            }
            // 否则（当前是键值），判断是否有嵌套
            if (isNest) {
                if (currChar == pairChar) {
                    isNest = false;
                }
            } else {
                if (currChar == '{') {
                    isNest = true;
                    pairChar = '}';
                } else if (currChar == '[') {
                    isNest = true;
                    pairChar = ']';
                }
            }
            // 如果读取到“&”分隔符，且这个分隔符不是值域，则添加到 Map 里
            if (currChar == '&' && !isNest) {
                putKeyValueToMap(temp.toString(), false, key, map);
                temp.setLength(0);
                isKey = true;
            } else {
                temp.append(currChar);
            }
        }
        putKeyValueToMap(temp.toString(), isKey, key, map);

        return map;
    }

    /**
     * 添加键值对到 Map
     *
     * @param temp  临时值
     * @param isKey 是否为键名
     * @param key   键名
     * @param map   目标 Map
     */
    private static void putKeyValueToMap(String temp, boolean isKey, String key, Map<String, String> map) {
        if (isKey) {
            if (temp.length() == 0) {
                throw new RuntimeException("QString format illegal");
            }
            map.put(temp, "");
        } else {
            if (key.length() == 0) {
                throw new RuntimeException("QString format illegal");
            }
            map.put(key, temp);
        }
    }
}
