package com.xy.anpei.base.util.sandpay;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 杉德支付证书工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-24 14:03
 */
@Slf4j
public class SandPayCertUtil {

    /**
     * 公钥键名
     */
    private static final String PUBLIC_KEY = "public_key";

    /**
     * 公钥键名
     */
    private static final String PRIVATE_KEY = "private_key";

    /**
     * 证书 Map
     */
    private static final ConcurrentHashMap<String, Object> CERT = new ConcurrentHashMap<>();

    /**
     * 初始化杉德公钥与私钥
     *
     * @param publicKeyPath  公钥路径
     * @param privateKeyPath 私钥路径
     * @param keyPassword    私钥密码
     */
    public static void init(String publicKeyPath, String privateKeyPath, String keyPassword) {
        // 初始化公钥
        initPublicKey(publicKeyPath);
        // 初始化私钥
        initPrivateKey(privateKeyPath, keyPassword);
    }

    /**
     * 获取公钥
     *
     * @return PublicKey
     */
    public static PublicKey getPublicKey() {
        return (PublicKey) CERT.get(PUBLIC_KEY);
    }

    /**
     * 获取公钥
     *
     * @return PublicKey
     */
    public static PrivateKey getPrivateKey() {
        return (PrivateKey) CERT.get(PRIVATE_KEY);
    }

    /**
     * 初始化公钥
     *
     * @param publicKeyPath 公钥路径
     */
    private static void initPublicKey(String publicKeyPath) {
        try (FileInputStream fis = new FileInputStream(publicKeyPath)) {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) cf.generateCertificate(fis);
            CERT.put(PUBLIC_KEY, cert.getPublicKey());
            log.info("[杉德支付] 加载公钥成功！公钥路径：{}", publicKeyPath);
        } catch (Exception e) {
            log.error("[杉德支付] 加载杉德公钥时发生异常！publicKeyPath={}", publicKeyPath, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 初始化私钥
     *
     * @param privateKeyPath 私钥路径
     * @param keyPassword    私钥密码
     */
    private static void initPrivateKey(String privateKeyPath, String keyPassword) {
        try (final FileInputStream fis = new FileInputStream(privateKeyPath)) {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            char[] pwdChars = keyPassword.toCharArray();
            ks.load(fis, pwdChars);
            Enumeration<String> aliases = ks.aliases();
            String keyAlias = aliases.hasMoreElements() ? aliases.nextElement() : null;
            CERT.put(PRIVATE_KEY, ks.getKey(keyAlias, pwdChars));
            log.info("[杉德支付] 加载私钥成功！私钥路径：{}", privateKeyPath);
        } catch (Exception e) {
            log.error("[杉德支付] 加载杉德私钥时发生异常！privateKeyPath={}", privateKeyPath, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }
}
