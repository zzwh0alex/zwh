package com.xy.anpei.base.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 自定义的 JPA 查询注解
 * <p>
 * 注解类型元素说明：
 * orderBy 仅在类上使用时有效，
 * 除 orderBy 外的注解类型元素仅在字段上使用时有效
 *
 * @author Chen Guibiao
 * Create at 2023-06-26 10:13
 */
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface JpaFmt {

    /**
     * 别名（别名要与实体类成员变量一致）
     * 不填时，默认使用被注解的字段名
     *
     * @return 别名
     */
    String alias() default "";

    /**
     * 数据库条件查询操作符
     * 集合    使用 IN 操作符
     * 非集合  使用 EQUAL 操作符
     * IGNORE 无操作（默认项）
     *
     * @return 查询操作符
     */
    Opt opt() default Opt.IGNORE;

    /**
     * GREATER_THAN、LESS_THAN、BETWEEN 操作符补充
     * 是否包含等于（默认不包含）
     *
     * @return boolean
     */
    boolean equal() default false;

    /**
     * LIKE 操作符补充
     * Like.BOTH    前后都加 %（默认项）
     * Like.PREFIX  前面添加 %
     * Like.SUFFIX  后面添加 %
     *
     * @return LIKE 操作符补充
     */
    Like like() default Like.BOTH;

    /**
     * EQUAL、LIKE、IN 操作符补充
     * 前面是否添加 not（默认不添加）
     *
     * @return boolean
     */
    boolean not() default false;

    /**
     * 排序
     *
     * @return SortExp[]
     */
    SortExp[] orderBy() default {};

    /**
     * 数据库查询操作符
     */
    enum Opt {

        /**
         * 等于（=）
         */
        EQUAL,

        /**
         * 相似（%）
         */
        LIKE,

        /**
         * in
         */
        IN,

        /**
         * 大于或等于（>=）
         */
        GREATER_THAN,

        /**
         * 小于或等于（<=）
         */
        LESS_THAN,

        /**
         * 介于
         */
        BETWEEN,

        /**
         * 无操作
         */
        IGNORE
    }

    /**
     * LIKE 操作符补充
     */
    enum Like {

        /**
         * 前后都加 %
         */
        BOTH,

        /**
         * 前面添加 %
         */
        PREFIX,

        /**
         * 后面添加 %
         */
        SUFFIX
    }
}
