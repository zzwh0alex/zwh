package com.xy.anpei.base.constant;

/**
 * 自定义常量 - 重庆安运科技
 *
 * @author Chen Guibiao
 * Create at 2023-07-13 10:17
 */
public class CqayConst {

    /**
     * 请求头属性名 - Authorization
     */
    public static final String HEADER_KEY_AUTHORIZATION = "Authorization";

    /**
     * 请求头属性名 - Content-Type
     */
    public static final String HEADER_KEY_CONTENT_TYPE = "Content-Type";

    /**
     * 请求头属性名 - Accept
     */
    public static final String HEADER_KEY_ACCEPT = "Accept";

    /**
     * 请求头属性值 - Content-Type
     */
    public static final String HEADER_VALUE_CONTENT_TYPE = "application/json;charset=UTF-8";

    /**
     * 请求头属性值 - Accept
     */
    public static final String HEADER_VALUE_ACCEPT = "application/json";

    /**
     * URL - 教练注册
     */
    public static final String URL_COACH_REGISTER = "/coach/info";

    /**
     * URL - 教练信息修改
     */
    public static final String URL_COACH_UPDATE = "/coach/update";

    /**
     * URL - 查询虚拟卡
     */
    public static final String URL_QUERY_STORAGE = "/coach/virtual/query-storage";
}
