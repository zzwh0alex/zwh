package com.xy.anpei.base.util;

import com.xy.anpei.base.constant.MyConst;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * AES 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-17 16:24
 */
@Slf4j
public class AesUtil {

    private static final String AES = "AES";

    private static final String SHA1PRNG = "SHA1PRNG";

    private static final int TAG_LENGTH = 128;

    /**
     * AES 加密
     *
     * @param plaintext 明文
     * @return 密文
     */
    public static String encrypt(String plaintext) {
        return encrypt(plaintext, MyConst.AES_SECRET_KEY);
    }

    /**
     * AES 加密
     *
     * @param plaintext 明文
     * @param secretKey 密钥
     * @return 密文
     */
    public static String encrypt(String plaintext, String secretKey) {
        String ciphertext = null;
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(AES);
            keyGen.init(TAG_LENGTH);
            Cipher cipher = Cipher.getInstance(AES);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(secretKey.getBytes(), AES));
            byte[] bytes = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
            ciphertext = Base64.getEncoder().encodeToString(bytes);
        } catch (Exception e) {
            log.error("AES加密时发生异常！[{} - {}] plaintext ==> {}", e.getClass().getSimpleName(), e.getMessage(), plaintext);
        }
        return ciphertext;
    }

    /**
     * AES 解密
     *
     * @param ciphertext 密文
     * @return 明文
     */
    public static String decrypt(String ciphertext) {
        return decrypt(ciphertext, MyConst.AES_SECRET_KEY);
    }

    /**
     * AES 解密
     *
     * @param ciphertext 密文
     * @param secretKey  密钥
     * @return 明文
     */
    public static String decrypt(String ciphertext, String secretKey) {
        String plaintext = null;
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(AES);
            SecureRandom random = SecureRandom.getInstance(SHA1PRNG);
            random.setSeed(secretKey.getBytes(StandardCharsets.UTF_8));
            keyGen.init(TAG_LENGTH, random);
            Cipher cipher = Cipher.getInstance(AES);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(secretKey.getBytes(), AES));
            byte[] encryptBytes = Base64.getDecoder().decode(ciphertext);
            byte[] decryptBytes = cipher.doFinal(encryptBytes);
            plaintext = new String(decryptBytes);
        } catch (Exception e) {
            log.error("AES解密时发生异常！[{} - {}] ciphertext ==> {}", e.getClass().getSimpleName(), e.getMessage(), ciphertext);
        }
        return plaintext;
    }
}
