package com.xy.anpei.base.business.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xy.anpei.base.business.domain.entity.parent.DeletableEntity;
import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 教练员信息表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 17:42
 */
@Getter
@Setter
@Entity
@Table(name = "info_coach")
public class Coach extends DeletableEntity implements Serializable {

    /**
     * 教练员 ID
     */
    @Id
    @Column(name = "coach_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer coachId;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 培训机构 ID
     */
    @Column(name = "unit_id")
    private Integer unitId;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 联系地址
     */
    @Column(name = "address")
    private String address;

    /**
     * 个人照片相对路径
     */
    @Column(name = "photo_path")
    private String photoPath;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @JsonIgnore
    @Column(name = "status")
    private Integer status;

    /**
     * 账号密码
     */
    @JsonIgnore
    @Column(name = "password")
    private String password;

    /**
     * 盐
     */
    @JsonIgnore
    @Column(name = "salt")
    private String salt;

    /**
     * 密码明文
     */
    @JsonIgnore
    @Column(name = "plaintext")
    private String plaintext;

    /**
     * 注册时间
     */
    @Column(name = "registration_time")
    @JsonFormat(pattern = MyConst.FORMAT_YMDHMS, timezone = "GMT+8")
    private Date registrationTime;

    /**
     * 微信小程序用户 openId
     */
    @JsonIgnore
    @Column(name = "open_id")
    private String openId;
}
