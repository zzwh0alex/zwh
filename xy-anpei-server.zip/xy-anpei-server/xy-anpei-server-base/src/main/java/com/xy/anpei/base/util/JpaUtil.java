package com.xy.anpei.base.util;

import com.xy.anpei.base.annotation.JpaFmt;
import com.xy.anpei.base.annotation.SortExp;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.page.PageInterface;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JPA 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-18 11:44
 */
@Slf4j
public class JpaUtil {

    /**
     * 获取默认的 Example
     *
     * @param clazz Class<T>
     * @param <T>   泛型
     * @return Example<T>
     */
    public static <T> Example<T> getDefaultExample(Class<T> clazz) {
        Map<String, Object> criteriaMap = new HashMap<>(1);
        criteriaMap.put("deleteFlag", MyConst.NOT_DELETED);
        return getExample(clazz, criteriaMap);
    }

    /**
     * 获取默认的 Example
     *
     * @param clazz       Class<T>
     * @param criteriaMap 筛选条件
     * @param <T>         泛型
     * @return Example<T>
     */
    public static <T> Example<T> getExample(Class<T> clazz, Map<String, Object> criteriaMap) {
        try {
            // 实例化对象
            T instance = clazz.newInstance();
            // 遍历筛选条件
            for (Map.Entry<String, Object> entry : criteriaMap.entrySet()) {
                // 成员变量名
                String key = entry.getKey();
                // 成员变量值
                Object value = entry.getValue();
                // 调用 set 方法设置成员变量的值
                clazz.getMethod(MyUtil.setMethodName(key), value.getClass()).invoke(instance, value);
            }
            // 返回 Example
            return Example.of(instance);
        } catch (Exception e) {
            String criteriaMapJson = MyUtil.toJsonStr(criteriaMap, "JsonProcessingException");
            log.error("获取Example时发生异常！clazz={}，criteriaMap={}", clazz.getName(), criteriaMapJson, e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 根据条件分页查询数据
     *
     * @param myRepository MyRepository
     * @param queryObj     查询过滤条件
     * @param <T>          MyRepository 的参数化类型
     * @return a page of T
     */
    public static <T> Page<T> getPage(MyRepository<T, ?> myRepository, Object queryObj) {
        // 返回分页查询结果
        return myRepository.findAll((Specification<T>) (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            // 拼接查询条件
            buildPredicates(predicates, root, cb, queryObj);
            // 添加排序
            addSort(root, query, cb, queryObj);
            // 定义数组构造入参
            Predicate[] array = new Predicate[predicates.size()];
            // 返回与 where 子句限制对应的谓词，如果没有指定限制，则返回 null
            return query.where(predicates.toArray(array)).getRestriction();
        }, ((PageInterface) queryObj).getPageable());
    }

    /**
     * 封装查询条件
     *
     * @param predicates List<Predicate>
     * @param root       Root<T>
     * @param cb         CriteriaBuilder
     * @param queryObj   查询过滤条件
     * @param <T>        MyRepository 的参数化类型
     */
    private static <T> void buildPredicates(List<Predicate> predicates, Root<T> root, CriteriaBuilder cb, Object queryObj) {
        try {
            // 获取请求对象的运行时类
            Class<?> clazz = queryObj.getClass();
            // 获取该类的所有声明的字段
            Field[] fields = clazz.getDeclaredFields();
            // 遍历所有字段，封装查询条件
            for (Field field : fields) {
                // 获取字段上的 JpaFmt 注解
                JpaFmt fieldFmt = field.getAnnotation(JpaFmt.class);
                // 若字段上无 JpaFmt 注解，直接跳过
                if (null == fieldFmt) {
                    continue;
                }
                // 获取字段名称
                String fieldName = field.getName();
                // 获取字段的值
                Object fieldValue = clazz.getMethod(MyUtil.getMethodName(fieldName)).invoke(queryObj);
                // 若字段值为 null，跳过
                if (null == fieldValue) {
                    continue;
                }
                // 若字段类型为字符串
                if (fieldValue instanceof String) {
                    // 则去掉所有空格
                    fieldValue = StringUtils.deleteWhitespace(fieldValue.toString());
                    // 若字段值为空白字符串，也跳过
                    if ("".equals(fieldValue)) {
                        continue;
                    }
                }
                // 匹配查询操作符，封装查询条件
                matchOpt(predicates, root, cb, fieldFmt, fieldName, fieldValue);
            }
        } catch (Exception e) {
            log.error("封装查询条件时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * @param predicates List<Predicate>
     * @param root       Root<T>
     * @param cb         CriteriaBuilder
     * @param fieldFmt   JpaFmt
     * @param fieldName  字段名称
     * @param fieldValue 字段值
     * @param <T>        MyRepository 的参数化类型
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T> void matchOpt(List<Predicate> predicates, Root<T> root, CriteriaBuilder cb, JpaFmt fieldFmt, String fieldName, Object fieldValue) {
        // 获取查询操作符
        JpaFmt.Opt opt = fieldFmt.opt();
        // 获取字段别名
        String alias = fieldFmt.alias().trim();
        // 设置实际查询时的字段名
        String targetName = StringUtils.isBlank(alias) ? fieldName : alias;
        switch (opt) {
            case EQUAL:
                // 判断是否为 not
                if (fieldFmt.not()) {
                    predicates.add(cb.notEqual(root.get(targetName), fieldValue));
                } else {
                    predicates.add(cb.equal(root.get(targetName), fieldValue));
                }
                break;
            case LIKE:
                if (fieldValue instanceof String) {
                    // 转为字符串
                    String likeValue = (String) fieldValue;
                    // 获取 like 操作符补充信息
                    JpaFmt.Like like = fieldFmt.like();
                    // 根据补充信息设置匹配模式
                    if (JpaFmt.Like.PREFIX.equals(like)) {
                        likeValue = "%" + likeValue;
                    } else if (JpaFmt.Like.SUFFIX.equals(like)) {
                        likeValue = likeValue + "%";
                    } else {
                        likeValue = "%" + likeValue + "%";
                    }
                    // 判断是否为 not
                    if (fieldFmt.not()) {
                        predicates.add(cb.notLike(root.get(targetName), likeValue));
                    } else {
                        predicates.add(cb.like(root.get(targetName), likeValue));
                    }
                }
                break;
            case IN:
                if (fieldValue instanceof Object[]) {
                    Object[] objs = (Object[]) fieldValue;
                    CriteriaBuilder.In<Object> in = cb.in(root.get(targetName));
                    for (Object obj : objs) {
                        in.value(obj);
                    }
                    // 判断是否为 not
                    if (fieldFmt.not()) {
                        predicates.add(in.not());
                    } else {
                        predicates.add(in);
                    }
                }
                break;
            case GREATER_THAN:
                if (fieldFmt.equal()) {
                    predicates.add(cb.greaterThanOrEqualTo(root.get(targetName), (Comparable) fieldValue));
                } else {
                    predicates.add(cb.greaterThan(root.get(targetName), (Comparable) fieldValue));
                }
                break;
            case LESS_THAN:
                if (fieldFmt.equal()) {
                    predicates.add(cb.lessThanOrEqualTo(root.get(targetName), (Comparable) fieldValue));
                } else {
                    predicates.add(cb.lessThan(root.get(targetName), (Comparable) fieldValue));
                }
                break;
            case BETWEEN:
                if (fieldValue instanceof Object[]) {
                    Object[] objs = (Object[]) fieldValue;
                    if (fieldFmt.equal()) {
                        predicates.add(cb.greaterThanOrEqualTo(root.get(targetName), (Comparable) objs[0]));
                        predicates.add(cb.lessThanOrEqualTo(root.get(targetName), (Comparable) objs[1]));
                    } else {
                        predicates.add(cb.greaterThan(root.get(targetName), (Comparable) objs[0]));
                        predicates.add(cb.lessThan(root.get(targetName), (Comparable) objs[1]));
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * 添加排序
     *
     * @param root     Root<T>
     * @param query    CriteriaQuery<?>
     * @param cb       CriteriaBuilder
     * @param queryObj 查询过滤条件
     * @param <T>      MyRepository 的参数化类型
     */
    private static <T> void addSort(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb, Object queryObj) {
        // 获取类上的 JpaFmt 注解
        JpaFmt typeFmt = queryObj.getClass().getAnnotation(JpaFmt.class);
        // 若无注解则直接返回
        if (null == typeFmt) {
            return;
        }
        // 获取排序字段
        SortExp[] exps = typeFmt.orderBy();
        // 若无配置则直接返回
        if (exps.length == 0) {
            return;
        }
        List<Order> orders = new ArrayList<>(exps.length);
        for (SortExp exp : exps) {
            // 获取排序字段名称
            String name = exp.name().trim();
            if (StringUtils.isBlank(name)) {
                continue;
            }
            // 根据配置设置排序方向
            if (exp.direction().isDescending()) {
                orders.add(cb.desc(root.get(name)));
            } else {
                orders.add(cb.asc(root.get(name)));
            }
        }
        // 添加排序
        query.orderBy(orders);
    }
}
