package com.xy.anpei.base.business.domain.model;

import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-05-20 08:04
 */
@Getter
@Setter
@Entity
@Table(name = "view_coach_unit")
public class ViewCoachUnit implements Serializable {

    /**
     * 教练员 ID
     */
    @Id
    @Column(name = "coach_id")
    private Integer coachId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 联系地址
     */
    @Column(name = "coach_address")
    private String address;

    /**
     * 个人照片相对路径
     */
    @Column(name = "photo_path")
    private String photo;

    /**
     * 账号状态
     * 0-停用；1-启用
     */
    @Column(name = "status")
    private Integer status;

    /**
     * 注册时间
     */
    @Column(name = "registration_time")
    private Date registrationTime;

    /**
     * 培训机构 ID
     */
    @Column(name = "unit_id")
    private Integer unitId;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "unit_full_name")
    private String unitFullName;

    /**
     * 所属省
     */
    @Column(name = "province_id")
    private Integer provinceId;

    /**
     * 所属市
     */
    @Column(name = "city_id")
    private Integer cityId;

    /**
     * 所属区/县
     */
    @Column(name = "district_id")
    private Integer districtId;

    /**
     * 获取状态的中文描述
     *
     * @return 状态的中文描述
     */
    public String getStatusDesc() {
        String statusDesc = "";
        if (MyConst.STATUS_ENABLED.equals(this.status)) {
            statusDesc = "正常";
        } else if (MyConst.STATUS_DISABLED.equals(this.status)) {
            statusDesc = "停用";
        }
        return statusDesc;
    }
}
