package com.xy.anpei.base.constant;

/**
 * 自定义常量 - 杉德支付
 *
 * @author Chen Guibiao
 * Create at 2023-05-24 14:45
 */
public class SandPayConst {

    /**
     * 版本号
     */
    public static final String VERSION = "1.0";

    /**
     * 产品编码
     * <p>
     * 详见杉德产品编码：https://open.sandpay.com.cn/product/detail/43984//
     */
    public static final String PRODUCT_ID = "00002021";

    /**
     * 接入类型
     * <p>
     * 1-普通商户接入
     * 2-平台商户接入
     * 3-核心企业商户接入
     */
    public static final String ACCESS_TYPE = "1";

    /**
     * 商户 ID
     */
    public static final String MID = "6888801018076";

    /**
     * 渠道类型
     * <p>
     * 07-互联网
     * 08-移动端
     */
    public static final String CHANNEL_TYPE = "08";

    /**
     * 字符集
     */
    public static final String ENCODING_UTF8 = "UTF-8";

    /**
     * 请求头属性名 - Content-Type
     */
    public static final String HEADER_KEY_CONTENT_TYPE = "Content-Type";

    /**
     * 请求头属性值 - Content-Type
     */
    public static final String HEADER_VALUE_CONTENT_TYPE = "application/x-www-form-urlencoded;charset=" + ENCODING_UTF8;

    /**
     * 签名类型 - SHA1WithRSA
     */
    public static final String SIGN_TYPE = "01";

    /**
     * 签名算法 - SHA1WithRSA
     */
    public static final String SIGN_ALGORITHM_SHA1WITHRSA = "SHA1WithRSA";

    /**
     * 字段 - 响应码
     */
    public static final String FIELD_RESP_CODE = "respCode";

    /**
     * 字段 - 响应描述
     */
    public static final String FIELD_RESP_MSG = "respMsg";

    /**
     * 成功响应码 - 000000
     */
    public static final String RESP_CODE_SUCCESS = "000000";

    /**
     * 异步通知响应 - 成功字符串
     */
    public static final String CALLBACK_RESP_SUCCESS = "respCode=000000";

    /**
     * 异步通知响应 - 失败字符串
     */
    public static final String CALLBACK_RESP_FAILURE = "respCode=999999";

    /**
     * 生产环境请求地址前缀
     */
    public static final String BASE_URL = "https://cashier.sandpay.com.cn/gateway/api";

    /**
     * 接口地址 - 统一下单
     */
    public static final String URL_UNIFIED_ORDER = BASE_URL + "/order/pay";

    /**
     * 接口地址 - 订单查询
     */
    public static final String URL_ORDER_QUERY = BASE_URL + "/order/query";

    /**
     * 接口地址 - 退货申请
     */
    public static final String URL_ORDER_REFUND = BASE_URL + "/order/refund";

    /**
     * 接口地址 - 商户自主重发异步通知
     */
    public static final String URL_MC_AUTO_NOTICE = BASE_URL + "/order/mcAutoNotice";

    /**
     * 接口地址 - 对账单申请
     */
    public static final String URL_CLEARFILE_DOWNLOAD = BASE_URL + "/clearfile/download";

    /**
     * 接口地址 - 收款凭证下载
     */
    public static final String URL_ORDER_FILE_DOWNLOAD = "https://cashier.sandpay.com.cn/gw/api/orderfile/download";

    /**
     * 接口名称 - 统一下单
     */
    public static final String METHOD_UNIFIED_ORDER = "sandpay.trade.pay";

    /**
     * 接口名称 - 订单查询
     */
    public static final String METHOD_ORDER_QUERY = "sandpay.trade.query";

    /**
     * 接口名称 - 退货申请
     */
    public static final String METHOD_ORDER_REFUND = "sandpay.trade.refund";

    /**
     * 接口名称 - 商户自主重发异步通知
     */
    public static final String METHOD_MC_AUTO_NOTICE = "sandpay.trade.notify";

    /**
     * 接口名称 - 对账单申请
     */
    public static final String METHOD_CLEAR_FILE_DOWNLOAD = "sandpay.trade.download";

    /**
     * 接口名称 - 收款凭证下载
     */
    public static final String METHOD_ORDER_FILE_DOWNLOAD = "sandPay.orderFile.download";
}
