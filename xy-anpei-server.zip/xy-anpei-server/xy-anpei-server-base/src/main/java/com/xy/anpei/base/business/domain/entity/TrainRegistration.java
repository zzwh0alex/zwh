package com.xy.anpei.base.business.domain.entity;

import com.xy.anpei.base.constant.MyConst;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 教练员培训报名表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 17:49
 */
@Getter
@Setter
@Entity
@Table(name = "train_registration")
public class TrainRegistration implements Serializable {

    /**
     * 报名 ID
     */
    @Id
    @Column(name = "reg_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer regId;

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Column(name = "train_id")
    private String trainId;

    /**
     * 地级市行政区划代码
     */
    @Column(name = "area_code")
    private Integer areaCode;

    /**
     * 培训机构 ID
     */
    @Column(name = "unit_id")
    private Integer unitId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 培训机构简称
     */
    @Column(name = "unit_name")
    private String unitName;

    /**
     * 培训机构全称
     */
    @Column(name = "unit_full_name")
    private String unitFullName;

    /**
     * 教练员 ID
     */
    @Column(name = "coach_id")
    private Integer coachId;

    /**
     * 教练员姓名
     */
    @Column(name = "coach_name")
    private String coachName;

    /**
     * 身份证号
     */
    @Column(name = "id_no")
    private String idNo;

    /**
     * 手机号码
     */
    @Column(name = "phone")
    private String phone;

    /**
     * 报名照片相对路径
     */
    @Column(name = "photo_path")
    private String photoPath;

    /**
     * 培训年度
     */
    @Column(name = "train_year")
    private Integer trainYear;

    /**
     * 地址
     */
    @Column(name = "address")
    private String address;

    /**
     * 商户订单号
     */
    @Column(name = "order_code")
    private String orderCode;

    /**
     * 订单金额（单位：分）
     */
    @Column(name = "total_amount")
    private Integer totalAmount;

    /**
     * 优惠金额（单位：分）
     */
    @Column(name = "disc_amount")
    private Integer discAmount;

    /**
     * 买家付款金额（单位：分）
     */
    @Column(name = "buyer_pay_amount")
    private Integer buyerPayAmount;

    /**
     * 交易流水号
     */
    @Column(name = "trade_no")
    private String tradeNo;

    /**
     * 支付状态
     * 0-待支付；1-支付成功；2-支付失败
     */
    @Column(name = "pay_status")
    private Integer payStatus;

    /**
     * 支付时间
     */
    @Column(name = "pay_time")
    private Date payTime;

    /**
     * 交易结果异步通知报文
     */
    @Column(name = "trade_result_msg")
    private String tradeResultMsg;

    /**
     * 商户退款单号
     */
    @Column(name = "refund_order_code")
    private String refundOrderCode;

    /**
     * 退款金额（单位：分）
     */
    @Column(name = "refund_amount")
    private Integer refundAmount;

    /**
     * 退款时间
     */
    @Column(name = "refund_time")
    private Date refundTime;

    /**
     * 交易退款异步通知报文
     */
    @Column(name = "refund_result_msg")
    private String refundResultMsg;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 获取支付状态的中文描述
     *
     * @return 权限支付的中文描述
     */
    public String getPayStatusDesc() {
        String statusDesc = "";
        if (MyConst.PAY_STATUS_WAIT.equals(this.payStatus)) {
            statusDesc = "待支付";
        } else if (MyConst.PAY_STATUS_SUCCESS.equals(this.payStatus)) {
            statusDesc = "支付成功";
        } else if (MyConst.PAY_STATUS_FAILED.equals(this.payStatus)) {
            statusDesc = "支付失败";
        }
        return statusDesc;
    }
}
