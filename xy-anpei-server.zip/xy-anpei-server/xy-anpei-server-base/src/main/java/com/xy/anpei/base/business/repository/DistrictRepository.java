package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:04
 */
@Repository
public interface DistrictRepository extends JpaRepository<District, Integer> {

    /**
     * 根据市区划代码查询区/县列表
     *
     * @param parentId 市区划代码
     * @return a list of District
     */
    List<District> findByParentId(Integer parentId);
}
