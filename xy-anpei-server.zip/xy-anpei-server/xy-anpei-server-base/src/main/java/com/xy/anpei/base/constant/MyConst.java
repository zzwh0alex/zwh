package com.xy.anpei.base.constant;

/**
 * 自定义常量
 *
 * @author Chen Guibiao
 * Create at 2023-05-17 10:31
 */
public class MyConst {

    /**
     * 停用
     */
    public static final Integer STATUS_DISABLED = 0;

    /**
     * 启用
     */
    public static final Integer STATUS_ENABLED = 1;

    /**
     * 性别 - 未知
     */
    public static final Integer GENDER_UNKNOWN = 0;

    /**
     * 性别 - 男
     */
    public static final Integer GENDER_MALE = 1;

    /**
     * 性别 - 女
     */
    public static final Integer GENDER_FEMALE = 2;

    /**
     * 未删除
     */
    public static final Integer NOT_DELETED = 0;

    /**
     * 已删除
     */
    public static final Integer DELETED = 1;

    /**
     * 请求头 - openId
     */
    public static final String HEADER_OPEN_ID = "openId";

    /**
     * 请求头 - coachId
     */
    public static final String HEADER_COACH_ID = "coachId";

    /**
     * 请求头 - unitId
     */
    public static final String HEADER_UNIT_ID = "unitId";

    /**
     * 请求头 - token
     */
    public static final String HEADER_TOKEN = "token";

    /**
     * 真实 IP
     */
    public static final String HEADER_REAL_IP = "X-Real-IP";

    /**
     * AES 密钥
     */
    public static final String AES_SECRET_KEY = "kC6ZLCXGGu7XHLcnLifusBwVBZTvWE7a";

    /**
     * 手机号码长度
     */
    public static final int PHONE_LENGTH = 11;

    /**
     * 身份证号长度 - 15
     */
    public static final int ID_CARD_LENGTH_15 = 15;

    /**
     * 身份证号长度 - 18
     */
    public static final int ID_CARD_LENGTH_18 = 18;

    /**
     * 时间格式（yyyy-MM-dd）
     */
    public static final String FORMAT_YMD = "yyyy-MM-dd";

    /**
     * 时间格式（yyyyMMdd）
     */
    public static final String FORMAT_YMD_PLAIN = "yyyyMMdd";

    /**
     * 时间格式（yyyy-MM-dd HH:mm:ss）
     */
    public static final String FORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";

    /**
     * 时间格式（yyyyMMddHHmmss）
     */
    public static final String FORMAT_YMDHMS_PLAIN = "yyyyMMddHHmmss";

    /**
     * 微信接口前缀
     */
    public static final String WX_BASE_API = "https://api.weixin.qq.com";

    /**
     * 学时类型 - 视频
     */
    public static final String TIME_TYPE_VIDEO_STR = "video";

    /**
     * 学时类型 - 练习
     */
    public static final String TIME_TYPE_PRACTICE_STR = "practice";

    /**
     * 学时类型 - 视频
     */
    public static final int TIME_TYPE_VIDEO_INT = 1;

    /**
     * 学时类型 - 练习
     */
    public static final int TIME_TYPE_PRACTICE_INT = 2;

    /**
     * 签名类型 MD5
     */
    public static final String SIGN_TYPE_MD5 = "MD5";

    /**
     * 签名类型 HMAC-SHA256
     */
    public static final String SIGN_TYPE_HMACSHA256 = "HMAC-SHA256";

    /**
     * 字段 sign，签名
     */
    public static final String FIELD_SIGN = "sign";

    /**
     * 字段 signType，签名类型
     */
    public static final String FIELD_SIGN_TYPE = "signType";

    /**
     * 字段 requestTime，请求时间
     */
    public static final String FIELD_REQUEST_TIME = "requestTime";

    /**
     * 支付状态 - 待支付
     */
    public static final Integer PAY_STATUS_WAIT = 0;

    /**
     * 支付状态 - 支付成功
     */
    public static final Integer PAY_STATUS_SUCCESS = 1;

    /**
     * 支付状态 - 支付失败
     */
    public static final Integer PAY_STATUS_FAILED = 2;

    /**
     * 订单状态 - 成功
     */
    public static final String ORDER_STATUS_SUCCESS = "1";
}
