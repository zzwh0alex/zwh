package com.xy.anpei.base.util;

import cn.hutool.json.JSONUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-22 16:41
 */
@Slf4j
public class MyUtil {

    private static final String SYMBOLS_INT = "0123456789";

//    private static final String aaaaaa_aaaa=

    private static final String SYMBOLS_STR = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private static final Random RANDOM = new SecureRandom();

    /**
     * 生成 32 位随机字符串
     *
     * @return String 32 位随机字符串
     */
    public static String generateNonceStr() {
        return generateNonceStr(32);
    }

    /**
     * 生成指定长度的随机串
     *
     * @param length 长度
     * @return 指定长度的随机串
     */
    public static String generateNonceStr(int length) {
        char[] nonceChars = new char[length];
        for (int index = 0; index < nonceChars.length; ++index) {
            nonceChars[index] = SYMBOLS_STR.charAt(RANDOM.nextInt(SYMBOLS_STR.length()));
        }
        return new String(nonceChars);
    }

    /**
     * 生成指定长度的数字随机串
     *
     * @param length 长度
     * @return 指定长度的数字随机串
     */
    public static String getRandomNum(int length) {
        char[] nonceChars = new char[length];
        for (int index = 0; index < nonceChars.length; ++index) {
            nonceChars[index] = SYMBOLS_INT.charAt(RANDOM.nextInt(SYMBOLS_INT.length()));
        }
        return new String(nonceChars);
    }

    /**
     * 获取指定范围内的随机整数
     *
     * @param min 最小值
     * @param max 最大值
     * @return 指定范围内的随机整数（包含 min 和 max）
     */
    public static int getRandomNumInRange(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("max must be greater than or equal to min");
        }
        return (min == max) ? min : RANDOM.nextInt((max - min) + 1) + min;
    }

    /**
     * 随机从指定集合中获取一个元素
     *
     * @param objs 集合
     * @return 集合中的一个元素
     */
    public static Object getRandomFrom(Object... objs) {
        return (objs.length == 0) ? null : objs[getRandomNumInRange(0, objs.length - 1)];
    }

    /**
     * get 方法名称
     *
     * @param fieldName 成员变量名称
     * @return get 方法名称
     */
    public static String getMethodName(String fieldName) {
        return methodName("get", fieldName);
    }

    /**
     * set 方法名称
     *
     * @param fieldName 成员变量名称
     * @return set 方法名称
     */
    public static String setMethodName(String fieldName) {
        return methodName("set", fieldName);
    }

    /**
     * 方法名称
     *
     * @param method    get of set
     * @param fieldName 成员变量名称
     * @return 方法名称
     */
    private static String methodName(String method, String fieldName) {
        return String.format("%s%s%s", method, fieldName.substring(0, 1).toUpperCase(), fieldName.substring(1));
    }

    /**
     * 格式化时间
     *
     * @param timeMillis 时间（毫秒）
     * @return 格式化的时间字符串
     */
    public static String formatTime(long timeMillis) {
        return formatTime(new Date(timeMillis));
    }

    /**
     * 格式化时间
     *
     * @param time 时间
     * @return 格式化的时间字符串
     */
    public static String formatTime(Date time) {
        return formatTime(time, MyConst.FORMAT_YMDHMS);
    }

    /**
     * 格式化时间
     *
     * @param timeMillis 时间（毫秒）
     * @param pattern    格式
     * @return 格式化的时间字符串
     */
    public static String formatTime(long timeMillis, String pattern) {
        return formatTime(new Date(timeMillis), pattern);
    }

    /**
     * 格式化时间
     *
     * @param time    时间
     * @param pattern 格式
     * @return 格式化的时间字符串
     */
    public static String formatTime(Date time, String pattern) {
        return null == time ? "" : new SimpleDateFormat(pattern).format(time);
    }

    /**
     * 格式化字符串转 Date
     *
     * @param formatTime 格式化的时间字符串
     * @return Date
     */
    public static Date parseToDate(String formatTime) {
        return parseToDate(formatTime, MyConst.FORMAT_YMDHMS);
    }

    /**
     * 格式化字符串转 Date
     *
     * @param formatTime 格式化的时间字符串
     * @param pattern    格式
     * @return Date
     */
    public static Date parseToDate(String formatTime, String pattern) {
        try {
            return new SimpleDateFormat(pattern).parse(formatTime);
        } catch (ParseException pe) {
            log.error("格式化时间字符串转Date时发生异常！", pe);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 对象转 JSON
     *
     * @param obj 对象
     * @return JSON
     */
    public static String toJsonStr(Object obj) {
        try {
            // 为使 @JsonIgnore、@JsonFormat 等注解生效，需要使用 Jackson 提供的方法将对象转为 JSON 字符串
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            log.error("对象转JSON时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * 对象转 JSON
     *
     * @param obj          对象
     * @param defaultValue 默认值
     * @return JSON
     */
    public static String toJsonStr(Object obj, String defaultValue) {
        try {
            // 为使 @JsonIgnore、@JsonFormat 等注解生效，需要使用 Jackson 提供的方法将对象转为 JSON 字符串
            defaultValue = new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            log.error("对象转JSON时发生异常！", e);
        }
        return defaultValue;
    }

    /**
     * JSON 转对象
     *
     * @param jsonString JSON
     * @param beanClass  目标对象类型
     * @param <T>        泛型
     * @return 目标对象
     */
    public static <T> T toBean(String jsonString, Class<T> beanClass) {
        if (!JSONUtil.isTypeJSON(jsonString)) {
            return null;
        }
        try {
            return new ObjectMapper().readValue(jsonString, beanClass);
        } catch (JsonProcessingException e) {
            log.error("JSON转对象时发生异常！", e);
            return null;
        }
    }

    /**
     * Bean 转 Map
     *
     * @param obj Object
     * @return Map<String, String>
     */
    public static Map<String, String> beanToMap(Object obj) {
        try {
            Field[] fields = obj.getClass().getDeclaredFields();
            Map<String, String> map = new HashMap<>(fields.length);
            for (Field field : fields) {
                field.setAccessible(true);
                Object value = field.get(obj);
                if (null != value) {
                    map.put(field.getName(), String.valueOf(value));
                }
            }
            return map;
        } catch (Exception e) {
            log.error("Bean转Map时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    /**
     * Map 转 Bean
     *
     * @param map   Map 集合
     * @param clazz 目标对象类型
     * @param <T>   泛型
     * @return 目标对象
     */
    public static <T> T mapToBean(Map<String, Object> map, Class<T> clazz) {
        try {
            T obj = clazz.newInstance();
            Field[] fields = obj.getClass().getDeclaredFields();
            for (Field field : fields) {
                int mod = field.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isFinal(mod)) {
                    continue;
                }
                field.setAccessible(true);
                if (map.containsKey(field.getName())) {
                    field.set(obj, map.get(field.getName()));
                }
            }
            return obj;
        } catch (Exception e) {
            log.error("Map转Bean时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }
}
