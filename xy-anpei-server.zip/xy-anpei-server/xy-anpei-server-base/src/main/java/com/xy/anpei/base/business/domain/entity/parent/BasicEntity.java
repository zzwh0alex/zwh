package com.xy.anpei.base.business.domain.entity.parent;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-06-13 10:32
 */
@Getter
@Setter
@MappedSuperclass
public class BasicEntity implements Serializable {

    /**
     * 创建人 ID
     */
    @JsonIgnore
    @Column(name = "create_user")
    private String createUser;

    /**
     * 创建时间
     */
    @JsonIgnore
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 更新人 ID
     */
    @JsonIgnore
    @Column(name = "update_user")
    private String updateUser;

    /**
     * 更新时间
     */
    @JsonIgnore
    @Column(name = "update_time")
    private Date updateTime;
}
