package com.xy.anpei.base.business.service.impl;

import com.xy.anpei.base.business.service.RedisService;
import com.xy.anpei.base.util.MyUtil;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author Chen Guibiao
 * Create at 2023-06-14 10:05
 */
@Service
public class RedisServiceImpl implements RedisService {

    private final ValueOperations<String, String> opsForValue;

    public RedisServiceImpl(StringRedisTemplate stringRedisTemplate) {
        this.opsForValue = stringRedisTemplate.opsForValue();
    }

    @Override
    public String get(String key) {
        return this.opsForValue.get(key);
    }

    @Override
    public <T> T get(String key, Class<T> beanClass) {
        return MyUtil.toBean(this.opsForValue.get(key), beanClass);
    }

    @Override
    public void set(String key, Object value) {
        this.set(key, value, 600L);
    }

    @Override
    public void set(String key, Object value, long timeout) {
        this.set(key, value, timeout, TimeUnit.SECONDS);
    }

    @Override
    public void set(String key, Object value, long timeout, TimeUnit unit) {
        String strValue = value instanceof String ? (String) value : MyUtil.toJsonStr(value, null);
        this.opsForValue.set(key, strValue, timeout, unit);
    }

    @Override
    public void delete(String key) {
        this.opsForValue.getOperations().delete(key);
    }
}
