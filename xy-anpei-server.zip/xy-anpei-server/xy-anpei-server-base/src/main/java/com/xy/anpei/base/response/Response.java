package com.xy.anpei.base.response;

/**
 * 响应代码枚举类
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 11:00
 */
public enum Response implements ResultInterface {

    /**
     * 成功
     */
    SUCCESS(0, "OK"),

    /**
     * 参数错误
     */
    PARAM_ERROR(1001, "参数错误"),

    /**
     * 令牌错误
     */
    TOKEN_ERROR(1002, "令牌错误"),

    /**
     * 验证码错误
     */
    CAPTCHA_ERROR(1003, "验证码错误"),

    /**
     * 账号或密码错误
     */
    ACC_OR_PWD_ERROR(1004, "账号或密码错误"),

    /**
     * 账号已停用
     */
    ACCOUNT_FROZEN(1005, "账号已停用"),

    /**
     * 数据不存在
     */
    DATA_NOT_FOUND(1006, "暂无数据"),

    /**
     * 数据已存在
     */
    DATA_ALREADY_EXISTS(1007, "数据已存在"),

    /**
     * 签名不匹配
     */
    SIGNATURE_MISMATCH(4001, "签名无效"),

    /**
     * 请求失效
     */
    REQUEST_INVALID(4002, "请求失效"),

    /**
     * 报名失败
     */
    REGISTRATION_FAILED(4003, "报名失败"),

    /**
     * 服务异常
     */
    SERVICE_EXCEPTION(5000, "服务异常"),

    /**
     * 请求方法不支持
     */
    METHOD_NOT_SUPPORTED(5001, "请求方法不支持"),

    /**
     * 未经授权
     */
    NO_AUTH(5002, "未经授权"),

    /**
     * 禁止访问
     */
    FORBIDDEN(5003, "禁止访问"),

    /**
     * 目标资源不存在
     */
    NOT_FOUND(5004, "目标资源不存在");

    /**
     * 返回码
     */
    private final Integer code;

    /**
     * 返回消息
     */
    private final String msg;

    Response(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public Integer getCode() {
        return this.code;
    }

    @Override
    public String getMsg() {
        return this.msg;
    }
}
