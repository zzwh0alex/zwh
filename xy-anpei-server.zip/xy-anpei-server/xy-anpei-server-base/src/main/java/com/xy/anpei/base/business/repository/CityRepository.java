package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.City;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:05
 */
@Repository
public interface CityRepository extends JpaRepository<City, Integer> {

    /**
     * 根据省区划代码查询市列表
     *
     * @param parentId 省区划代码
     * @return a list of City
     */
    List<City> findByParentId(Integer parentId);
}
