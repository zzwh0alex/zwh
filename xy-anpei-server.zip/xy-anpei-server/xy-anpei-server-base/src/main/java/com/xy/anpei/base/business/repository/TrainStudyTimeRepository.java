package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.TrainStudyTime;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:02
 */
@Repository
public interface TrainStudyTimeRepository extends MyRepository<TrainStudyTime, Integer> {
}
