package com.xy.anpei.base.util.cqay;

import cn.hutool.http.HttpRequest;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.constant.CqayConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * 重庆安运科技对接工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-26 07:54
 */
@Slf4j
public class CqayUtil {

    /**
     * 请求地址
     */
    private static String cqayUrl;

    /**
     * 请求 Toke
     */
    private static String cqayToken;

    /**
     * 初始化重庆安运科技请求地址和请求 Token
     *
     * @param url   请求地址
     * @param token 请求 Token
     */
    public static void init(String url, String token) {
        cqayUrl = url;
        cqayToken = token;
        log.info("[重庆安运] 初始化成功！URL={}, TOKEN={}", cqayUrl, cqayToken);
    }

    /**
     * 学员报名
     *
     * @param data 请求数据
     * @return 重庆安运报名记录 ID
     */
    public static String register(Map<String, Object> data) {
        Object respData = request(CqayConst.URL_COACH_REGISTER, data);
        String trainId = String.valueOf(JSONUtil.parseObj(respData).get("trainId"));
        if (StringUtils.isBlank(trainId)) {
            log.info("[重庆安运][报名失败] 报名记录ID为空");
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
        log.info("[重庆安运][报名成功] 报名记录ID：{}，报名请求参数：{}", trainId, JSONUtil.toJsonStr(data));
        return trainId;
    }

    /**
     * 教练信息修改
     *
     * @param data 请求数据
     */
    public static void update(Map<String, Object> data) {
        request(CqayConst.URL_COACH_UPDATE, data);
    }

    /**
     * 查询虚拟卡使用情况
     *
     * @return Object
     */
    public static Object queryStorage() {
        Object respData = request(CqayConst.URL_QUERY_STORAGE, null);
        return respData;
    }

    /**
     * 发起请求
     *
     * @param uri     uri
     * @param reqData 请求数据
     * @return 应答数据
     */
    private static Object request(String uri, Map<String, Object> reqData) {
        // Map 转 JSON
        String reqBody = JSONUtil.toJsonStr(reqData);
        // 发送请求，获取响应数据
        String respBody = HttpRequest.post(cqayUrl + uri)
                .header(CqayConst.HEADER_KEY_AUTHORIZATION, cqayToken)
                .header(CqayConst.HEADER_KEY_CONTENT_TYPE, CqayConst.HEADER_VALUE_CONTENT_TYPE)
                .header(CqayConst.HEADER_KEY_ACCEPT, CqayConst.HEADER_VALUE_ACCEPT)
                .body(reqBody)
                .execute()
                .body();

        // 日志提示信息
        String logMsg = String.format("[重庆安运][{}] reqUrl=%s, Authorization=%s, reqBody=%s, respBody=%s", cqayUrl, cqayToken, reqBody, respBody);

        // 检查响应数据是否为 JSON
        if (!JSONUtil.isTypeJSON(respBody)) {
            log.info(logMsg, "响应报文非JSON格式");
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }

        // 响应数据转 JSON
        JSONObject respObj = JSONUtil.parseObj(respBody);
        // 返回结果
        Boolean result = (Boolean) respObj.get("result");
        // 返回数据（返回结果为 false 时，此项为错误信息）
        Object data = respObj.get("data");
        // 检查返回结果
        if (!Boolean.TRUE.equals(result)) {
            log.info(logMsg, String.format("%s - %s", result, data));
            throw new BusinessException(Response.SERVICE_EXCEPTION, String.valueOf(data));
        }

        // 打印日志
        log.info(logMsg, "请求成功");

        // 返回接口返回数据
        return data;
    }
}
