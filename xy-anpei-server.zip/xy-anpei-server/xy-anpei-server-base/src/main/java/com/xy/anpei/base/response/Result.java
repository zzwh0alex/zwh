package com.xy.anpei.base.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.UUID;

/**
 * 统一返回结果封装类
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 10:50
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Result {

    /**
     * 返回代码
     */
    private Integer code;

    /**
     * 返回信息
     */
    private String msg;

    /**
     * 调用链 ID
     */
    private String traceId;

    /**
     * 返回数据
     */
    private Object data;

    private Result(Integer code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.traceId = UUID.randomUUID().toString().replace("-", "");
        this.data = data;
    }

    public static Result success() {
        return Result.success(null);
    }

    public static Result success(Object data) {
        return new Result(Response.SUCCESS.getCode(), Response.SUCCESS.getMsg(), data);
    }

    public static Result failure() {
        return Result.failure(Response.SERVICE_EXCEPTION);
    }

    public static Result failure(ResultInterface ri) {
        return Result.failure(ri, ri.getMsg());
    }

    public static Result failure(ResultInterface ri, String msg) {
        return new Result(ri.getCode(), msg, null);
    }
}
