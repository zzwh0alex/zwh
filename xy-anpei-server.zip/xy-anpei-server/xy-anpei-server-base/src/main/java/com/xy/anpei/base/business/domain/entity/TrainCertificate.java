package com.xy.anpei.base.business.domain.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 教练员结业证表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 18:06
 */
@Getter
@Setter
@Entity
@Table(name = "train_certificate")
public class TrainCertificate implements Serializable {

    /**
     * 记录 ID
     */
    @Id
    @Column(name = "record_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer recordId;

    /**
     * （重庆安运科技）报名记录 ID
     */
    @Column(name = "train_id")
    private String trainId;

    /**
     * 培训机构全国统一编号
     */
    @Column(name = "unit_no")
    private String unitNo;

    /**
     * 教练员 ID
     */
    @Column(name = "coach_id")
    private Integer coachId;

    /**
     * 结业证地址
     */
    @Column(name = "cert_url")
    private String certUrl;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;
}
