package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.model.ViewCoachRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author Chen Guibiao
 * Create at 2023-05-28 18:39
 */
@Repository
public interface ViewCoachRegistrationRepository extends JpaRepository<ViewCoachRegistration, String> {

    /**
     * 根据身份证号查询教练报名信息
     *
     * @param idNo 身份证号
     * @return Optional<ViewCoachRegistration>
     */
    Optional<ViewCoachRegistration> findByIdNo(String idNo);

    /**
     * 根据手机号码查询教练报名信息
     *
     * @param phone 手机号码
     * @return Optional<ViewCoachRegistration>
     */
    Optional<ViewCoachRegistration> findByPhone(String phone);
}
