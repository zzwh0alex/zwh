package com.xy.anpei.base.util;

import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * 身份证工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-17 10:07
 */
public class IdCardUtil {

    /**
     * 中国公民身份证号码最小长度
     */
    private static final int CHINA_ID_MIN_LENGTH = 15;

    /**
     * 中国公民身份证号码最大长度
     */
    private static final int CHINA_ID_MAX_LENGTH = 18;

    /**
     * 校验码
     */
    private static final int[] PARITYBIT = {'1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};

    /**
     * 加权因子 wi
     */
    private static final int[] POWER_LIST = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};

    /**
     * 身份证省份编码
     */
    private static final Map<Integer, String> ZONE_NUM = new HashMap<>();

    static {
        ZONE_NUM.put(11, "北京");
        ZONE_NUM.put(12, "天津");
        ZONE_NUM.put(13, "河北");
        ZONE_NUM.put(14, "山西");
        ZONE_NUM.put(15, "内蒙古");
        ZONE_NUM.put(21, "辽宁");
        ZONE_NUM.put(22, "吉林");
        ZONE_NUM.put(23, "黑龙江");
        ZONE_NUM.put(31, "上海");
        ZONE_NUM.put(32, "江苏");
        ZONE_NUM.put(33, "浙江");
        ZONE_NUM.put(34, "安徽");
        ZONE_NUM.put(35, "福建");
        ZONE_NUM.put(36, "江西");
        ZONE_NUM.put(37, "山东");
        ZONE_NUM.put(41, "河南");
        ZONE_NUM.put(42, "湖北");
        ZONE_NUM.put(43, "湖南");
        ZONE_NUM.put(44, "广东");
        ZONE_NUM.put(45, "广西");
        ZONE_NUM.put(46, "海南");
        ZONE_NUM.put(50, "重庆");
        ZONE_NUM.put(51, "四川");
        ZONE_NUM.put(52, "贵州");
        ZONE_NUM.put(53, "云南");
        ZONE_NUM.put(54, "西藏");
        ZONE_NUM.put(61, "陕西");
        ZONE_NUM.put(62, "甘肃");
        ZONE_NUM.put(63, "青海");
        ZONE_NUM.put(64, "宁夏");
        ZONE_NUM.put(65, "新疆");
        ZONE_NUM.put(71, "台湾");
        ZONE_NUM.put(81, "香港");
        ZONE_NUM.put(82, "澳门");
        ZONE_NUM.put(91, "国外");
    }

    /**
     * 校验身份证号
     *
     * @param idNo 身份证号
     */
    public static void verify(String idNo) {
        verify(idNo, false);
    }

    /**
     * 校验身份证号
     *
     * @param idNo        身份证号
     * @param ignoreEmpty 是否忽略空值
     */
    public static void verify(String idNo, boolean ignoreEmpty) {
        if (ignoreEmpty && StringUtils.isEmpty(idNo)) {
            return;
        }
        if (!isIdcard(idNo)) {
            throw new BusinessException(Response.PARAM_ERROR, "身份证号格式不正确");
        }
    }

    /**
     * 验证身份证号有效性
     *
     * @param idNo 身份证号
     * @return 有效返回 true，否则返回 false
     */
    private static boolean isIdcard(String idNo) {
        // 号码长度应为 15 位或 18 位
        if (idNo.length() != CHINA_ID_MIN_LENGTH && idNo.length() != CHINA_ID_MAX_LENGTH) {
            return false;
        }
        // 校验区位码
        if (!ZONE_NUM.containsKey(Integer.valueOf(idNo.substring(0, 2)))) {
            return false;
        }
        // 校验年份
        String year = idNo.length() == CHINA_ID_MIN_LENGTH ? "19" + idNo.substring(6, 8) : idNo.substring(6, 10);
        final int iYear = Integer.parseInt(year);
        if (iYear < 1900 || iYear > Calendar.getInstance().get(Calendar.YEAR)) {
            // 1900 年的 PASS，超过今年的 PASS
            return false;
        }
        // 校验月份
        String month = idNo.length() == CHINA_ID_MIN_LENGTH ? idNo.substring(8, 10) : idNo.substring(10, 12);
        final int imonth = Integer.parseInt(month);
        if (imonth < 1 || imonth > 12) {
            return false;
        }
        // 校验天数
        String day = idNo.length() == CHINA_ID_MIN_LENGTH ? idNo.substring(10, 12) : idNo.substring(12, 14);
        final int iday = Integer.parseInt(day);
        if (iday < 1 || iday > 31) {
            return false;
        }
        // 校验一个合法的年月日
        if (!isValidDate(year + month + day)) {
            return false;
        }
        // 校验位数
        int power = 0;
        final char[] cs = idNo.toUpperCase().toCharArray();
        // 循环比正则表达式更快
        for (int i = 0; i < cs.length; i++) {
            if (i == cs.length - 1 && cs[i] == 'X') {
                // 最后一位可以是 X 或者 x
                break;
            }
            if (cs[i] < '0' || cs[i] > '9') {
                return false;
            }
            if (i < cs.length - 1) {
                power += (cs[i] - '0') * POWER_LIST[i];
            }
        }
        // 校验“校验码”
        if (idNo.length() == CHINA_ID_MIN_LENGTH) {
            return true;
        }
        return cs[cs.length - 1] == PARITYBIT[power % 11];
    }

    /**
     * 判断日期是否为合法日期
     *
     * @param inDate 字符串日期
     * @return 合法返回 true，否则返回 false
     */
    private static boolean isValidDate(String inDate) {
        if (inDate == null) {
            return false;
        }
        // 校验日期字符串长度
        SimpleDateFormat dataFormat = new SimpleDateFormat("yyyyMMdd");
        if (inDate.trim().length() != dataFormat.toPattern().length()) {
            return false;
        }
        // 该方法用于设置 Calendar 严格解析字符串；默认为 true，宽松解析
        dataFormat.setLenient(false);
        try {
            dataFormat.parse(inDate.trim());
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
}
