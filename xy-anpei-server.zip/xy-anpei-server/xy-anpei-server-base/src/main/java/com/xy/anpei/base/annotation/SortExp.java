package com.xy.anpei.base.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 自定义的 JPA 查询排序注解
 *
 * @author Chen Guibiao
 * Create at 2023-06-26 10:17
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SortExp {

    /**
     * 字段名称
     *
     * @return 字段名称
     */
    String name();

    /**
     * 排序方向（默认升序）
     *
     * @return Direction
     */
    Direction direction() default Direction.ASC;

    enum Direction {

        /**
         * 升序
         */
        ASC,

        /**
         * 降序
         */
        DESC;

        /**
         * 是否是降序
         *
         * @return boolean
         */
        public boolean isDescending() {
            return this.equals(DESC);
        }
    }
}
