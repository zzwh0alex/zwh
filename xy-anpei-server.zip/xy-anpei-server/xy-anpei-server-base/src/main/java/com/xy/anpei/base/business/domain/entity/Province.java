package com.xy.anpei.base.business.domain.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 行政区划（省）表
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 17:21
 */
@Getter
@Setter
@Entity
@Table(name = "region_province")
public class Province implements Serializable {

    /**
     * 省行政区划唯一标识
     */
    @Id
    @Column(name = "province_id")
    private Integer provinceId;

    /**
     * 简称
     */
    @Column(name = "province_name")
    private String provinceName;

    /**
     * 全称
     */
    @Column(name = "full_name")
    private String fullName;
}
