package com.xy.anpei.base.business.repository;

import com.xy.anpei.base.business.domain.entity.TrainCertificate;
import com.xy.anpei.base.business.repository.parent.MyRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:03
 */
@Repository
public interface TrainCertificateRepository extends MyRepository<TrainCertificate, Integer> {
}
