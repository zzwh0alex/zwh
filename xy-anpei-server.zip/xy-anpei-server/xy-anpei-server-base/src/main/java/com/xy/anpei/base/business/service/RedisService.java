package com.xy.anpei.base.business.service;

import java.util.concurrent.TimeUnit;

/**
 * @author Chen Guibiao
 * Create at 2023-06-14 10:05
 */
public interface RedisService {

    /**
     * 根据 key 获取 value
     *
     * @param key key
     * @return value
     */
    String get(String key);

    /**
     * 根据 key 获取目标对象
     *
     * @param key       key
     * @param beanClass 目标对象类型
     * @return 目标对象
     */
    <T> T get(String key, Class<T> beanClass);

    /**
     * 缓存键值对
     *
     * @param key   key
     * @param value value
     */
    void set(String key, Object value);

    /**
     * 缓存键值对
     *
     * @param key     key
     * @param value   value
     * @param timeout 超时时间
     */
    void set(String key, Object value, long timeout);

    /**
     * 缓存键值对
     *
     * @param key     key
     * @param value   value
     * @param timeout 超时时间
     * @param unit    时间单位
     */
    void set(String key, Object value, long timeout, TimeUnit unit);

    /**
     * 删除 key
     *
     * @param key key
     */
    void delete(String key);
}
