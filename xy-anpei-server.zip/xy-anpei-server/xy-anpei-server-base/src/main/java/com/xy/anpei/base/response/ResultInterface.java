package com.xy.anpei.base.response;

/**
 * 返回结果接口
 *
 * @author Chen Guibiao
 * Create at 2023-05-16 10:53
 */
public interface ResultInterface {

    /**
     * 获取返回代码
     *
     * @return code
     */
    Integer getCode();

    /**
     * 获取返回信息
     *
     * @return message
     */
    String getMsg();
}
