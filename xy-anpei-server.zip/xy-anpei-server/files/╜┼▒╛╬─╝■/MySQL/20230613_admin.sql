-- 系统功能菜单表
create table if not exists sys_menu (
    menu_id varchar(32) comment '菜单ID',
    menu_name varchar(32) not null comment '菜单名称',
    menu_path varchar(128) comment '菜单路径',
    menu_level tinyint(1) comment '菜单级别',
    menu_status tinyint(1) comment '菜单状态：0-停用；1-启用',
    icon_cls varchar(64) comment 'ElementUI图标名称',
    vue_component varchar(64) comment 'Vue组件名称',
    parent_id varchar(32) comment '父菜单ID',
    display_order int comment '显示顺序',
    auth_id varchar(32) comment '权限ID',
    create_user varchar(32) comment '创建人ID',
    create_time timestamp comment '创建时间',
    update_user varchar(32) comment '更新人ID',
    update_time timestamp comment '更新时间',
    primary key (menu_id),
    unique (menu_name)
);

-- 系统用户表
create table if not exists sys_user (
    user_id varchar(32) comment '用户ID',
    user_name varchar(32) not null comment '用户名称',
    id_no varchar(18) comment '身份证号',
    phone varchar(11) comment '手机号码',
    gender tinyint(1) comment '性别：0-未知；1-男；2-女',
    status tinyint(1) not null default 1 comment '账号状态：0-停用；1-启用',
    password varchar(128) not null comment '账号密码',
    salt varchar(32) comment '盐',
    plaintext varchar(128) comment '密码明文',
    delete_flag tinyint(1) not null default 0 comment '删除标记：0-未删除；1-已删除',
    create_user varchar(32) comment '创建人ID',
    create_time timestamp comment '创建时间',
    update_user varchar(32) comment '更新人ID',
    update_time timestamp comment '更新时间',
    delete_user varchar(32) comment '删除人ID',
    delete_time timestamp comment '删除时间',
    primary key (user_id)
);

-- 系统角色表
create table if not exists sys_role (
    role_id varchar(32) comment '角色ID',
    role_name varchar(32) comment '角色名称',
    role_desc varchar(255) comment '角色描述',
    user_count int comment '关联用户记数',
    create_user varchar(32) comment '创建人ID',
    create_time timestamp comment '创建时间',
    update_user varchar(32) comment '更新人ID',
    update_time timestamp comment '更新时间',
    primary key (role_id),
    unique (role_name)
);

-- 系统权限表
create table if not exists sys_auth (
    auth_id varchar(32) comment '权限ID',
    auth_name varchar(32) comment '权限名称',
    auth_level tinyint(1) comment '权限级别',
    auth_status tinyint(1) comment '权限状态：0-停用；1-启用',
    parent_id varchar(32) comment '父权限ID',
    dependent_id varchar(32) comment '依赖权限ID',
    display_order int comment '显示顺序',
    primary key (auth_id)
);

-- 系统用户角色关联表
create table if not exists sys_user_role (
    id int auto_increment comment 'ID',
    user_id varchar(32) comment '用户ID',
    role_id varchar(32) comment '角色ID',
    primary key (id)
);

-- 系统角色权限关联表
create table if not exists sys_role_auth (
    id int auto_increment comment 'ID',
    role_id varchar(32) comment '角色ID',
    auth_id varchar(32) comment '权限ID',
    primary key (id)
);

-- 用户角色关系视图
create view view_user_role as select
    ur.user_id,
    u.user_name,
    u.status,
    ur.role_id,
    r.role_name
from
    sys_user_role ur
    left join sys_user u on u.user_id = ur.user_id
    left join sys_role r on r.role_id = ur.role_id;

-- 用户角色关系视图
create view view_role_auth as select
    ra.role_id,
    r.role_name,
    ra.auth_id,
    a.auth_name,
    a.auth_level,
    a.auth_status,
    a.dependent_id,
    a.parent_id,
    a.display_order
from
    sys_role_auth ra
    left join sys_role r on r.role_id = ra.role_id
    left join sys_auth a on a.auth_id = ra.auth_id;
