package com.xy.anpei.applet.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.File;

/**
 * @author Chen Guibiao
 * Create at 2023-05-18 15:37
 */
@Configuration
public class AppletConfig {

    /**
     * 微信小程序 appId
     */
    @Value("${wechat.applet.appid}")
    private String wxAppId;

    /**
     * 微信小程序 secret
     */
    @Value("${wechat.applet.secret}")
    private String wxSecret;

    /**
     * 杉德支付公钥路径
     */
    @Value("${sandpay.public.key.path}")
    private String sandPayPublicKeyPath;

    /**
     * 杉德支付私钥路径
     */
    @Value("${sandpay.private.key.path}")
    private String sandPayPrivateKeyPath;

    /**
     * 杉德支付私钥密码
     */
    @Value("${sandpay.private.key.password}")
    private String sandPayPrivateKeyPassword;

    /**
     * 杉德支付统一下单异步通知地址
     */
    @Value("${sandpay.notify.url.unifiedorder}")
    private String sandPayUnifiedOrderNotifyUrl;

    /**
     * 杉德支付申请退款异步通知地址
     */
    @Value("${sandpay.notify.url.refund}")
    private String sandPayRefundNotifyUrl;

    /**
     * 重庆安运请求地址
     */
    @Value("${cqay.url}")
    private String cqayUrl;

    /**
     * 重庆安运请求 Token
     */
    @Value("${cqay.token}")
    private String cqayToken;

    /**
     * 重庆安运请求我方系统接口密钥
     */
    @Value("${cqay.secret.key}")
    private String cqaySecretKey;

    /**
     * 个人照片存储目录
     */
    @Value("${photo.path.personal}")
    private String personalPhotoPath;

    /**
     * 报名照片存储目录
     */
    @Value("${photo.path.register}")
    private String registerPhotoPath;

    /**
     * 结业照片存储目录
     */
    @Value("${photo.path.graduation}")
    private String graduationPhotoPath;

    /**
     * 个人照片 URL 前缀
     */
    @Value("${photo.url.personal}")
    private String personalPhotoUrl;

    /**
     * 报名照片 URL 前缀
     */
    @Value("${photo.url.register}")
    private String registerPhotoUrl;

    /**
     * 结业照片 URL 前缀
     */
    @Value("${photo.url.graduation}")
    private String graduationPhotoUrl;

    public String getWxAppId() {
        return wxAppId;
    }

    public String getWxSecret() {
        return wxSecret;
    }

    public String getSandPayPublicKeyPath() {
        return getLocalePath(sandPayPublicKeyPath, true);
    }

    public String getSandPayPrivateKeyPath() {
        return getLocalePath(sandPayPrivateKeyPath, true);
    }

    public String getSandPayPrivateKeyPassword() {
        return sandPayPrivateKeyPassword;
    }

    public String getSandPayUnifiedOrderNotifyUrl() {
        return sandPayUnifiedOrderNotifyUrl;
    }

    public String getSandPayRefundNotifyUrl() {
        return sandPayRefundNotifyUrl;
    }

    public String getCqayUrl() {
        return cqayUrl;
    }

    public String getCqayToken() {
        return cqayToken;
    }

    public String getCqaySecretKey() {
        return cqaySecretKey;
    }

    public String getPersonalPhotoPath() {
        return getLocalePath(personalPhotoPath);
    }

    public String getRegisterPhotoPath() {
        return getLocalePath(registerPhotoPath);
    }

    public String getGraduationPhotoPath() {
        return getLocalePath(graduationPhotoPath);
    }

    public String getPersonalPhotoUrl() {
        return getFormatUrl(personalPhotoUrl);
    }

    public String getRegisterPhotoUrl() {
        return getFormatUrl(registerPhotoUrl);
    }

    public String getGraduationPhotoUrl() {
        return getFormatUrl(graduationPhotoUrl);
    }

    /**
     * 获取本地系统路径
     *
     * @param path 路径
     * @return 本地系统路径
     */
    private String getLocalePath(String path) {
        return getLocalePath(path, false);
    }

    /**
     * 获取本地系统路径
     *
     * @param path       路径
     * @param isFilePath 是否是文件路径
     * @return 本地系统路径
     */
    private String getLocalePath(String path, boolean isFilePath) {
        path = path.replace("/", File.separator).replace("\\", File.separator);
        return isFilePath ? path : (path.endsWith(File.separator) ? path : path + File.separator);
    }

    /**
     * 获取格式化的 URL
     *
     * @param url URL
     * @return 格式化的 URL
     */
    private String getFormatUrl(String url) {
        return url.endsWith("/") ? url : url + "/";
    }
}
