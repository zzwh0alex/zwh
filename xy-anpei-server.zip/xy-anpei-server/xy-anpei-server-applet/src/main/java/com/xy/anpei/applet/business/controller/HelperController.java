package com.xy.anpei.applet.business.controller;

import com.xy.anpei.applet.business.dto.helper.SignatureDto;
import com.xy.anpei.applet.business.dto.helper.TokenDto;
import com.xy.anpei.applet.business.service.HelperService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Chen Guibiao
 * Create at 2023-05-19 11:34
 */
@RestController
@RequestMapping("/helper")
public class HelperController {

    private final HelperService helperService;

    public HelperController(HelperService helperService) {
        this.helperService = helperService;
    }

    @PostMapping(value = "/parseToken", name = "解析令牌")
    public Object parseToken(@RequestBody TokenDto dto) {
        return helperService.parseToken(dto);
    }

    @PostMapping(value = "/generateSignature", name = "生成签名")
    public Object generateSignature(@RequestBody SignatureDto dto) {
        return helperService.generateSignature(dto);
    }
}
