package com.xy.anpei.applet.business.dto.helper;

import lombok.Data;

/**
 * @author Chen Guibiao
 * Create at 2023-05-19 12:43
 */
@Data
public class TokenDto {

    /**
     * 鉴权码
     */
    private String auth;

    /**
     * 令牌
     */
    private String token;
}
