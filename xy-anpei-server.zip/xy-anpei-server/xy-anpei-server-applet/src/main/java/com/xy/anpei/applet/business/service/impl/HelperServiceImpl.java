package com.xy.anpei.applet.business.service.impl;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.applet.business.dto.helper.SignatureDto;
import com.xy.anpei.applet.business.dto.helper.TokenDto;
import com.xy.anpei.applet.business.service.HelperService;
import com.xy.anpei.applet.config.AppletConfig;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.util.AesUtil;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-05-19 11:36
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class HelperServiceImpl implements HelperService {

    private final AppletConfig appletConfig;

    public HelperServiceImpl(AppletConfig appletConfig) {
        this.appletConfig = appletConfig;
    }

    @Override
    public Object parseToken(TokenDto dto) {
        String smile = "^_^";

        String authCode = dto.getAuth();
        String token = dto.getToken();
        if (StringUtils.isAnyBlank(authCode, token)) {
            log.info("【令牌解析】参数不全！authCode={}, token={}", authCode, token);
            return smile;
        }

        if (!this.auth(authCode)) {
            log.info("【令牌解析】鉴权失败！authCode={}", authCode);
            return smile;
        }

        String decrypt = AesUtil.decrypt(token, MyConst.AES_SECRET_KEY);
        if (StringUtils.isBlank(decrypt) || !JSONUtil.isTypeJSON(decrypt)) {
            log.info("【令牌解析】解析失败！");
            return smile;
        }

        JSONObject jsonObj = JSONUtil.parseObj(decrypt);
        jsonObj.set("expiryTime", MyUtil.formatTime((Long) jsonObj.get("expiryTime"), MyConst.FORMAT_YMDHMS));
        return jsonObj;
    }

    @Override
    public Object generateSignature(SignatureDto dto) {
        String smile = "^_^";

        String authCode = dto.getAuth();
        String json = dto.getJson();
        if (StringUtils.isAnyBlank(authCode, json)) {
            log.info("【签名生成】参数不全！authCode={}, json={}", authCode, json);
            return smile;
        }

        if (!this.auth(authCode)) {
            log.info("【签名生成】鉴权失败！authCode={}", authCode);
            return smile;
        }

        if (!JSONUtil.isTypeJSON(json)) {
            log.info("【签名生成】参数错误！authCode={}, json={}", authCode, json);
            return smile;
        }

        JSONObject jsonObj = JSONUtil.parseObj(json);
        Map<String, Object> data = new HashMap<>(jsonObj.size());
        for (Map.Entry<String, Object> entry : jsonObj) {
            data.put(entry.getKey(), entry.getValue());
        }
        return SignUtil.generateSignature(data, appletConfig.getCqaySecretKey());
    }

    /**
     * 鉴权
     *
     * @param authCode 鉴权码
     * @return 鉴权成功返回 true，否则返回 false
     */
    private boolean auth(String authCode) {
        String date = MyUtil.formatTime(new Date(), MyConst.FORMAT_YMD);
        String[] split = date.split("-");
        String year = split[0];
        int month = Integer.parseInt(split[1]);
        int day = Integer.parseInt(split[2]);
        String authValue = year + month * month + day * day;
        return StringUtils.equals(authCode, authValue);
    }
}
