package com.xy.anpei.applet.aspect;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.applet.annotation.CoachLogin;
import com.xy.anpei.applet.business.login.CoachLoginInfo;
import com.xy.anpei.applet.business.login.CoachLocal;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.AesUtil;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * 鉴权切面
 *
 * @author Chen Guibiao
 * Create at 2023-05-17 15:50
 */
@Aspect
@Component
@Order(1)
@Slf4j
public class CoachLoginAspect {

    @Around("execution(* com.xy.anpei.applet.business.controller..*(..)) && @annotation(coachLogin)")
    public Object aroundController(ProceedingJoinPoint jp, CoachLogin coachLogin) throws Throwable {
        HttpServletRequest request = SpringUtil.getRequest();
        String ip = request.getHeader(MyConst.HEADER_REAL_IP);
        String openId = request.getHeader(MyConst.HEADER_OPEN_ID);
        String coachId = request.getHeader(MyConst.HEADER_COACH_ID);
        String token = request.getHeader(MyConst.HEADER_TOKEN);

        if (StringUtils.isAnyBlank(openId, coachId, token)) {
            log.info("鉴权信息不完整！ip={}, openId={}, coachId={}, token={}", ip, openId, coachId, token);
            throw new BusinessException(Response.NO_AUTH);
        }

        String decrypt = AesUtil.decrypt(token, MyConst.AES_SECRET_KEY);
        if (StringUtils.isBlank(decrypt) || !JSONUtil.isTypeJSON(decrypt)) {
            log.info("鉴权信息解析失败！ip={}, openId={}, coachId={}, token={}", ip, openId, coachId, token);
            throw new BusinessException(Response.NO_AUTH);
        }

        CoachLoginInfo info = JSONUtil.toBean(decrypt, CoachLoginInfo.class);
        if (null == info) {
            log.info("鉴权失败！信息为空！ip={}, openId={}, coachId={}, token={}", ip, openId, coachId, token);
            throw new BusinessException(Response.NO_AUTH);
        }
        if (!StringUtils.equals(openId, info.getOpenId())) {
            log.info("鉴权失败！openId不匹配！ip={}, openId={}, coachId={}, token={}", ip, openId, coachId, token);
            throw new BusinessException(Response.NO_AUTH);
        }
        if (!StringUtils.equals(coachId, info.getCoachId())) {
            log.info("鉴权失败！coachId不匹配！ip={}, openId={}, coachId={}, token={}", ip, openId, coachId, token);
            throw new BusinessException(Response.NO_AUTH);
        }
        if (System.currentTimeMillis() > info.getExpiryTime()) {
            log.info("访问令牌已失效！ip={}, openId={}, coachId={}, expiryTime={}, token={}", ip, openId, coachId, MyUtil.formatTime(info.getExpiryTime()), token);
            throw new BusinessException(Response.NO_AUTH);
        }

        CoachLocal.setInfo(info);
        Object retObj = jp.proceed(jp.getArgs());
        CoachLocal.removeLogin();

        return retObj;
    }
}
