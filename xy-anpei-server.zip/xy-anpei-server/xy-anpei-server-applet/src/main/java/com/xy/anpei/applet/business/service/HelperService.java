package com.xy.anpei.applet.business.service;

import com.xy.anpei.applet.business.dto.helper.SignatureDto;
import com.xy.anpei.applet.business.dto.helper.TokenDto;

/**
 * @author Chen Guibiao
 * Create at 2023-05-19 11:35
 */
public interface HelperService {

    /**
     * 解析令牌
     *
     * @param dto TokenDto
     * @return Object
     */
    Object parseToken(TokenDto dto);

    /**
     * 生成签名
     *
     * @param dto SignatureDto
     * @return Object
     */
    Object generateSignature(SignatureDto dto);
}
