package com.xy.anpei.applet.business.service.impl;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.applet.business.service.CqayService;
import com.xy.anpei.applet.business.service.SandPayService;
import com.xy.anpei.applet.config.AppletConfig;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.repository.TrainRegistrationRepository;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.constant.SandPayConst;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.sandpay.SandPayCryptoUtil;
import com.xy.anpei.base.util.sandpay.SandPayUtil;
import com.xy.anpei.base.util.SpringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-05-24 09:04
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class SandPayServiceImpl implements SandPayService {

    private final TrainRegistrationRepository trainRegistrationRepository;

    private final CqayService cqayService;

    private final AppletConfig appConfig;

    public SandPayServiceImpl(TrainRegistrationRepository trainRegistrationRepository,
                              CqayService cqayService,
                              AppletConfig appConfig) {
        this.trainRegistrationRepository = trainRegistrationRepository;
        this.cqayService = cqayService;
        this.appConfig = appConfig;
    }

    @Override
    public Map<String, Object> unifiedOrder(Integer totalAmount, String openId) {
        // 商户订单号
        String orderCode = System.currentTimeMillis() + MyUtil.getRandomNum(3);

        Map<String, String> payExtraMap = new HashMap<>(2);
        // 微信小程序 appId
        payExtraMap.put("subAppid", appConfig.getWxAppId());
        // 微信小程序用户 openId
        payExtraMap.put("userId", openId);

        Map<String, Object> reqMap = new HashMap<>(16);
        // 商户订单号
        reqMap.put("orderCode", orderCode);
        // 订单金额
        reqMap.put("totalAmount", String.format("%012d", totalAmount));
        // 订单标题
        reqMap.put("subject", "星云安全学习-培训费");
        // 订单描述
        reqMap.put("body", String.format("星云安全学习-培训费%s元", totalAmount / 100.0));
        // 支付模式
        reqMap.put("payMode", "sand_wx");
        // 支付扩展域
        reqMap.put("payExtra", JSONUtil.toJsonStr(payExtraMap));
        // 客户端 IP
        reqMap.put("clientIp", SpringUtil.getRequest().getHeader(MyConst.HEADER_REAL_IP));
        // 异步通知地址
        reqMap.put("notifyUrl", appConfig.getSandPayUnifiedOrderNotifyUrl());

        // 发送请求，获取响应数据
        JSONObject respData = SandPayUtil.send(SandPayConst.URL_UNIFIED_ORDER, SandPayConst.METHOD_UNIFIED_ORDER, reqMap);
        // 获取微信小程序支付参数
        JSONObject params = JSONUtil.parseObj(JSONUtil.parseObj(respData.get("credential")).get("params"));
        // 日志记录微信小程序支付参数
        log.info("{} 微信小程序支付参数：{}", SandPayUtil.getSandPayDesc(SandPayConst.METHOD_UNIFIED_ORDER), params);

        // 构造返回数据
        Map<String, Object> retMap = new HashMap<>(2);
        retMap.put("orderCode", orderCode);
        retMap.put("params", params);
        return retMap;
    }

    @Override
    public void unifiedOrderCallback(HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> data = this.checkSign(SandPayConst.METHOD_UNIFIED_ORDER, request, response);
        if (null == data) {
            return;
        }
        // 异步通知数据
        JSONObject respData = (JSONObject) data.get("respData");
        // 商户订单号
        String orderCode = String.valueOf(respData.get("orderCode"));
        // 日志提示信息前缀
        String logMsgPrefix = SandPayUtil.getSandPayDesc(SandPayConst.METHOD_UNIFIED_ORDER);

        TrainRegistration tr = trainRegistrationRepository.findByOrderCode(orderCode).orElse(null);
        if (null == tr) {
            log.error("{}[异步通知] 未找到商户订单号为[{}]的报名记录", logMsgPrefix, orderCode);
            return;
        }

        // 订单状态
        String orderStatus = String.valueOf(respData.get("orderStatus"));
        // 支付时间
        String payTime = String.valueOf(respData.get("payTime"));

        if (MyConst.ORDER_STATUS_SUCCESS.equals(orderStatus)) {
            log.info("{}[异步通知] 订单状态为“成功”，开始调用安运接口进行报名……", logMsgPrefix);
            tr.setPayStatus(MyConst.PAY_STATUS_SUCCESS);
        } else {
            log.info("{}[异步通知] 订单状态为“失败”，orderStatus={}", logMsgPrefix, orderStatus);
            tr.setPayStatus(MyConst.PAY_STATUS_FAILED);
        }
        tr.setPayTime(MyUtil.parseToDate(payTime, MyConst.FORMAT_YMDHMS_PLAIN));
        tr.setTradeResultMsg(String.valueOf(data.get("params")));
        trainRegistrationRepository.save(tr);

        if (MyConst.ORDER_STATUS_SUCCESS.equals(orderStatus)) {
            try {
                // 调安运接口进行报名
                cqayService.register(orderCode);
            } catch (Exception e) {
                log.info("调用重庆安运接口报名时发生异常！{}", e.getMessage());
            }
        }
    }

    @Override
    public void refundCallback(HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> data = this.checkSign(SandPayConst.METHOD_ORDER_REFUND, request, response);
        if (null == data) {
            return;
        }
        // 异步通知数据
        JSONObject respData = (JSONObject) data.get("respData");
        // 原商户订单号
        String oriOrderCode = String.valueOf(respData.get("oriOrderCode"));
        // 日志提示信息前缀
        String logMsgPrefix = SandPayUtil.getSandPayDesc(SandPayConst.METHOD_UNIFIED_ORDER);

        TrainRegistration tr = trainRegistrationRepository.findByOrderCode(oriOrderCode).orElse(null);
        if (null == tr) {
            log.error("{}[异步通知] 未找到商户订单号为[{}]的报名记录", logMsgPrefix, oriOrderCode);
            return;
        }

        // 订单退款状态：1-成功；3-退款失败
        String refundStatus = String.valueOf(respData.get("orderStatus"));
        // 保存退款信息
        tr.setRefundOrderCode(String.valueOf(respData.get("orderCode")));
        tr.setRefundResultMsg(String.valueOf(data.get("params")));
        if ("1".equals(refundStatus)) {
            tr.setRefundAmount(Integer.parseInt(String.valueOf(respData.get("totalAmount"))));
        }
        trainRegistrationRepository.save(tr);
    }

    /**
     * 验签并获取异步通知参数
     *
     * @param method   接口名称
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return 异步通知参数
     */
    private Map<String, Object> checkSign(String method, HttpServletRequest request, HttpServletResponse response) {
        // 请求 IP
        String ip = StringUtils.defaultIfBlank(request.getHeader(MyConst.HEADER_REAL_IP), "%");
        // 请求参数集合
        Map<String, String[]> paramMap = request.getParameterMap();
        Map<String, String> params = new LinkedHashMap<>(paramMap.size());
        for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
            params.put(entry.getKey(), entry.getValue()[0]);
        }
        // 请求参数转 JSON
        String paramsJson = JSONUtil.toJsonStr(params);
        // 通知数据
        String data = params.get("data");
        // 通知签名
        String sign = params.get("sign");
        // 日志提示信息前缀
        String logMsgPrefix = SandPayUtil.getSandPayDesc(method);
        // 日志提示信息
        String logMsg = String.format("%s[异步通知验签{}] %s, noticeData: %s", logMsgPrefix, ip, paramsJson);

        // 验证签名
        boolean result = SandPayCryptoUtil.verifySign(data, sign);
        // 若验签不通过，则响应“失败”字符串，且返回 null
        if (!result) {
            log.error(logMsg, "失败");
            this.response(method, response, false);
            return null;
        }
        // 否则，响应“成功”字符串
        log.info(logMsg, "成功");
        this.response(method, response, true);

        // 解析通知数据
        JSONObject dataObj = JSONUtil.parseObj(data);
        // 响应码
        String respCode = String.valueOf(dataObj.getByPath("head.respCode"));
        // 响应描述
        String respMsg = String.valueOf(dataObj.getByPath("head.respMsg"));
        // 若响应码不为“000000”，则打印响应描述，且返回 null
        if (!SandPayConst.RESP_CODE_SUCCESS.equals(respCode)) {
            log.info("{}[异步通知结果][{} - {}]", logMsgPrefix, respCode, respMsg);
            return null;
        }

        // 封装返回参数
        Map<String, Object> retMap = new HashMap<>(2);
        retMap.put("params", paramsJson);
        retMap.put("respData", dataObj.get("body"));
        return retMap;
    }

    /**
     * 异步通知响应
     *
     * @param method   接口名称
     * @param response HttpServletResponse
     * @param success  是否成功
     */
    private void response(String method, HttpServletResponse response, boolean success) {
        try {
            response.getWriter().print(success ? SandPayConst.CALLBACK_RESP_SUCCESS : SandPayConst.CALLBACK_RESP_FAILURE);
        } catch (IOException ioe) {
            log.error("{} 异步通知响应时发生异常！", SandPayUtil.getSandPayDesc(method), ioe);
        }
    }
}
