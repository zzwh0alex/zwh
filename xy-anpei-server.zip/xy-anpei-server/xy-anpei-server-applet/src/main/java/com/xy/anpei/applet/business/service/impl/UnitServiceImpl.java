package com.xy.anpei.applet.business.service.impl;

import com.xy.anpei.applet.business.service.UnitService;
import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.business.repository.UnitRepository;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.JpaUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author Chen Guibiao
 * Create at 2023-05-18 11:03
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class UnitServiceImpl implements UnitService {

    private final UnitRepository unitRepository;

    public UnitServiceImpl(UnitRepository unitRepository) {
        this.unitRepository = unitRepository;
    }

    @Override
    public Unit getByUnitId(Integer unitId) {
        return unitRepository.findById(unitId).orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND));
    }

    @Override
    public List<Map<String, Object>> getEffectiveUnits() {
        List<Unit> units = unitRepository.findAll(JpaUtil.getDefaultExample(Unit.class), Sort.by("displayOrder"));
        List<Map<String, Object>> list = new ArrayList<>(units.size());
        for (Unit unit : units) {
            Map<String, Object> map = new LinkedHashMap<>(3);
            map.put("unitId", unit.getUnitId());
            map.put("unitName", unit.getUnitName());
            map.put("fullName", unit.getFullName());
            list.add(map);
        }
        return list;
    }
}
