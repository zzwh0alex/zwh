package com.xy.anpei.applet.business.service;

/**
 * @author Chen Guibiao
 * Create at 2023-05-26 13:59
 */
public interface CqayService {

    /**
     * 培训报名
     *
     * @param orderCode 商户订单号
     */
    void register(String orderCode);
}
