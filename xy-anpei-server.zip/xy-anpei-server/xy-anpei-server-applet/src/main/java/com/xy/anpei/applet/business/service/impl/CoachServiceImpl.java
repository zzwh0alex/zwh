package com.xy.anpei.applet.business.service.impl;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.applet.business.dto.coach.CoachLoginDto;
import com.xy.anpei.applet.business.dto.coach.CoachPwdDto;
import com.xy.anpei.applet.business.dto.coach.RegisterDto;
import com.xy.anpei.applet.business.dto.coach.SignUpDto;
import com.xy.anpei.applet.business.login.CoachLocal;
import com.xy.anpei.applet.business.login.CoachLoginInfo;
import com.xy.anpei.applet.business.service.CoachService;
import com.xy.anpei.applet.business.service.SandPayService;
import com.xy.anpei.applet.business.service.UnitService;
import com.xy.anpei.applet.config.AppletConfig;
import com.xy.anpei.applet.util.WxUtil;
import com.xy.anpei.base.business.domain.entity.Coach;
import com.xy.anpei.base.business.domain.entity.RegionFee;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.domain.entity.Unit;
import com.xy.anpei.base.business.domain.model.ViewCoachRegistration;
import com.xy.anpei.base.business.domain.model.ViewCoachUnit;
import com.xy.anpei.base.business.repository.*;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.AesUtil;
import com.xy.anpei.base.util.FileUtil;
import com.xy.anpei.base.util.IdCardUtil;
import com.xy.anpei.base.util.MyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:23
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class CoachServiceImpl implements CoachService {

    private final CoachRepository coachRepository;

    private final TrainRegistrationRepository trainRegistrationRepository;

    private final RegionFeeRepository regionFeeRepository;

    private final ViewCoachUnitRepository viewCoachUnitRepository;

    private final ViewCoachRegistrationRepository viewCoachRegistrationRepository;

    private final UnitService unitService;

    private final SandPayService sandPayService;

    private final AppletConfig appletConfig;

    public CoachServiceImpl(CoachRepository coachRepository,
                            TrainRegistrationRepository trainRegistrationRepository,
                            RegionFeeRepository regionFeeRepository,
                            ViewCoachUnitRepository viewCoachUnitRepository,
                            ViewCoachRegistrationRepository viewCoachRegistrationRepository,
                            UnitService unitService,
                            SandPayService sandPayService,
                            AppletConfig appletConfig) {
        this.coachRepository = coachRepository;
        this.trainRegistrationRepository = trainRegistrationRepository;
        this.regionFeeRepository = regionFeeRepository;
        this.viewCoachUnitRepository = viewCoachUnitRepository;
        this.viewCoachRegistrationRepository = viewCoachRegistrationRepository;
        this.unitService = unitService;
        this.sandPayService = sandPayService;
        this.appletConfig = appletConfig;
    }

    @Override
    public void register(RegisterDto dto) {
        // 校验身份证号
        IdCardUtil.verify(dto.getIdNo());
        // 获取培训机构信息
        Unit unit = unitService.getByUnitId(dto.getUnitId());
        // 保存个人照片（以培训机构全国构统一编号作为上级目录名称，身份证号作为文件名称）
        String imageFullPath = FileUtil.base64ToImage(dto.getPhoto(), appletConfig.getPersonalPhotoPath() + unit.getUnitNo(), dto.getIdNo());
        // 保存教练信息
        Coach coach = new Coach();
        coach.setUnitId(dto.getUnitId());
        coach.setCoachName(StringUtils.deleteWhitespace(dto.getName()));
        coach.setIdNo(dto.getIdNo());
        coach.setPhone(dto.getPhone());
        coach.setAddress(dto.getAddress());
        coach.setPhotoPath(imageFullPath.replace(appletConfig.getPersonalPhotoPath(), ""));
        coach.setStatus(MyConst.STATUS_ENABLED);
        coach.setPassword(dto.getPassword());
        coach.setPlaintext(dto.getPassword());
        coach.setRegistrationTime(new Date());
        coach.setDeleteFlag(MyConst.NOT_DELETED);
        try {
            coachRepository.save(coach);
        } catch (DataIntegrityViolationException dive) {
            log.info("教练注册失败！身份证号或手机号已存在！idNo={}, phone={}", dto.getIdNo(), dto.getPhone());
            throw new BusinessException(Response.DATA_ALREADY_EXISTS);
        } catch (Exception e) {
            log.error("保存教练信息时发生异常！", e);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
    }

    @Override
    public Object login(CoachLoginDto dto) {
        String coachId = dto.getCoachId();
        String password = dto.getPassword();

        // 获取用户 openId
        String openId = WxUtil.getOpenId(appletConfig.getWxAppId(), appletConfig.getWxSecret(), dto.getJsCode());
        // 获取教练信息
        Coach coach = this.getByCoachId(coachId);
        // 校验教练信息
        if (!MyConst.NOT_DELETED.equals(coach.getDeleteFlag())) {
            log.info("账号已删除！coachId={}，password={}", coachId, password);
            throw new BusinessException(Response.ACC_OR_PWD_ERROR);
        }
        if (!MyConst.STATUS_ENABLED.equals(coach.getStatus())) {
            log.info("账号已停用！coachId={}，password={}", coachId, password);
            throw new BusinessException(Response.ACCOUNT_FROZEN);
        }
        if (!StringUtils.equals(password, coach.getPassword())) {
            log.info("密码错误！coachId={}，password={}", coachId, password);
            throw new BusinessException(Response.ACC_OR_PWD_ERROR);
        }

        // 保存用户 openId
        coach.setOpenId(openId);
        coachRepository.save(coach);

        // 创建登录信息实例
        CoachLoginInfo loginInfo = new CoachLoginInfo();
        loginInfo.setOpenId(openId);
        loginInfo.setCoachId(coachId);
        loginInfo.setExpiryTime(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(120L));

        // 构造返回数据
        Map<String, String> retMap = new HashMap<>(3);
        retMap.put("openId", openId);
        retMap.put("coachId", coachId);
        retMap.put("token", AesUtil.encrypt(JSONUtil.toJsonStr(loginInfo)));
        return retMap;
    }

    @Override
    public Object getProfile() {
        ViewCoachUnit coach = this.getCoachInfo();

        Map<String, Object> retMap = new LinkedHashMap<>();
        retMap.put("coachId", coach.getCoachId());
        retMap.put("coachName", coach.getCoachName());
        retMap.put("idNo", coach.getIdNo());
        retMap.put("phone", coach.getPhone());
        retMap.put("address", StringUtils.defaultIfBlank(coach.getAddress(), ""));
        retMap.put("status", coach.getStatus());
        retMap.put("statusDesc", coach.getStatusDesc());
        retMap.put("registrationTime", MyUtil.formatTime(coach.getRegistrationTime()));
        retMap.put("unitName", coach.getUnitName());
        retMap.put("fullName", coach.getUnitFullName());
        retMap.put("photo", StringUtils.isBlank(coach.getPhoto()) ? "" : appletConfig.getPersonalPhotoUrl() + coach.getPhoto().replace(File.separator, "/"));

        return retMap;
    }

    @Override
    public void changePassword(CoachPwdDto dto) {
        if (!StringUtils.equals(dto.getNewPwd(), dto.getCheckPwd())) {
            throw new BusinessException(Response.PARAM_ERROR, "新密码和确认密码不一致");
        }
        Coach coach = this.getByCoachId(CoachLocal.getCoachId());
        if (!StringUtils.equals(coach.getPassword(), dto.getCurrPwd())) {
            throw new BusinessException(Response.ACC_OR_PWD_ERROR);
        }
        coach.setPassword(dto.getNewPwd());
        coach.setPlaintext(dto.getNewPwd());
        coachRepository.save(coach);
    }

    @Override
    public Object getTrainingFee() {
        ViewCoachUnit coach = this.getCoachInfo();
        RegionFee fee = regionFeeRepository.findByCityId(coach.getCityId())
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND));
        return fee.getTrainingFee();
    }

    @Override
    public Object signUp(SignUpDto dto) {
        // 获取教练信息（报名前先确认教练信息存在）
        ViewCoachUnit coach = getCoachInfo();

        // 发起支付
        Map<String, Object> map = sandPayService.unifiedOrder(dto.getTrainingFee(), CoachLocal.getOpenId());
        // 商户订单号
        String orderCode = (String) map.get("orderCode");
        // 微信小程序支付参数
        Object params = map.get("params");

        // 报名照片父目录
        String parentPath = String.format("%s%s%s%s", appletConfig.getRegisterPhotoPath(), dto.getYear(), File.separator, coach.getUnitNo());
        // 报名照片文件名
        String imageName = String.format("%s_%s", coach.getIdNo(), System.currentTimeMillis());
        // 报名照片相对路径
        String imageRelativePath = null;
        // 若报名照片为空，则使用个人照片
        if (StringUtils.isBlank(dto.getPhoto())) {
            if (StringUtils.isNotBlank(coach.getPhoto())) {
                File source = new File(appletConfig.getPersonalPhotoPath() + coach.getPhoto());
                String fileType = source.getAbsolutePath().substring(source.getAbsolutePath().lastIndexOf("."));
                File dest = FileUtil.create(parentPath + File.separator + imageName + fileType);
                FileUtil.copy(source, dest);
                imageRelativePath = dest.getAbsolutePath().replace(appletConfig.getRegisterPhotoPath(), "");
            } else {
                log.info("培训报名保存报名照片失败！因为个人照片不存在！coachId={}", CoachLocal.getCoachId());
            }
        } else {
            try {
                String imageFullPath = FileUtil.base64ToImage(dto.getPhoto(), parentPath, imageName);
                imageRelativePath = imageFullPath.replace(appletConfig.getRegisterPhotoPath(), "");
            } catch (Exception e) {
                log.info("培训报名保存报名照片时发生异常！parentPath={}, imageName={}", parentPath, imageName);
            }
        }

        // 保存培训报名记录
        TrainRegistration tr = new TrainRegistration();
        tr.setAreaCode(coach.getCityId());
        tr.setUnitId(coach.getUnitId());
        tr.setUnitNo(coach.getUnitNo());
        tr.setUnitName(coach.getUnitName());
        tr.setUnitFullName(coach.getUnitFullName());
        tr.setCoachId(coach.getCoachId());
        tr.setCoachName(coach.getCoachName());
        tr.setIdNo(coach.getIdNo());
        tr.setPhone(coach.getPhone());
        tr.setPhotoPath(imageRelativePath);
        tr.setTrainYear(dto.getYear());
        tr.setAddress(coach.getAddress());
        tr.setOrderCode(orderCode);
        tr.setTotalAmount(dto.getTrainingFee());
        tr.setDiscAmount(0);
        tr.setBuyerPayAmount(dto.getTrainingFee());
        tr.setPayStatus(MyConst.PAY_STATUS_WAIT);
        tr.setCreateTime(new Date());
        trainRegistrationRepository.save(tr);

        // 返回微信小程序支付参数
        return params;
    }

    @Override
    public Object checkRegistrationStatus() {
        ViewCoachRegistration cr = this.getCoachRegistration();
        if (null == cr || StringUtils.isNotBlank(cr.getCertUrl())) {
            return null;
        }
        return cr.getIdNo();
    }

    /**
     * 根据身份证号或手机号码获取教练信息
     *
     * @param coachId 身份证号或手机号码
     * @return Coach
     */
    private Coach getByCoachId(String coachId) {
        Optional<Coach> coach = Optional.empty();
        if (coachId.length() == MyConst.PHONE_LENGTH) {
            coach = coachRepository.findByPhone(coachId);
        } else if (coachId.length() == MyConst.ID_CARD_LENGTH_18 || coachId.length() == MyConst.ID_CARD_LENGTH_15) {
            IdCardUtil.verify(coachId);
            coach = coachRepository.findByIdNo(coachId);
        }
        return coach.orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND));
    }

    /**
     * 获取教练个人信息
     *
     * @return ViewCoachUnit
     */
    private ViewCoachUnit getCoachInfo() {
        Optional<ViewCoachUnit> coach = Optional.empty();
        String coachId = CoachLocal.getCoachId();
        if (coachId.length() == MyConst.PHONE_LENGTH) {
            coach = viewCoachUnitRepository.findByPhone(coachId);
        } else if (coachId.length() == MyConst.ID_CARD_LENGTH_18 || coachId.length() == MyConst.ID_CARD_LENGTH_15) {
            coach = viewCoachUnitRepository.findByIdNo(coachId);
        }
        return coach.orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND));
    }

    /**
     * 获取教练个人信息
     *
     * @return ViewCoachRegistration
     */
    private ViewCoachRegistration getCoachRegistration() {
        Optional<ViewCoachRegistration> coach = Optional.empty();
        String coachId = CoachLocal.getCoachId();
        if (coachId.length() == MyConst.PHONE_LENGTH) {
            coach = viewCoachRegistrationRepository.findByPhone(coachId);
        } else if (coachId.length() == MyConst.ID_CARD_LENGTH_18 || coachId.length() == MyConst.ID_CARD_LENGTH_15) {
            coach = viewCoachRegistrationRepository.findByIdNo(coachId);
        }
        return coach.orElse(null);
    }
}
