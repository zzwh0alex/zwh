package com.xy.anpei.applet.business.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-05-24 09:03
 */
public interface SandPayService {

    /**
     * 统一下单
     *
     * @param totalAmount 订单金额，单位：分
     * @param openId      微信小程序用户 openId
     * @return Map<String, Object>
     */
    Map<String, Object> unifiedOrder(Integer totalAmount, String openId);

    /**
     * 统一下单回调
     *
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     */
    void unifiedOrderCallback(HttpServletRequest request, HttpServletResponse response);

    /**
     * 退货申请回调
     *
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     */
    void refundCallback(HttpServletRequest request, HttpServletResponse response);
}
