package com.xy.anpei.applet.util;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 微信工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-18 17:32
 */
@Slf4j
public class WxUtil {

    /**
     * 获取用户 openId
     *
     * @param appId  微信小程序 appId
     * @param secret 微信小程序 secret
     * @param jsCode 微信小程序登录时获取的 code
     * @return 用户 openId
     */
    public static String getOpenId(String appId, String secret, String jsCode) {
        String reqUrl = String.format("%s%s?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code",
                MyConst.WX_BASE_API, "/sns/jscode2session", appId, secret, jsCode);
        String respBody = HttpUtil.get(reqUrl);

        JSONObject respObj = JSONUtil.parseObj(respBody);
        Integer errCode = (Integer) respObj.get("errcode");
        String errMsg = (String) respObj.get("errmsg");
        if (null != errCode && errCode != 0) {
            log.error("获取用户openid时发生异常！[{} - {}], jsCode={}", errCode, errMsg, jsCode);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }
        String openId = (String) respObj.get("openid");
        if (StringUtils.isBlank(openId)) {
            log.error("获取用户openid时发生异常！openid为空！jsCode={}", jsCode);
            throw new BusinessException(Response.SERVICE_EXCEPTION);
        }

        return openId;
    }
}
