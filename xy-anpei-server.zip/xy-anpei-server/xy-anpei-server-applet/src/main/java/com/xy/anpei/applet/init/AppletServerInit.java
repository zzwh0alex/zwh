package com.xy.anpei.applet.init;

import com.xy.anpei.applet.config.AppletConfig;
import com.xy.anpei.base.util.cqay.CqayUtil;
import com.xy.anpei.base.util.sandpay.SandPayCertUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author Chen Guibiao
 * Create at 2023-05-24 16:01
 */
@Slf4j
@Component
public class AppletServerInit {

    private final AppletConfig config;

    public AppletServerInit(AppletConfig config) {
        this.config = config;
    }

    @PostConstruct
    public void init() {
        log.info("================================================== 开始执行自定义初始化操作 ==================================================");

        // 杉德支付初始化
        SandPayCertUtil.init(config.getSandPayPublicKeyPath(), config.getSandPayPrivateKeyPath(), config.getSandPayPrivateKeyPassword());
        // 重庆安运科技初始化
        CqayUtil.init(config.getCqayUrl(), config.getCqayToken());

        log.info("================================================== 结束执行自定义初始化操作 ==================================================");
    }
}
