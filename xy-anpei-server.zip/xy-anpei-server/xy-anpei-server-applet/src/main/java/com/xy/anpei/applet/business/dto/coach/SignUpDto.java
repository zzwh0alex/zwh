package com.xy.anpei.applet.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-05-20 13:26
 */
@Data
public class SignUpDto {

    /**
     * 培训费（单位：分）
     */
    @NotNull(message = "培训费不能为空")
    @Min(value = 0, message = "培训费不正确")
    private Integer trainingFee;

    /**
     * 培训年度
     */
    @NotNull(message = "培训年度不能为空")
    private Integer year;

    /**
     * 报名照片
     */
    @Pattern(regexp = "^$|^data:image/.*;base64,.*", message = "报名照片格式不正确")
    private String photo;
}
