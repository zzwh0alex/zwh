package com.xy.anpei.applet.business.dto.helper;

import lombok.Data;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 11:29
 */
@Data
public class SignatureDto {

    /**
     * 鉴权码
     */
    private String auth;

    /**
     * 待签名的参数（JSON）
     */
    private String json;
}
