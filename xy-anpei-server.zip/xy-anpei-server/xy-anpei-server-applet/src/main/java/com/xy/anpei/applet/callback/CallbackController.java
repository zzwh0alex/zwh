package com.xy.anpei.applet.callback;

import com.xy.anpei.applet.business.service.SandPayService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Chen Guibiao
 * Create at 2023-05-24 16:27
 */
@RestController
@RequestMapping("/callback")
public class CallbackController {

    private final SandPayService sandPayService;

    public CallbackController(SandPayService sandPayService) {
        this.sandPayService = sandPayService;
    }

    @RequestMapping(value = "/sandPay/unifiedOrder", name = "杉德支付统一下单回调")
    public void unifiedOrderCallback(HttpServletRequest request, HttpServletResponse response) {
        sandPayService.unifiedOrderCallback(request, response);
    }

    @RequestMapping(value = "/sandPay/refund", name = "杉德支付退货申请回调")
    public void refundCallback(HttpServletRequest request, HttpServletResponse response) {
        sandPayService.refundCallback(request, response);
    }
}
