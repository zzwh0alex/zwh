package com.xy.anpei.applet.business.login;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 15:38
 */
public class CoachLocal {

    private static final ThreadLocal<CoachLoginInfo> LOGIN_LOCAL = new ThreadLocal<>();

    /**
     * 教练账号 ID
     *
     * @return 教练账号 ID
     */
    public static String getCoachId() {
        return LOGIN_LOCAL.get().getCoachId();
    }

    /**
     * 获取微信小程序用户 openId
     *
     * @return 微信小程序用户 openId
     */
    public static String getOpenId() {
        return LOGIN_LOCAL.get().getOpenId();
    }

    /**
     * 缓存会话消息
     *
     * @param info CoachLoginInfo
     */
    public static void setInfo(CoachLoginInfo info) {
        LOGIN_LOCAL.set(info);
    }

    /**
     * 清除会话消息
     */
    public static void removeLogin() {
        LOGIN_LOCAL.remove();
    }
}
