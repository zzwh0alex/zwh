package com.xy.anpei.applet.business.service;

import com.xy.anpei.base.business.domain.entity.Unit;

import java.util.List;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-05-18 11:03
 */
public interface UnitService {

    /**
     * 根据培训机构 ID 获取培训机构信息
     *
     * @param unitId 培训机构 ID
     * @return Unit
     */
    Unit getByUnitId(Integer unitId);

    /**
     * 获取未删除的培训机构列表
     *
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getEffectiveUnits();
}
