package com.xy.anpei.applet.business.service;

import com.xy.anpei.applet.business.dto.coach.CoachLoginDto;
import com.xy.anpei.applet.business.dto.coach.CoachPwdDto;
import com.xy.anpei.applet.business.dto.coach.RegisterDto;
import com.xy.anpei.applet.business.dto.coach.SignUpDto;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 09:19
 */
public interface CoachService {

    /**
     * 注册
     *
     * @param dto RegisterDto
     */
    void register(RegisterDto dto);

    /**
     * 登录
     *
     * @param dto CoachLoginDto
     * @return Object
     */
    Object login(CoachLoginDto dto);

    /**
     * 获取个人信息
     *
     * @return Object
     */
    Object getProfile();

    /**
     * 修改密码
     *
     * @param dto CoachPwdDto
     */
    void changePassword(CoachPwdDto dto);

    /**
     * 获取培训费用
     *
     * @return Object
     */
    Object getTrainingFee();

    /**
     * 培训报名
     *
     * @param dto SignUpDto
     * @return Object
     */
    Object signUp(SignUpDto dto);

    /**
     * 检查培训报名状态
     *
     * @return Object
     */
    Object checkRegistrationStatus();
}
