package com.xy.anpei.applet.business.controller;

import com.xy.anpei.applet.business.service.UnitService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Chen Guibiao
 * Create at 2023-05-18 11:24
 */
@RestController
@RequestMapping("/unit")
public class UnitController {

    private final UnitService unitService;

    public UnitController(UnitService unitService) {
        this.unitService = unitService;
    }

    @GetMapping(value = "/getUnits", name = "获取培训机构列表")
    public Object getUnits() {
        return unitService.getEffectiveUnits();
    }
}
