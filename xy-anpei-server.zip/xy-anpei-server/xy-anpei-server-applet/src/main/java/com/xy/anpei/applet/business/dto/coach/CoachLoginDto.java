package com.xy.anpei.applet.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 10:01
 */
@Data
public class CoachLoginDto {

    /**
     * 教练账号 ID
     */
    @NotBlank(message = "账号不能为空")
    private String coachId;

    /**
     * 账号密码
     */
    @NotBlank(message = "密码不能为空")
    private String password;

    /**
     * 微信小程序 jsCode
     */
    @NotBlank(message = "登录凭证不能为空")
    private String jsCode;
}
