package com.xy.anpei.applet.business.controller;

import com.xy.anpei.applet.annotation.CoachLogin;
import com.xy.anpei.applet.business.dto.coach.CoachLoginDto;
import com.xy.anpei.applet.business.dto.coach.CoachPwdDto;
import com.xy.anpei.applet.business.dto.coach.RegisterDto;
import com.xy.anpei.applet.business.dto.coach.SignUpDto;
import com.xy.anpei.applet.business.service.CoachService;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 10:53
 */
@RestController
@RequestMapping("/coach")
public class CoachController {

    private final CoachService coachService;

    public CoachController(CoachService coachService) {
        this.coachService = coachService;
    }

    @PostMapping(value = "/register", name = "教练注册")
    public void register(@RequestBody @Valid RegisterDto dto) {
        coachService.register(dto);
    }

    @PostMapping(value = "/login", name = "教练登录")
    public Object login(@RequestBody @Valid CoachLoginDto dto) {
        return coachService.login(dto);
    }

    @CoachLogin
    @GetMapping(value = "/getProfile", name = "获取个人信息")
    public Object getProfile() {
        return coachService.getProfile();
    }

    @CoachLogin
    @PostMapping(value = "/changePwd", name = "修改密码")
    public void changePassword(@RequestBody @Valid CoachPwdDto dto) {
        coachService.changePassword(dto);
    }

    @CoachLogin
    @GetMapping(value = "/getTrainingFee", name = "获取培训费用")
    public Object getTrainingFee() {
        return coachService.getTrainingFee();
    }

    @CoachLogin
    @PostMapping(value = "/signUp", name = "培训报名")
    public Object signUp(@RequestBody @Valid SignUpDto dto) {
        return coachService.signUp(dto);
    }

    @CoachLogin
    @GetMapping(value = "/checkRegistrationStatus", name = "检查报名状态")
    public Object checkRegistrationStatus() {
        return coachService.checkRegistrationStatus();
    }
}
