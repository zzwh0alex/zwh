package com.xy.anpei.applet.business.login;

import lombok.Data;

/**
 * @author Chen Guibiao
 * Create at 2023-05-17 15:30
 */
@Data
public class CoachLoginInfo {

    /**
     * 微信小程序用户 openId
     */
    private String openId;

    /**
     * 教练账号 ID
     */
    private String coachId;

    /**
     * 到期时间
     */
    private long expiryTime;
}
