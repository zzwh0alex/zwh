package com.xy.anpei.applet.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-05-18 14:20
 */
@Data
public class RegisterDto {

    /**
     * 培训机构 ID
     */
    @NotNull(message = "培训机构编号不能为空")
    private Integer unitId;

    /**
     * 教练姓名
     */
    @NotBlank(message = "姓名不能为空")
    private String name;

    /**
     * 身份证号
     */
    @NotBlank(message = "身份证号不能为空")
    private String idNo;

    /**
     * 手机号码
     */
    @NotBlank(message = "手机号码不能为空")
    @Pattern(regexp = "^$|^1[3-9]\\d{9}$", message = "手机号码格式不正确")
    private String phone;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 账号密码
     */
    @NotBlank(message = "账号密码不能为空")
    private String password;

    /**
     * 个人照片
     */
    @NotBlank(message = "个人照片不能为空")
    @Pattern(regexp = "^data:image/.*;base64,.*", message = "个人照片格式不正确")
    private String photo;
}
