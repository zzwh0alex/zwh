package com.xy.anpei.applet.business.service.impl;

import com.xy.anpei.applet.business.service.CqayService;
import com.xy.anpei.applet.config.AppletConfig;
import com.xy.anpei.base.business.domain.entity.TrainRegistration;
import com.xy.anpei.base.business.repository.TrainRegistrationRepository;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Response;
import com.xy.anpei.base.util.FileUtil;
import com.xy.anpei.base.util.cqay.CqayUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Chen Guibiao
 * Create at 2023-05-26 14:00
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class CqayServiceImpl implements CqayService {

    private final TrainRegistrationRepository trainRegistrationRepository;

    private final AppletConfig appletConfig;

    public CqayServiceImpl(TrainRegistrationRepository trainRegistrationRepository, AppletConfig appletConfig) {
        this.trainRegistrationRepository = trainRegistrationRepository;
        this.appletConfig = appletConfig;
    }

    @Override
    public void register(String orderCode) {
        // 根据商户订单号获取报名记录
        TrainRegistration tr = trainRegistrationRepository.findByOrderCode(orderCode)
                .orElseThrow(() -> new BusinessException(Response.DATA_NOT_FOUND, String.format("未找到订单号为[%s]的报名记录", orderCode)));

        // 封装请求参数
        Map<String, Object> data = new LinkedHashMap<>(10);
        // 地区代码（必须）
        data.put("areaCode", tr.getAreaCode());
        // 培训机构编号（必须）
        data.put("unitNo", tr.getUnitNo());
        // 培训机构名称（必须）
        data.put("unitName", tr.getUnitFullName());
        // 教练员 ID（必须）
        data.put("coachId", tr.getCoachId());
        // 教练员姓名（必须）
        data.put("name", tr.getCoachName());
        // 身份证号（必须）
        data.put("idCard", tr.getIdNo());
        // 手机号码（必须）
        data.put("phone", tr.getPhone());
        // 登记照片（必须）
        data.put("photo", FileUtil.imageToBase64(appletConfig.getRegisterPhotoPath() + tr.getPhotoPath(), false));
        // 培训年度（必须）
        data.put("year", tr.getTrainYear());
        // 地址（非必须）
        data.put("address", tr.getAddress());

        // 发送请求，获取报名记录 ID
        String trainId = CqayUtil.register(data);

        // 保存报名记录 ID
        tr.setTrainId(trainId);
        trainRegistrationRepository.save(tr);
    }
}
