package com.xy.anpei.thirdparty.aspect;

import com.xy.anpei.base.response.Result;
import com.xy.anpei.thirdparty.local.ThirdPartyLocal;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 应答切面
 *
 * @author Chen Guibiao
 * Create at 2023-05-22 14:35
 */
@Aspect
@Component
@Order(3)
public class ResponseAspect {

    @Around("execution(* com.xy.anpei.thirdparty.business.controller..*(..))")
    public Object aroundController(ProceedingJoinPoint jp) throws Throwable {
        // 执行业务代码
        Object retObj = jp.proceed(jp.getArgs());
        // 判断返回结果是否为空
        if (null == retObj) {
            // 若返回结果为空（即业务方法返回类型为 void），则构造通用应答数据
            Result success = Result.success();
            // 同时缓存应答数据
            ThirdPartyLocal.setResult(success);
            // 返回通用应答数据
            return success;
        }
        // 若返回结果类型不为 Result，则先封装后返回
        return (retObj instanceof Result) ? retObj : Result.success(retObj);
    }
}
