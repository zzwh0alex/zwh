package com.xy.anpei.thirdparty.business.service.impl;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.business.domain.entity.TrainCertificate;
import com.xy.anpei.base.business.domain.entity.TrainStudyTime;
import com.xy.anpei.base.business.repository.TrainCertificateRepository;
import com.xy.anpei.base.business.repository.TrainStudyTimeRepository;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.util.FileUtil;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SignUtil;
import com.xy.anpei.thirdparty.business.dto.coach.GraduationDto;
import com.xy.anpei.thirdparty.business.dto.coach.StudyTimeDto;
import com.xy.anpei.thirdparty.business.dto.coach.TestDataDto;
import com.xy.anpei.thirdparty.business.service.CoachService;
import com.xy.anpei.thirdparty.config.ThirdPartyConfig;
import com.xy.anpei.thirdparty.util.TestDataUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 13:59
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class CoachServiceImpl implements CoachService {

    private final TrainStudyTimeRepository trainStudyTimeRepository;

    private final TrainCertificateRepository trainCertificateRepository;

    private final ThirdPartyConfig tpConfig;

    public CoachServiceImpl(TrainStudyTimeRepository trainStudyTimeRepository,
                            TrainCertificateRepository trainCertificateRepository,
                            ThirdPartyConfig tpConfig) {
        this.trainStudyTimeRepository = trainStudyTimeRepository;
        this.trainCertificateRepository = trainCertificateRepository;
        this.tpConfig = tpConfig;
    }

    @Override
    public void studyTime(StudyTimeDto dto) {
        // 校验请求参数
        SignUtil.verify(dto, tpConfig.getCqaySecretKey(), tpConfig.getCqayValidTime());

        // 保存学时记录
        TrainStudyTime record = new TrainStudyTime();
        record.setTrainId(dto.getTrainId());
        record.setUnitNo(dto.getUnitNo());
        record.setCoachId(Integer.parseInt(dto.getCoachId()));
        record.setSubjectName(dto.getSubjectName());
        record.setCourseName(dto.getCourseName());
        record.setTimeType(this.parseTimeType(dto.getTimeType()));
        record.setStartTime(MyUtil.parseToDate(dto.getStartTime()));
        record.setEndTime(MyUtil.parseToDate(dto.getEndTime()));
        record.setDuration(dto.getDuration());
        record.setStatus(dto.getStatus());
        record.setStuIdNo(dto.getStuIdCard());
        record.setClient(dto.getClient());
        record.setRequestIp(dto.getRequestIp());
        record.setRemark(dto.getRemark());
        record.setPhotoList(JSONUtil.toJsonStr(dto.getPhotoList()));
        record.setCreateTime(new Date());
        trainStudyTimeRepository.save(record);
    }

    @Override
    public void graduation(GraduationDto dto) {
        // 校验请求参数
        SignUtil.verify(dto, tpConfig.getCqaySecretKey(), tpConfig.getCqayValidTime());

        // 保存结业证信息
        TrainCertificate cert = new TrainCertificate();
        cert.setTrainId(dto.getTrainId());
        cert.setUnitNo(dto.getUnitNo());
        cert.setCoachId(Integer.parseInt(dto.getCoachId()));
        cert.setCertUrl(dto.getUrl());
        cert.setCreateTime(new Date());
        trainCertificateRepository.save(cert);

        // 保存图片到本地
        FileUtil.downloadImage(dto.getUrl(), tpConfig.getGraduationPhotoPath() + dto.getUnitNo(), dto.getTrainId() + "");
    }

    @Override
    public Object getTestData(TestDataDto dto) {
        return TestDataUtil.getTestData(dto.getServiceType(), JSONUtil.parseObj(dto.getSpecifics()));
    }

    /**
     * 解析学时类型
     *
     * @param timeType 学时类型（字符串）
     * @return 学时类型（整型）
     */
    private Integer parseTimeType(String timeType) {
        return MyConst.TIME_TYPE_VIDEO_STR.equals(timeType) ? MyConst.TIME_TYPE_VIDEO_INT : MyConst.TIME_TYPE_PRACTICE_INT;
    }
}
