package com.xy.anpei.thirdparty.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 16:33
 */
@Data
public class TestDataDto {

    /**
     * 服务类型
     */
    @Pattern(regexp = "^$|^studyTime|graduation$", message = "服务类型不正确")
    private String serviceType;

    /**
     * 指定值集合
     */
    private Object specifics;
}
