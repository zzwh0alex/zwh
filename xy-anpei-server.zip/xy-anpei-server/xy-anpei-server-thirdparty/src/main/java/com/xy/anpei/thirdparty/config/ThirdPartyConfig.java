package com.xy.anpei.thirdparty.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.File;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 14:08
 */
@Configuration
public class ThirdPartyConfig {

    /**
     * 重庆安运请求我方系统接口密钥
     */
    @Value("${cqay.secret.key}")
    private String cqaySecretKey;

    /**
     * 重庆安运请求我方系统接口有效时间
     */
    @Value("${cqay.valid.time}")
    private long cqayValidTime;

    /**
     * 结业照片存储目录
     */
    @Value("${photo.path.graduation}")
    private String graduationPhotoPath;

    public String getCqaySecretKey() {
        return cqaySecretKey;
    }

    public long getCqayValidTime() {
        return cqayValidTime;
    }

    public String getGraduationPhotoPath() {
        return getLocalePath(graduationPhotoPath);
    }

    /**
     * 获取本地系统路径
     *
     * @param path 路径
     * @return 本地系统路径
     */
    private String getLocalePath(String path) {
        path = path.replace("/", File.separator).replace("\\", File.separator);
        return path.endsWith(File.separator) ? path : path + File.separator;
    }
}
