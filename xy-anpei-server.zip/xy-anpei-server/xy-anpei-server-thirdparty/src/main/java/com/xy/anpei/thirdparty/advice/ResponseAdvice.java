package com.xy.anpei.thirdparty.advice;

import com.xy.anpei.thirdparty.local.ThirdPartyLocal;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 14:36
 */
@RestControllerAdvice(basePackages = "com.xy.anpei.thirdparty.business.controller")
public class ResponseAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter methodParameter, Class<? extends HttpMessageConverter<?>> aClass) {
        // 如果不需要进行封装，可以添加一些校验手段，比如添加标记排除的注解
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter methodParameter, MediaType mediaType, Class<? extends HttpMessageConverter<?>> aClass, ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse) {
        // 判断返回结果是否为空
        if (null == body) {
            // 若返回结果为空（即业务方法返回类型为 void），则从缓存中获取应答数据
            body = ThirdPartyLocal.getResult();
        }
        // 清除缓存
        ThirdPartyLocal.removeResult();
        // 返回应答数据
        return body;
    }
}
