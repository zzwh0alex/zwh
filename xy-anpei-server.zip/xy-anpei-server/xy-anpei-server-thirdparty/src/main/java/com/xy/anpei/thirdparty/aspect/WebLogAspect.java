package com.xy.anpei.thirdparty.aspect;

import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.exception.BusinessException;
import com.xy.anpei.base.response.Result;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SpringUtil;
import com.xy.anpei.thirdparty.local.ThirdPartyLocal;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 日志切面
 *
 * @author Chen Guibiao
 * Create at 2023-05-22 14:30
 */
@Aspect
@Component
@Order(1)
@Slf4j
public class WebLogAspect {

    @Around("execution(* com.xy.anpei.thirdparty.business.controller..*(..))")
    public Object aroundController(ProceedingJoinPoint jp) {
        // 创建计时器
        StopWatch watch = new StopWatch();
        // 开始计时
        watch.start();
        // 解析请求信息
        Map<String, Object> map = this.parseRequestInfo(jp);
        try {
            // 执行业务代码
            Object retObj = jp.proceed(jp.getArgs());
            // 停止计时
            watch.stop();
            // 从左到右依次是：URI、IP、耗时、请求参数、应答数据
            log.info("{}, {}, {}ms, reqBody:{}, respBody:{}",
                    map.get("uri"),
                    map.get("ip"),
                    watch.getTotalTimeMillis(),
                    map.get("reqBody"),
                    this.toJsonStr(retObj));
            // 返回业务数据
            return retObj;
        } catch (BusinessException be) {
            // 停止计时
            watch.stop();
            // 构造错误提示应答数据
            Result failure = Result.failure(be.getResult(), be.getMessage());
            // 缓存应答数据
            ThirdPartyLocal.setResult(failure);
            // 从左到右依次是：提示信息、URI、IP、耗时、请求参数、应答数据
            log.info("[{}] {}, {}, {}ms, reqBody:{}, respBody:{}",
                    be.getMessage(),
                    map.get("uri"),
                    map.get("ip"),
                    watch.getTotalTimeMillis(),
                    map.get("reqBody"),
                    this.toJsonStr(failure));
            // 返回错误提示
            return failure;
        } catch (Throwable throwable) {
            // 停止计时
            watch.stop();
            // 构造错误提示应答数据
            Result failure = Result.failure();
            // 缓存应答数据
            ThirdPartyLocal.setResult(failure);
            // 从左到右依次是：异常信息、URI、IP、耗时、异常类型、请求参数、应答数据
            log.error("[{}] {}, {}, {}ms, {} reqBody:{}, respBody:{}",
                    throwable.getMessage(),
                    map.get("uri"),
                    map.get("ip"),
                    watch.getTotalTimeMillis(),
                    throwable.getClass().getSimpleName(),
                    map.get("reqBody"),
                    this.toJsonStr(failure),
                    throwable);
            // 返回错误提示
            return failure;
        }
    }

    /**
     * 解析请求信息
     *
     * @param jp ProceedingJoinPoint
     * @return 请求信息 Map
     */
    private Map<String, Object> parseRequestInfo(ProceedingJoinPoint jp) {
        Map<String, Object> reqInfo = new HashMap<>(5);
        HttpServletRequest request = SpringUtil.getRequest();
        reqInfo.put("uri", request.getRequestURI());
        reqInfo.put("ip", StringUtils.defaultIfBlank(request.getHeader(MyConst.HEADER_REAL_IP), "%"));
        reqInfo.put("reqBody", this.parseRequestParams(jp));
        return reqInfo;
    }

    /**
     * 解析请求参数
     *
     * @param jp ProceedingJoinPoint
     * @return 请求参数 List
     */
    private List<Object> parseRequestParams(ProceedingJoinPoint jp) {
        List<Object> list = new ArrayList<>();
        Object[] args = jp.getArgs();
        for (Object arg : args) {
            if (null == arg) {
                list.add("null");
            } else if (arg instanceof MultipartFile) {
                list.add("MultipartFile");
            } else if (arg instanceof ServletRequest) {
                list.add("ServletRequest");
            } else if (arg instanceof ServletResponse) {
                list.add("ServletResponse");
            } else {
                list.add(JSONUtil.toJsonStr(arg));
            }
        }
        return list;
    }

    /**
     * 对象转 JSON
     *
     * @param obj 对象
     * @return JSON 字符串
     */
    private String toJsonStr(Object obj) {
        String jsonStr;
        try {
            // 为了让 @JsonIgnore 生效，这里使用 Jackson 将对象转为 JSON 字符串
            jsonStr = MyUtil.toJsonStr(obj);
        } catch (BusinessException be) {
            // 若转换过程中出现异常，则转用 Hutool 的 JSONUtil 将对象转为 JSON 字符串
            jsonStr = JSONUtil.toJsonStr(obj);
        }
        return jsonStr;
    }
}
