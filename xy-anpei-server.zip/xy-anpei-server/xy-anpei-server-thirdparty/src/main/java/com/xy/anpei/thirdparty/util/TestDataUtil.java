package com.xy.anpei.thirdparty.util;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.xy.anpei.base.constant.MyConst;
import com.xy.anpei.base.util.MyUtil;
import com.xy.anpei.base.util.SignUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 测试数据工具类
 *
 * @author Chen Guibiao
 * Create at 2023-05-23 09:03
 */
@Slf4j
public class TestDataUtil {

    /**
     * 获取测试数据
     *
     * @param serviceType 服务类型
     * @param specifics   指定值集合
     * @return 测试数据
     */
    public static Object getTestData(String serviceType, JSONObject specifics) {
        Object testData = "^_^";
        if (StringUtils.isBlank(serviceType)) {
            return testData;
        }
        try {
            Class<TestDataUtil> clazz = TestDataUtil.class;
            String methodName = String.format("get%s%sTestData", serviceType.substring(0, 1).toUpperCase(), serviceType.substring(1));
            testData = clazz.getDeclaredMethod(methodName, specifics.getClass()).invoke(clazz.newInstance(), specifics);
        } catch (Exception e) {
            log.error("获取测试数据时发生异常！serviceType={}, specifics={}", serviceType, JSONUtil.toJsonStr(specifics), e);
        }
        return testData;
    }

    /**
     * 获取测试数据 - 上传教练员学时记录
     *
     * @return 上传教练员学时记录接口测试数据
     */
    private Object getStudyTimeTestData(JSONObject specifics) {
        Map<String, Object> data = new LinkedHashMap<>(32);
        data.put("trainId", MyUtil.getRandomNum(18));
        data.put("unitNo", MyUtil.generateNonceStr(16));
        data.put("coachId", MyUtil.getRandomNumInRange(1, 1000) + "");
        data.put("subjectName", "职工交通安全基础知识");
        data.put("courseName", "超速行驶");
        data.put("timeType", MyUtil.getRandomFrom("video", "practice"));
        data.put("startTime", MyUtil.formatTime(new Date()));
        data.put("endTime", MyUtil.formatTime(new Date()));
        data.put("duration", MyUtil.getRandomNumInRange(1, 30));
        data.put("status", MyUtil.getRandomFrom(0, 1));
        data.put("stuIdCard", MyUtil.getRandomNum(18));
        data.put("client", MyUtil.getRandomFrom("web", "android", "ios"));
        data.put("requestIp", "127.0.0.1");
        data.put("remark", MyUtil.generateNonceStr(8));
        data.put("photoList", null);
        return this.getTestDataMap(data, specifics);
    }

    /**
     * 获取测试数据 - 上传教练员结业证
     *
     * @return 上传教练员结业证接口测试数据
     */
    private Object getGraduationTestData(JSONObject specifics) {
        Map<String, Object> data = new LinkedHashMap<>(32);
        data.put("trainId", MyUtil.getRandomNum(18));
        data.put("unitNo", MyUtil.generateNonceStr(16));
        data.put("coachId", MyUtil.getRandomNumInRange(1, 1000) + "");
        data.put("url", "https://img1.baidu.com/it/u=4172228887,1599550215&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=538");
        return this.getTestDataMap(data, specifics);
    }

    /**
     * 获取测试数据
     *
     * @param defaults  默认值集合
     * @param specifics 指定值集合
     * @return 测试数据
     */
    private Map<String, Object> getTestDataMap(Map<String, Object> defaults, JSONObject specifics) {
        defaults.put("requestTime", System.currentTimeMillis());
        defaults.put("nonce", MyUtil.generateNonceStr());
        defaults.put("signType", MyUtil.getRandomFrom(null, MyConst.SIGN_TYPE_MD5, MyConst.SIGN_TYPE_HMACSHA256));

        Map<String, Object> retMap = new LinkedHashMap<>(defaults.size());
        for (Map.Entry<String, Object> entry : defaults.entrySet()) {
            String key = entry.getKey();
            Object defaultValue = entry.getValue();
            Object specificValue = specifics.get(key);
            if (null != specificValue) {
                retMap.put(key, specificValue);
            } else if (null != defaultValue) {
                retMap.put(key, defaultValue);
            }
        }
        retMap.put(MyConst.FIELD_SIGN, SignUtil.generateSignatureTest(retMap, "2ry14bjme2kmjhd0r5j611q6t4ylez46"));

        return retMap;
    }
}
