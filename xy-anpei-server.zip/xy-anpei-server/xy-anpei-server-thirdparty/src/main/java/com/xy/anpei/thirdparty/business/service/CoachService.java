package com.xy.anpei.thirdparty.business.service;

import com.xy.anpei.thirdparty.business.dto.coach.GraduationDto;
import com.xy.anpei.thirdparty.business.dto.coach.StudyTimeDto;
import com.xy.anpei.thirdparty.business.dto.coach.TestDataDto;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 13:59
 */
public interface CoachService {

    /**
     * 教练员学时记录
     *
     * @param dto StudyTimeDto
     */
    void studyTime(StudyTimeDto dto);

    /**
     * 教练员结业证
     *
     * @param dto GraduationDto
     */
    void graduation(GraduationDto dto);

    /**
     * 获取测试数据
     *
     * @param dto TestDataDto
     * @return Object
     */
    Object getTestData(TestDataDto dto);
}
