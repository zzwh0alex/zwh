package com.xy.anpei.thirdparty.business.controller;

import com.xy.anpei.thirdparty.business.dto.coach.GraduationDto;
import com.xy.anpei.thirdparty.business.dto.coach.StudyTimeDto;
import com.xy.anpei.thirdparty.business.dto.coach.TestDataDto;
import com.xy.anpei.thirdparty.business.service.CoachService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 13:57
 */
@RestController
@RequestMapping("/coach")
public class CoachController {

    private final CoachService coachService;

    public CoachController(CoachService coachService) {
        this.coachService = coachService;
    }

    @PostMapping(value = "/studyTime", name = "上传教练员学时记录")
    public void studyTime(@RequestBody @Valid StudyTimeDto dto) {
        coachService.studyTime(dto);
    }

    @PostMapping(value = "/graduation", name = "上传教练员结业证")
    public void graduation(@RequestBody @Valid GraduationDto dto) {
        coachService.graduation(dto);
    }

    @PostMapping(value = "/testData", name = "获取测试数据")
    public Object testData(@RequestBody @Valid TestDataDto dto) {
        return coachService.getTestData(dto);
    }
}
