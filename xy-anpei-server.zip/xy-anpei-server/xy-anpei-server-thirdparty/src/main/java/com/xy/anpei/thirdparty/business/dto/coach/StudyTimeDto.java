package com.xy.anpei.thirdparty.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.*;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 14:00
 */
@Data
public class StudyTimeDto {

    /**
     * 报名记录 ID
     */
    @NotBlank(message = "报名记录ID不能为空")
    private String trainId;

    /**
     * 培训机构全国统一编号
     */
    @NotBlank(message = "机构编号不能为空")
    private String unitNo;

    /**
     * 教练员 ID
     */
    @NotBlank(message = "教练员ID不能为空")
    private String coachId;

    /**
     * 课程名称
     */
    private String subjectName;

    /**
     * 课件名称
     */
    private String courseName;

    /**
     * 学时类型
     * video：视频；practice：练习
     */
    @NotBlank(message = "学时类型不能为空")
    private String timeType;

    /**
     * 开始时间
     */
    @NotBlank(message = "开始时间不能为空")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", message = "开始时间格式不正确")
    private String startTime;

    /**
     * 结束时间
     */
    @NotBlank(message = "结束时间不能为空")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", message = "结束时间格式不正确")
    private String endTime;

    /**
     * 有效时长（单位：分钟）
     */
    @NotNull(message = "有效时长不能为空")
    private Integer duration;

    /**
     * 学时状态
     * 0-无效；1-有效
     */
    @NotNull(message = "学时状态不能为空")
    @Min(value = 0, message = "学时状态不正确")
    @Max(value = 1, message = "学时状态不正确")
    private Integer status;

    /**
     * 学员身份证号
     */
    @NotBlank(message = "身份证号不能为空")
    private String stuIdCard;

    /**
     * 客户端
     */
    private String client;

    /**
     * 访问 IP
     */
    private String requestIp;

    /**
     * 备注
     */
    private String remark;

    /**
     * 照片集合
     */
    private Object photoList;

    /**
     * 请求时间
     */
    @NotNull(message = "请求时间不能为空")
    private Long requestTime;

    /**
     * 随机字符串
     */
    @NotBlank(message = "随机字符串不能为空")
    private String nonce;

    /**
     * 签名类型
     */
    @Pattern(regexp = "^$|^MD5|HMAC-SHA256$", message = "签名类型不正确")
    private String signType;

    /**
     * 签名
     */
    @NotBlank(message = "签名不能为空")
    private String sign;
}
