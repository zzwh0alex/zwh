package com.xy.anpei.thirdparty.business.dto.coach;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author Chen Guibiao
 * Create at 2023-05-22 14:02
 */
@Data
public class GraduationDto {

    /**
     * 报名记录 ID
     */
    @NotBlank(message = "报名记录ID不能为空")
    private String trainId;

    /**
     * 培训机构全国统一编号
     */
    @NotBlank(message = "机构编号不能为空")
    private String unitNo;

    /**
     * 教练员 ID
     */
    @NotBlank(message = "教练员ID不能为空")
    private String coachId;

    /**
     * 结业证地址
     */
    @NotBlank(message = "结业证地址不能为空")
    private String url;

    /**
     * 请求时间
     */
    @NotNull(message = "请求时间不能为空")
    private Long requestTime;

    /**
     * 随机字符串
     */
    @NotBlank(message = "随机字符串不能为空")
    private String nonce;

    /**
     * 签名类型
     */
    @Pattern(regexp = "^$|^MD5|HMAC-SHA256$", message = "签名类型不正确")
    private String signType;

    /**
     * 签名
     */
    @NotBlank(message = "签名不能为空")
    private String sign;
}
